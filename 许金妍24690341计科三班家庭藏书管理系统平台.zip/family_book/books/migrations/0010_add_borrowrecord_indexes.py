# Generated migration for BorrowRecord performance indexes

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('books', '0009_add_book_indexes'),
    ]

    operations = [
        # Add indexes to BorrowRecord for better query performance
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['borrower_name'], name='borrowrecord_borrower_name_idx'),
        ),
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['borrow_date'], name='borrowrecord_borrow_date_idx'),
        ),
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['return_date'], name='borrowrecord_return_date_idx'),
        ),
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['is_returned'], name='borrowrecord_is_returned_idx'),
        ),
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['book', 'return_date'], name='borrowrecord_book_return_idx'),
        ),
        migrations.AddIndex(
            model_name='borrowrecord',
            index=models.Index(fields=['borrower', 'return_date'], name='borrowrecord_borrower_return_idx'),
        ),
    ]
