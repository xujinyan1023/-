 
from django.db import models
from django.contrib.auth.models import User


# 图书分类模型品牌【
class Category(models.Model):
    name = models.CharField(max_length=20, unique=True, verbose_name="分类名称")
    sort_order = models.IntegerField(default=0, verbose_name="排序顺序")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = "图书分类"
        verbose_name_plural = "图书分类"
        ordering = ['sort_order', 'id']

    def __str__(self):
        return self.name


# 书架位置模型
class ShelfLocation(models.Model):
    name = models.CharField(max_length=50, verbose_name="位置名称")
    description = models.CharField(max_length=200, blank=True, verbose_name="位置描述")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = "书架位置"
        verbose_name_plural = "书架位置"
        ordering = ['name']

    def __str__(self):
        return self.name


# 用户角色扩展表（仿微信账号体系）
class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('member', '普通成员'),
        ('guest', '游客'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='member')
    reader = models.ForeignKey('Reader', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="关联借阅人")
    # 手机号作为唯一实名标识（仿微信）- 允许为空以兼容历史数据，但新注册必填
    phone = models.CharField(max_length=11, unique=True, null=True, blank=True, verbose_name="手机号")
    # 昵称（可修改）
    nickname = models.CharField(max_length=50, blank=True, verbose_name="昵称")
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True, verbose_name="用户头像")

    def has_permission(self, action):
        role_perms = {
            'member': {'view', 'borrow', 'return', 'note'},
            'guest': {'view'},
        }
        return action in role_perms.get(self.role, set())

    @property
    def display_name(self):
        """获取显示名称：优先昵称 > 关联借阅人名 > 用户名"""
        if self.nickname:
            return self.nickname
        if self.reader:
            return self.reader.reader_name
        return self.user.username

    def __str__(self):
        return f"{self.display_name} ({self.user.username})"


# 最近登录记录（用于快速切换账号 - 仿微信安全机制）
class RecentLogin(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recent_logins')
    last_login = models.DateTimeField(auto_now=True, verbose_name="最后登录时间")
    quick_login_token = models.CharField(max_length=64, blank=True, verbose_name="快速登录令牌")
    token_expires = models.DateTimeField(null=True, blank=True, verbose_name="令牌过期时间")
    # 安全相关字段
    password_verified_at = models.DateTimeField(null=True, blank=True, verbose_name="最后密码验证时间")
    switch_count = models.IntegerField(default=0, verbose_name="切换次数计数")
    switch_count_reset_at = models.DateTimeField(null=True, blank=True, verbose_name="切换计数重置时间")
    # 会话安全
    session_key = models.CharField(max_length=64, blank=True, verbose_name="会话标识")

    class Meta:
        verbose_name = "最近登录"
        verbose_name_plural = "最近登录"
        ordering = ['-last_login']

    def __str__(self):
        return f"{self.user.username} - {self.last_login}"

# 图书表（对应你原来的book表）
class Book(models.Model):
    book_name = models.CharField(max_length=255, verbose_name="书名", db_index=True)
    author = models.CharField(max_length=255, verbose_name="作者", db_index=True)
    isbn = models.CharField(
        max_length=13,
        verbose_name="ISBN号",
        null=True,
        blank=True,
        default="",
        db_index=True,
    )
    status = models.CharField(max_length=20, default="在架", verbose_name="状态", db_index=True)
    cover = models.ImageField(upload_to='covers/', null=True, blank=True, verbose_name="图书封面")
    book_type = models.CharField(max_length=20, verbose_name="图书分类", db_index=True)
    place = models.CharField(max_length=30, null=True, blank=True, verbose_name="存放位置")
    description = models.TextField(blank=True, null=True, verbose_name="书籍介绍")
    publisher = models.CharField(max_length=100, blank=True, null=True, verbose_name="出版社")
    publish_date = models.DateField(blank=True, null=True, verbose_name="出版日期")

    class Meta:
        verbose_name = "图书"
        verbose_name_plural = "图书"
        indexes = [
            models.Index(fields=['book_type', 'status']),
        ]

    def __str__(self):
        return self.book_name

# 读者表（对应你原来的readers表）
class Reader(models.Model):
    reader_name = models.CharField(max_length=50, unique=True, verbose_name="借阅人")

    def __str__(self):
        return self.reader_name

# 借阅记录表（对应你原来的borrow_records表）
class BorrowRecord(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE, verbose_name="借阅书籍")
    borrower = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="借阅人(用户)", null=True, blank=True)
    borrower_name = models.CharField(max_length=50, verbose_name="借阅人姓名", null=True, blank=True, db_index=True)
    borrow_date = models.DateTimeField(auto_now_add=True, verbose_name="借阅时间", db_index=True)
    return_date = models.DateTimeField(null=True, blank=True, verbose_name="归还时间", db_index=True)
    is_returned = models.BooleanField(default=False, verbose_name="是否归还", db_index=True)

    class Meta:
        verbose_name = "借阅记录"
        verbose_name_plural = "借阅记录"
        indexes = [
            models.Index(fields=['book', 'return_date']),
            models.Index(fields=['borrower', 'return_date']),
        ]

    def get_borrower_display_name(self):
        """获取借阅人显示名称"""
        # 优先返回 borrower_name（借阅时保存的姓名）
        if self.borrower_name:
            return self.borrower_name
        # 其次尝试从关联用户获取
        if self.borrower:
            try:
                profile = self.borrower.profile
                if profile and profile.reader:
                    return profile.reader.reader_name
            except:
                pass
            return self.borrower.username
        return "未知"

    def __str__(self):
        return f"{self.book} - {self.get_borrower_display_name()}"


# 书籍评论模型
class BookComment(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE, verbose_name="书籍", related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="评论者")
    content = models.TextField(verbose_name="评论内容")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="评论时间")

    class Meta:
        verbose_name = "书籍评论"
        verbose_name_plural = "书籍评论"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.book.book_name} - {self.user.username}"


# 书摘书评模型
class BookNote(models.Model):
    NOTE_TYPES = [
        ('excerpt', '书摘'),
        ('review', '书评'),
    ]
    book = models.ForeignKey(Book, on_delete=models.CASCADE, verbose_name="书籍", related_name='notes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="作者")
    note_type = models.CharField(max_length=10, choices=NOTE_TYPES, default='excerpt', verbose_name="类型")
    title = models.CharField(max_length=200, verbose_name="标题")
    content = models.TextField(verbose_name="内容")
    page_number = models.IntegerField(null=True, blank=True, verbose_name="页码")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        verbose_name = "书摘书评"
        verbose_name_plural = "书摘书评"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.book.book_name} - {self.title}"


# AI 聊天记录模型
class ChatMessage(models.Model):
    """AI 助手聊天记录"""
    ROLE_CHOICES = [
        ('user', '用户'),
        ('assistant', '助手'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="用户", related_name='chat_messages')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, verbose_name="角色")
    content = models.TextField(verbose_name="消息内容")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = "聊天记录"
        verbose_name_plural = "聊天记录"
        ordering = ['created_at']  # 按时间正序，方便显示

    def __str__(self):
        return f"{self.user.username} - {self.role} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"


# 借阅提醒/通知模型
class Notification(models.Model):
    """借阅提醒通知"""
    NOTIFICATION_TYPES = [
        ('due_reminder', '到期提醒'),
        ('overdue', '逾期通知'),
        ('system', '系统通知'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="用户", related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES, verbose_name="通知类型")
    title = models.CharField(max_length=100, verbose_name="通知标题")
    content = models.TextField(verbose_name="通知内容")
    borrow_record = models.ForeignKey(BorrowRecord, on_delete=models.CASCADE, null=True, blank=True, verbose_name="关联借阅记录")
    is_read = models.BooleanField(default=False, verbose_name="是否已读")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        verbose_name = "通知"
        verbose_name_plural = "通知"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.title}"


# 系统操作日志模型
class OperationLog(models.Model):
    """系统操作日志"""
    ACTION_TYPES = [
        ('borrow', '借书'),
        ('return', '还书'),
        ('add_book', '添加图书'),
        ('edit_book', '编辑图书'),
        ('delete_book', '删除图书'),
        ('add_member', '添加成员'),
        ('delete_member', '删除成员'),
        ('login', '登录'),
        ('logout', '退出登录'),
    ]

    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="操作用户")
    action = models.CharField(max_length=20, choices=ACTION_TYPES, verbose_name="操作类型")
    target_type = models.CharField(max_length=50, blank=True, verbose_name="目标类型")
    target_id = models.IntegerField(null=True, blank=True, verbose_name="目标ID")
    target_name = models.CharField(max_length=255, blank=True, verbose_name="目标名称")
    detail = models.TextField(blank=True, verbose_name="操作详情")
    ip_address = models.CharField(max_length=50, blank=True, verbose_name="IP地址")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="操作时间")

    class Meta:
        verbose_name = "操作日志"
        verbose_name_plural = "操作日志"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user} - {self.get_action_display()} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"


# 书评点赞模型
class BookCommentLike(models.Model):
    """书评点赞"""
    comment = models.ForeignKey(BookComment, on_delete=models.CASCADE, verbose_name="评论", related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="点赞用户")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="点赞时间")

    class Meta:
        verbose_name = "书评点赞"
        verbose_name_plural = "书评点赞"
        unique_together = ['comment', 'user']  # 每个用户对每条评论只能点赞一次

    def __str__(self):
        return f"{self.user.username} 点赞了 {self.comment.book.book_name}"


# 阅读打卡记录模型
class ReadingCheckIn(models.Model):
    """阅读打卡记录"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="用户", related_name='checkins')
    checkin_date = models.DateField(verbose_name="打卡日期", db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="打卡时间")

    class Meta:
        verbose_name = "阅读打卡"
        verbose_name_plural = "阅读打卡"
        unique_together = ['user', 'checkin_date']  # 每天只能打卡一次
        ordering = ['-checkin_date']

    def __str__(self):
        return f"{self.user.username} - {self.checkin_date}"


# 用户徽章模型
class UserBadge(models.Model):
    """用户徽章"""
    BADGE_TYPES = [
        ('week_reader', '一周阅读达人', '连续打卡7天'),
        ('month_reader', '月度阅读之星', '累计打卡30天'),
        ('book_lover', '藏书爱好者', '累计借阅10本书'),
    ]

    BADGE_ICONS = {
        'week_reader': '🌟',
        'month_reader': '🏆',
        'book_lover': '📚',
    }

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="用户", related_name='badges')
    badge_type = models.CharField(max_length=20, verbose_name="徽章类型")
    earned_at = models.DateTimeField(auto_now_add=True, verbose_name="获得时间")

    class Meta:
        verbose_name = "用户徽章"
        verbose_name_plural = "用户徽章"
        unique_together = ['user', 'badge_type']  # 每种徽章只能获得一次
        ordering = ['-earned_at']

    def __str__(self):
        badge_info = dict((t[0], t[1]) for t in self.BADGE_TYPES)
        return f"{self.user.username} - {badge_info.get(self.badge_type, self.badge_type)}"

    @property
    def name(self):
        badge_info = dict((t[0], t[1]) for t in self.BADGE_TYPES)
        return badge_info.get(self.badge_type, self.badge_type)

    @property
    def description(self):
        badge_info = dict((t[0], t[2]) for t in self.BADGE_TYPES)
        return badge_info.get(self.badge_type, '')

    @property
    def icon(self):
        return self.BADGE_ICONS.get(self.badge_type, '🏅')