# 火山方舟语音合成 (TTS) API
# 将文本转换为自然语音

import requests
import json
import base64
import time
import re

# ==================== 配置区域 ====================

# 火山方舟 TTS API 配置
TTS_APP_ID = "7726628082"
TTS_ACCESS_TOKEN = "akE0TW7kUV2XKmoLXCfD2aer08Awj2zE"

# TTS API 地址
TTS_API_URL = "https://openspeech.bytedance.com/api/v1/tts"

# 语音配置
DEFAULT_VOICE = "zh_female_shuangkuaisisi_moon_bigtts"  # 默认女声（晴川）
DEFAULT_SPEED = 1.0  # 语速
DEFAULT_VOLUME = 1.0  # 音量

# ==================================================


def text_to_speech(text: str, voice: str = None, speed: float = None) -> dict:
    """
    调用火山方舟 TTS API 将文本转换为语音

    Args:
        text: 要转换的文本
        voice: 语音类型（可选）
        speed: 语速（可选）

    Returns:
        dict: 包含音频数据或错误信息
    """
    if not text:
        return {'success': False, 'error': '文本不能为空'}

    # 清理文本中的HTML标签和特殊字符
    clean_text = re.sub(r'<[^>]+>', '', text)
    clean_text = clean_text.replace('&nbsp;', ' ').replace('&amp;', '&')
    clean_text = clean_text.strip()

    if not clean_text:
        return {'success': False, 'error': '文本内容无效'}

    # 限制文本长度
    if len(clean_text) > 500:
        clean_text = clean_text[:500] + "..."

    # 如果没有配置Token，使用浏览器原生TTS
    if not TTS_APP_ID or not TTS_ACCESS_TOKEN:
        return {
            'success': False,
            'error': 'TTS未配置Access Token',
            'fallback': True,
            'text': clean_text
        }

    try:
        # 构建请求
        headers = {
            "Content-Type": "application/json",
        }

        payload = {
            "app": {
                "appid": TTS_APP_ID,
                "token": TTS_ACCESS_TOKEN,
                "cluster": "volcano_tts",
            },
            "user": {
                "uid": "tutu_ai"
            },
            "audio": {
                "voice_type": voice or DEFAULT_VOICE,
                "encoding": "mp3",
                "speed_ratio": speed or DEFAULT_SPEED,
                "volume_ratio": DEFAULT_VOLUME,
                "pitch_ratio": 1.0,
            },
            "request": {
                "reqid": str(int(time.time() * 1000)),
                "text": clean_text,
                "text_type": "plain",
                "operation": "query"
            }
        }

        response = requests.post(
            TTS_API_URL,
            headers=headers,
            json=payload,
            timeout=15
        )

        if response.status_code == 200:
            result = response.json()

            if result.get('code') == 0 and 'data' in result:
                return {
                    'success': True,
                    'audio': result['data'],
                    'format': 'mp3',
                    'text': clean_text
                }
            else:
                return {
                    'success': False,
                    'error': result.get('message', 'TTS合成失败'),
                    'fallback': True
                }
        else:
            return {
                'success': False,
                'error': f'TTS请求失败: {response.status_code}',
                'fallback': True
            }

    except Exception as e:
        return {'success': False, 'error': f'TTS异常: {str(e)}', 'fallback': True}


def get_available_voices() -> list:
    """
    获取可用的语音列表

    Returns:
        list: 语音列表
    """
    voices = [
        {"id": "zh_female_shuangkuaisisi_moon_bigtts", "name": "晴川", "desc": "温柔女声"},
        {"id": "zh_male_chunhouzixin_moon_bigtts", "name": "宇飞", "desc": "沉稳男声"},
        {"id": "zh_female_tianmeixiaoyuan_moon_bigtts", "name": "晓颜", "desc": "甜美女声"},
        {"id": "zh_male_wanwanxiaohe_moon_bigtts", "name": "超自然音色-梓梓", "desc": "少年音"},
    ]
    return voices
