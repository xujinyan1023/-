# AI 工具函数
# 用于图书系统的 AI 功能扩展

from books.models import Book, BorrowRecord, UserProfile, Reader
from django.contrib.auth.models import User
from django.db.models import Q
from difflib import SequenceMatcher
from functools import lru_cache


# ========== 错别字纠错功能 ==========

def get_similarity(a: str, b: str) -> float:
    """计算两个字符串的相似度（0-1）"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


@lru_cache(maxsize=1)
def get_all_authors():
    """获取数据库中所有作者名（缓存）"""
    return list(Book.objects.values_list('author', flat=True).distinct())


@lru_cache(maxsize=1)
def get_all_book_names():
    """获取数据库中所有书名（缓存）"""
    return list(Book.objects.values_list('book_name', flat=True).distinct())


def clear_tools_cache():
    """清除工具函数的缓存（在数据变更时调用）"""
    get_all_authors.cache_clear()
    get_all_book_names.cache_clear()
    get_all_borrower_names.cache_clear()


@lru_cache(maxsize=1)
def get_all_borrower_names():
    """获取所有借阅人姓名（包括用户昵称和借阅记录中的姓名）"""
    names = set()

    # 从 UserProfile 获取所有用户的显示名称
    for profile in UserProfile.objects.all():
        if profile.display_name:
            names.add(profile.display_name)
        if profile.nickname:
            names.add(profile.nickname)

    # 从 Reader 表获取
    for reader in Reader.objects.all():
        if reader.reader_name:
            names.add(reader.reader_name)

    # 从借阅记录获取
    for record in BorrowRecord.objects.values_list('borrower_name', flat=True).distinct():
        if record:
            names.add(record)

    return list(names)


def fuzzy_match_author(keyword: str, threshold: float = 0.6) -> tuple:
    """
    模糊匹配作者名

    Args:
        keyword: 用户输入的关键词
        threshold: 相似度阈值（0-1）

    Returns:
        tuple: (是否匹配成功, 正确的作者名, 相似度)
    """
    if not keyword or len(keyword) < 2:
        return False, None, 0

    best_match = None
    best_score = 0

    authors = get_all_authors()
    for author in authors:
        if not author:
            continue

        # 完全匹配
        if keyword == author:
            return True, author, 1.0

        # 包含匹配
        if keyword in author or author in keyword:
            score = 0.85
            if score > best_score:
                best_match = author
                best_score = score
            continue

        # 相似度匹配
        score = get_similarity(keyword, author)
        if score > best_score and score >= threshold:
            best_match = author
            best_score = score

    if best_match:
        return True, best_match, best_score

    return False, None, 0


def fuzzy_match_book_name(keyword: str, threshold: float = 0.6) -> tuple:
    """
    模糊匹配书名

    Args:
        keyword: 用户输入的关键词
        threshold: 相似度阈值（0-1）

    Returns:
        tuple: (是否匹配成功, 正确的书名, 相似度)
    """
    if not keyword or len(keyword) < 2:
        return False, None, 0

    best_match = None
    best_score = 0

    book_names = get_all_book_names()
    for book_name in book_names:
        if not book_name:
            continue

        # 完全匹配
        if keyword == book_name:
            return True, book_name, 1.0

        # 包含匹配
        if keyword in book_name or book_name in keyword:
            score = 0.85
            if score > best_score:
                best_match = book_name
                best_score = score
            continue

        # 相似度匹配
        score = get_similarity(keyword, book_name)
        if score > best_score and score >= threshold:
            best_match = book_name
            best_score = score

    if best_match:
        return True, best_match, best_score

    return False, None, 0


def smart_search_books(keyword: str) -> dict:
    """
    智能搜索书籍（支持错别字纠错）

    Args:
        keyword: 用户输入的关键词

    Returns:
        dict: 包含搜索结果、纠错提示等信息
    """
    if not keyword:
        return {'books': [], 'correction': None}

    # 先尝试直接搜索
    books = _search_books_internal(keyword)

    # 如果找到了结果，直接返回
    if books:
        return {'books': books, 'correction': None}

    # 没找到结果，尝试模糊匹配
    correction = None
    corrected_keyword = None

    # 尝试匹配作者名
    author_matched, author_name, author_score = fuzzy_match_author(keyword)
    if author_matched:
        correction = f'你是不是想找作者「{author_name}」？'
        corrected_keyword = author_name

    # 尝试匹配书名
    book_matched, book_name, book_score = fuzzy_match_book_name(keyword)
    if book_matched and book_score > author_score:
        correction = f'你是不是想找《{book_name}》这本书？'
        corrected_keyword = book_name

    # 如果有纠错建议，用正确的关键词重新搜索
    if corrected_keyword:
        books = _search_books_internal(corrected_keyword)

    return {
        'books': books,
        'correction': correction,
        'original_keyword': keyword,
        'corrected_keyword': corrected_keyword,
    }


def _search_books_internal(keyword: str) -> list:
    """内部搜索函数"""
    books = Book.objects.filter(
        book_name__icontains=keyword
    ) | Book.objects.filter(
        author__icontains=keyword
    ) | Book.objects.filter(
        isbn__icontains=keyword
    ) | Book.objects.filter(
        publisher__icontains=keyword
    ) | Book.objects.filter(
        book_type__icontains=keyword
    )

    result = []
    for book in books[:10]:
        borrower_info = None
        if book.status == '借出':
            record = BorrowRecord.objects.filter(book=book, is_returned=False).first()
            if record:
                borrower_info = record.get_borrower_display_name()

        result.append({
            'id': book.id,
            'name': book.book_name,
            'author': book.author,
            'status': book.status,
            'category': book.book_type,
            'place': book.place or '未设置',
            'borrower': borrower_info,
        })

    return result


def search_books(keyword: str) -> list:
    """
    根据关键词搜索书籍（兼容旧接口）

    Args:
        keyword: 搜索关键词（匹配书名、作者、ISBN、出版社）

    Returns:
        list: 匹配的书籍列表，每本书包含 id, name, author, status, category, borrower
    """
    result = smart_search_books(keyword)
    return result.get('books', [])


def fuzzy_match_borrower(keyword: str, threshold: float = 0.6) -> tuple:
    """
    模糊匹配借阅人姓名

    Args:
        keyword: 用户输入的关键词
        threshold: 相似度阈值（0-1）

    Returns:
        tuple: (是否匹配成功, 正确的姓名, 相似度)
    """
    if not keyword or len(keyword) < 2:
        return False, None, 0

    best_match = None
    best_score = 0

    names = get_all_borrower_names()
    for name in names:
        if not name:
            continue

        # 完全匹配
        if keyword == name:
            return True, name, 1.0

        # 包含匹配
        if keyword in name or name in keyword:
            score = 0.85
            if score > best_score:
                best_match = name
                best_score = score
            continue

        # 相似度匹配
        score = get_similarity(keyword, name)
        if score > best_score and score >= threshold:
            best_match = name
            best_score = score

    if best_match:
        return True, best_match, best_score

    return False, None, 0


def find_user_by_name(name: str) -> list:
    """
    根据姓名查找用户（支持模糊匹配）

    Args:
        name: 用户姓名或昵称

    Returns:
        list: 匹配的 User 对象列表
    """
    users = []

    # 1. 先尝试精确匹配用户名
    exact_users = User.objects.filter(username=name)
    users.extend(exact_users)

    # 2. 通过 UserProfile 的 nickname 精确匹配
    profile_matches = UserProfile.objects.filter(nickname=name).select_related('user')
    for profile in profile_matches:
        if profile.user not in users:
            users.append(profile.user)

    # 3. 通过 UserProfile 的 display_name 模糊匹配
    if len(users) == 0:
        # 模糊匹配 nickname
        profile_matches = UserProfile.objects.filter(nickname__icontains=name).select_related('user')
        for profile in profile_matches:
            if profile.user not in users:
                users.append(profile.user)

    # 4. 通过 Reader 表匹配
    if len(users) == 0:
        readers = Reader.objects.filter(reader_name__icontains=name)
        for reader in readers:
            # 查找关联的用户
            profiles = UserProfile.objects.filter(reader=reader).select_related('user')
            for profile in profiles:
                if profile.user not in users:
                    users.append(profile.user)

    return users


def search_by_borrower(borrower_name: str) -> dict:
    """
    根据借阅人姓名搜索借阅记录（支持模糊匹配）

    Args:
        borrower_name: 借阅人姓名

    Returns:
        dict: 包含借阅记录列表、纠错提示等信息
    """
    if not borrower_name:
        return {
            'records': [],
            'correction': None,
            'matched_name': None,
        }

    # 1. 先尝试直接查询借阅记录
    records = BorrowRecord.objects.filter(
        borrower_name__icontains=borrower_name
    ).select_related('book').order_by('-borrow_date')[:20]

    # 2. 尝试通过用户名查找
    users = find_user_by_name(borrower_name)
    for user in users:
        user_records = BorrowRecord.objects.filter(
            borrower=user
        ).select_related('book').order_by('-borrow_date')[:20]
        records = records | user_records

    # 去重
    record_ids = set()
    unique_records = []
    for record in records:
        if record.id not in record_ids:
            record_ids.add(record.id)
            unique_records.append(record)

    # 如果找到了结果
    if unique_records:
        result_list = []
        for record in unique_records[:10]:
            result_list.append({
                'book_name': record.book.book_name,
                'author': record.book.author,
                'borrower': record.get_borrower_display_name(),
                'borrow_date': record.borrow_date.strftime('%Y-%m-%d %H:%M'),
                'return_date': record.return_date.strftime('%Y-%m-%d %H:%M') if record.return_date else None,
                'is_returned': record.is_returned,
                'status': '已归还' if record.is_returned else '借阅中',
            })

        return {
            'records': result_list,
            'correction': None,
            'matched_name': borrower_name,
            'total': len(unique_records),
        }

    # 没找到结果，尝试模糊匹配
    matched, corrected_name, score = fuzzy_match_borrower(borrower_name)

    if matched:
        correction = f'你是不是要找「{corrected_name}」？'
        # 用正确的名字重新搜索
        records = BorrowRecord.objects.filter(
            borrower_name__icontains=corrected_name
        ).select_related('book').order_by('-borrow_date')[:20]

        # 也查找用户
        users = find_user_by_name(corrected_name)
        for user in users:
            user_records = BorrowRecord.objects.filter(
                borrower=user
            ).select_related('book').order_by('-borrow_date')[:20]
            records = records | user_records

        result_list = []
        for record in records[:10]:
            result_list.append({
                'book_name': record.book.book_name,
                'author': record.book.author,
                'borrower': record.get_borrower_display_name(),
                'borrow_date': record.borrow_date.strftime('%Y-%m-%d %H:%M'),
                'return_date': record.return_date.strftime('%Y-%m-%d %H:%M') if record.return_date else None,
                'is_returned': record.is_returned,
                'status': '已归还' if record.is_returned else '借阅中',
            })

        return {
            'records': result_list,
            'correction': correction,
            'matched_name': corrected_name,
            'total': len(result_list),
        }

    # 确实没找到
    return {
        'records': [],
        'correction': f'未找到名为「{borrower_name}」的借阅人，请核对名字是否正确。',
        'matched_name': None,
        'all_borrowers': get_all_borrower_names()[:10],  # 返回可用的借阅人列表
    }


def get_book_detail(book_id: int) -> dict:
    """
    获取书籍详细信息

    Args:
        book_id: 书籍 ID

    Returns:
        dict: 书籍详细信息，包含所有字段
    """
    try:
        book = Book.objects.get(id=book_id)

        return {
            'id': book.id,
            'name': book.book_name,
            'author': book.author,
            'isbn': book.isbn or '无',
            'status': book.status,
            'category': book.book_type,
            'place': book.place or '未设置',
            'publisher': book.publisher or '未知',
            'publish_date': book.publish_date.strftime('%Y-%m-%d') if book.publish_date else '未知',
            'description': book.description or '暂无简介',
            'cover': book.cover.url if book.cover else None,
        }

    except Book.DoesNotExist:
        return {'error': f'未找到 ID 为 {book_id} 的书籍'}


def recommend_books(age: int = None, category: str = None, limit: int = 5) -> list:
    """
    推荐书籍

    Args:
        age: 推荐年龄段（可选，目前用于简单筛选）
        category: 书籍分类（可选）
        limit: 返回数量，默认 5 本

    Returns:
        list: 推荐的书籍列表
    """
    # 基础查询：在架的书籍
    books = Book.objects.filter(status='在架')

    # 按分类筛选
    if category:
        books = books.filter(book_type__icontains=category)

    # 按年龄段简单筛选（基于分类名称判断）
    # 这里的逻辑可以根据实际需求扩展
    if age:
        age_categories = get_age_categories(age)
        if age_categories:
            books = books.filter(book_type__in=age_categories)

    # 按推荐数量限制
    books = books[:limit]

    # 转换为字典列表
    result = []
    for book in books:
        result.append({
            'id': book.id,
            'name': book.book_name,
            'author': book.author,
            'category': book.book_type,
            'status': book.status,
            'description': (book.description[:100] + '...') if book.description and len(book.description) > 100 else (book.description or '暂无简介'),
        })

    return result


def get_age_categories(age: int) -> list:
    """
    根据年龄返回适合的书籍分类

    Args:
        age: 年龄

    Returns:
        list: 适合该年龄的分类列表
    """
    # 年龄段与分类的映射（可根据实际情况调整）
    if age <= 6:
        return ['绘本', '幼儿读物', '儿童文学', '启蒙']
    elif age <= 12:
        return ['儿童文学', '科普', '故事', '少儿读物']
    elif age <= 18:
        return ['青少年读物', '文学', '科普', '历史']
    else:
        return []  # 成人不限分类


# ==================== 借阅相关工具函数 ====================

def get_user_borrow_records(user_id: int, limit: int = 10) -> list:
    """
    获取用户的借阅记录

    Args:
        user_id: 用户 ID
        limit: 返回数量，默认 10 条

    Returns:
        list: 借阅记录列表
    """
    # 查询该用户的所有借阅记录，按时间倒序
    records = BorrowRecord.objects.filter(
        borrower_id=user_id
    ).select_related('book').order_by('-borrow_date')[:limit]

    result = []
    for record in records:
        result.append({
            'record_id': record.id,
            'book_id': record.book.id,
            'book_name': record.book.book_name,
            'author': record.book.author,
            'borrow_date': record.borrow_date.strftime('%Y-%m-%d %H:%M'),
            'return_date': record.return_date.strftime('%Y-%m-%d %H:%M') if record.return_date else None,
            'is_returned': record.is_returned,
            'status': '已归还' if record.is_returned else '借阅中',
        })

    return result


def get_borrow_status(book_id: int) -> dict:
    """
    查询书籍当前的借阅状态

    Args:
        book_id: 书籍 ID

    Returns:
        dict: 借阅状态信息
    """
    try:
        book = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return {'error': f'未找到 ID 为 {book_id} 的书籍'}

    # 基本状态信息
    result = {
        'book_id': book_id,
        'book_name': book.book_name,
        'status': book.status,
        'is_borrowed': book.status == '借出',
    }

    # 如果被借出，查询借阅人信息
    if book.status == '借出':
        # 查找最新的未归还记录
        record = BorrowRecord.objects.filter(
            book_id=book_id,
            is_returned=False
        ).first()

        if record:
            result['borrower'] = record.get_borrower_display_name()
            result['borrow_date'] = record.borrow_date.strftime('%Y-%m-%d')
            result['record_id'] = record.id

    return result


def get_borrow_stats(user_id: int) -> dict:
    """
    统计用户的借阅数据

    Args:
        user_id: 用户 ID

    Returns:
        dict: 借阅统计数据
    """
    # 用户的所有借阅记录
    all_records = BorrowRecord.objects.filter(borrower_id=user_id)

    # 总借阅数
    total_count = all_records.count()

    # 未归还数量
    unreturned_count = all_records.filter(is_returned=False).count()

    # 已归还数量
    returned_count = total_count - unreturned_count

    # 当前借阅的书籍列表
    current_books = []
    unreturned_records = all_records.filter(is_returned=False).select_related('book')
    for record in unreturned_records:
        current_books.append({
            'book_name': record.book.book_name,
            'borrow_date': record.borrow_date.strftime('%Y-%m-%d'),
        })

    return {
        'user_id': user_id,
        'total_count': total_count,
        'returned_count': returned_count,
        'unreturned_count': unreturned_count,
        'current_books': current_books,
    }


# ==================== 内容生成相关工具函数 ====================

def generate_book_summary(book_title: str, content: str = None) -> dict:
    """
    生成书籍摘要或阅读心得

    Args:
        book_title: 书名
        content: 书籍内容或阅读感想（可选）

    Returns:
        dict: 包含生成的书摘和心得
    """
    from books.utils.ai_client import chat

    # 构建提示词
    if content:
        prompt = f"""请根据以下内容，为《{book_title}》这本书：
1. 生成一段 100 字左右的精彩书摘
2. 写一段简短的阅读心得（50字以内）

内容：
{content}

请用简洁、优美的语言，分别标注【书摘】和【心得】。"""
    else:
        prompt = f"""请为《{book_title}》这本书：
1. 写一段 100 字左右的推荐语
2. 简要介绍这本书适合什么人阅读

请用简洁、友好的语言表达。"""

    try:
        # 调用 AI 生成内容
        result = chat(prompt)
        return {
            'book_title': book_title,
            'content': result,
            'success': True,
        }
    except Exception as e:
        return {
            'book_title': book_title,
            'content': None,
            'success': False,
            'error': str(e),
        }


def organize_review(review_text: str) -> dict:
    """
    整理和润色用户书评

    Args:
        review_text: 用户输入的原始书评

    Returns:
        dict: 包含润色后的书评
    """
    from books.utils.ai_client import chat

    if not review_text:
        return {
            'original': review_text,
            'polished': None,
            'success': False,
            'error': '请输入书评内容',
        }

    prompt = f"""请对以下书评进行整理和润色：
1. 修正错别字和语病
2. 优化语句表达，使其更流畅
3. 保持原作者的观点和情感
4. 字数控制在原文附近，不要大幅增加

原始书评：
{review_text}

请直接输出润色后的书评，不需要解释修改内容。"""

    try:
        # 调用 AI 润色
        polished = chat(prompt)
        return {
            'original': review_text,
            'polished': polished,
            'success': True,
        }
    except Exception as e:
        return {
            'original': review_text,
            'polished': None,
            'success': False,
            'error': str(e),
        }


# ==================== 页面跳转相关工具函数 ====================

def get_page_link(page_name: str) -> dict:
    """
    根据页面名称返回对应的页面 URL

    Args:
        page_name: 页面名称（支持：首页、书籍、借阅记录、成员管理、个人中心、设置）

    Returns:
        dict: 包含页面名称和 URL
    """
    # 页面名称与 URL 的映射
    page_map = {
        '首页': '/',
        '书籍': '/',
        '书籍列表': '/',
        '书架': '/',
        '借阅记录': '/records/',
        '借阅': '/records/',
        '成员管理': '/family/',
        '家庭成员': '/family/',
        '个人中心': '/',
        '设置': '/',
        '书摘': '/',
        '书评': '/',
    }

    # 标准化输入（去除空格）
    normalized_name = page_name.strip()

    # 查找对应 URL
    url = page_map.get(normalized_name)

    if url:
        return {
            'page_name': normalized_name,
            'url': url,
            'success': True,
            'message': f'点击前往「{normalized_name}」页面',
        }
    else:
        # 模糊匹配
        for name, link in page_map.items():
            if normalized_name in name or name in normalized_name:
                return {
                    'page_name': name,
                    'url': link,
                    'success': True,
                    'message': f'找到了「{name}」页面，点击前往',
                }

        return {
            'page_name': normalized_name,
            'url': None,
            'success': False,
            'message': f'未找到「{normalized_name}」对应的页面，您可以尝试：首页、借阅记录、成员管理',
        }


def get_all_pages() -> list:
    """
    获取所有可用页面列表

    Returns:
        list: 页面列表，每项包含名称和 URL
    """
    return [
        {'name': '首页', 'url': '/', 'description': '查看所有书籍'},
        {'name': '借阅记录', 'url': '/records/', 'description': '查看借阅历史'},
        {'name': '成员管理', 'url': '/family/', 'description': '管理家庭成员'},
    ]
