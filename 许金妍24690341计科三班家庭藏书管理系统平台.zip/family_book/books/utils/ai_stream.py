# AI 流式输出客户端
# 用于流式调用豆包大模型 API

import requests
import json
from books.utils.ai_client import (
    API_KEY,
    API_URL,
    MODEL_NAME,
    TUTU_SYSTEM_PROMPT,
    recognize_intent,
    call_tool_by_intent,
)


def chat_stream(message: str, system_prompt: str = None, user_id: int = None, history: list = None):
    """
    流式调用豆包大模型进行对话

    Args:
        message: 用户输入的对话内容
        system_prompt: 自定义系统提示词（可选）
        user_id: 用户ID（可选，用于查询个人借阅信息）
        history: 历史消息列表（可选）

    Yields:
        str: 每次生成的文本片段
    """
    # ========== 第一步：识别用户意图 ==========
    intent = recognize_intent(message)

    # ========== 第二步：根据意图处理 ==========
    tool_result = None
    if intent != "chat":
        tool_result = call_tool_by_intent(intent, message, user_id)

    # ========== 第三步：构建消息发送给 AI ==========
    final_system_prompt = system_prompt if system_prompt else TUTU_SYSTEM_PROMPT

    messages = []
    messages.append({
        "role": "system",
        "content": final_system_prompt
    })

    # 添加历史消息
    if history and len(history) > 0:
        for msg in history[:-1]:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            if role == 'assistant':
                messages.append({"role": "assistant", "content": content})
            else:
                messages.append({"role": "user", "content": content})

    # 如果有工具调用结果，将结果作为上下文发送
    if tool_result and tool_result['success']:
        context = f"""用户说：{message}

【系统识别的意图】：{tool_result['intent_desc']}
【查询到的数据】：
{json.dumps(tool_result['data'], ensure_ascii=False, indent=2)}

请根据以上数据，用简洁友好的语言回答用户的问题。如果数据是列表，请用列表形式展示。如果数据为空，请友好地告诉用户暂无相关内容。"""
        messages.append({
            "role": "user",
            "content": context
        })
    else:
        messages.append({
            "role": "user",
            "content": message
        })

    # ========== 第四步：流式调用豆包 API ==========
    payload = {
        "model": MODEL_NAME,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 2000,
        "stream": True,  # 开启流式输出
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            data=json.dumps(payload),
            timeout=60,
            stream=True  # 流式接收响应
        )

        response.raise_for_status()

        # 逐行读取 SSE 数据
        for line in response.iter_lines():
            if not line:
                continue

            line = line.decode('utf-8')

            # SSE 格式：data: {...}
            if line.startswith('data:'):
                data_str = line[5:].strip()

                # 结束标志
                if data_str == '[DONE]':
                    break

                try:
                    data = json.loads(data_str)

                    # 提取生成的文本
                    if 'choices' in data and len(data['choices']) > 0:
                        delta = data['choices'][0].get('delta', {})
                        content = delta.get('content', '')

                        if content:
                            yield content

                except json.JSONDecodeError:
                    continue

    except requests.exceptions.Timeout:
        yield "抱歉，AI 响应超时，请稍后重试~"
    except requests.exceptions.RequestException as e:
        yield f"抱歉，网络出问题了：{str(e)}"
    except Exception as e:
        yield f"抱歉，出了点问题：{str(e)}"
