# 意图识别模块
# 根据用户输入判断意图类型

def recognize_intent(user_msg: str) -> str:
    """
    根据用户消息识别意图类型

    Args:
        user_msg: 用户输入的消息

    Returns:
        str: 意图类型，可能的值：
            - "search_book": 查找书籍
            - "search_borrower": 按借阅人搜索
            - "recommend_book": 推荐书籍
            - "borrow_info": 查询借阅记录/状态/统计
            - "generate_summary": 生成书摘、心得、总结
            - "organize_review": 整理书评
            - "goto_page": 跳转到某个页面
            - "chat": 普通聊天问答
    """

    # 标准化输入：转小写、去空格
    msg = user_msg.strip().lower()

    # ========== 1. 按借阅人搜索意图（优先判断） ==========
    # 关键词：谁借了、借给谁、XX借的书、查XX的借阅、XX的借阅记录
    borrower_keywords = [
        '谁借了', '借给谁', '谁借走', '被谁借', '借了什么书',
        '借的书', '名下有什么书', '手里有什么书',
        '借阅记录', '的借阅', '借了哪些', '借过哪些',
        '借书情况', '借书记录',
    ]
    for kw in borrower_keywords:
        if kw in msg:
            return "search_borrower"

    # 特别处理："查询/搜索/查看 + 人名 + 借阅"
    import re
    if re.search(r'查\w{2,4}的借阅', msg) or re.search(r'搜索\w{2,4}的借阅', msg):
        return "search_borrower"
    if re.search(r'\w{2,4}借了什么', msg) or re.search(r'\w{2,4}借了哪些', msg):
        return "search_borrower"

    # ========== 2. 查找书籍意图 ==========
    # 关键词：找书、查找、搜索、有没有、书名、哪本、作者是
    search_keywords = [
        '找书', '查找', '搜索', '有没有', '书名',
        '哪本', '作者是', '谁写的', '找一本', '帮我找',
        '查一下', '这本书', '有没有关于', '有没有叫',
        '搜', '找一下', '作者是谁', '谁写的书',
    ]
    for kw in search_keywords:
        if kw in msg:
            # 如果包含"借阅记录"，则优先按借阅人搜索
            if '借阅记录' in msg or '借书记录' in msg:
                return "search_borrower"
            return "search_book"

    # ========== 3. 推荐书籍意图 ==========
    # 关键词：推荐、介绍几本、有什么好书、适合读什么
    recommend_keywords = [
        '推荐', '介绍几本', '有什么好书', '适合读什么',
        '看什么书', '有什么书', '好书', '值得看',
        '想看书', '想读', '适合我', '推荐几本',
    ]
    for kw in recommend_keywords:
        if kw in msg:
            return "recommend_book"

    # ========== 4. 借阅信息意图 ==========
    # 关键词：借阅、借了、没还、记录、统计、谁借了
    borrow_keywords = [
        '借阅', '借了', '没还', '借书记录', '借阅记录',
        '统计', '借给谁', '还书', '借了多久',
        '借了几本', '还了几本', '借书情况', '未归还',
        '欠书', '超期', '逾期', '我的借阅',
    ]
    for kw in borrow_keywords:
        if kw in msg:
            return "borrow_info"

    # ========== 5. 生成书摘/心得意图 ==========
    # 关键词：书摘、心得、总结、摘录、读后感
    summary_keywords = [
        '书摘', '心得', '总结', '摘录', '读后感',
        '读书笔记', '精彩片段', '摘抄', '概括',
        '帮我写', '生成', '读书心得',
    ]
    for kw in summary_keywords:
        if kw in msg:
            # 区分：如果包含"书评"相关，可能是整理书评
            if '书评' in msg or '润色' in msg:
                return "organize_review"
            return "generate_summary"

    # ========== 6. 整理书评意图 ==========
    # 关键词：书评、润色、整理、修改、帮我改
    review_keywords = [
        '书评', '润色', '整理一下', '修改', '帮我改',
        '改一下', '优化', '写得更好',
    ]
    for kw in review_keywords:
        if kw in msg:
            return "organize_review"

    # ========== 7. 跳转页面意图 ==========
    # 关键词：去、跳转、打开、页面、进入
    goto_keywords = [
        '去首页', '去书籍', '去借阅', '去成员', '去设置',
        '跳转到', '打开', '进入', '带我去', '去个人',
        '页面在哪', '怎么去', '我想去',
    ]
    for kw in goto_keywords:
        if kw in msg:
            return "goto_page"

    # ========== 8. 默认：普通聊天 ==========
    return "chat"


def get_intent_description(intent: str) -> str:
    """
    获取意图类型的中文描述

    Args:
        intent: 意图类型

    Returns:
        str: 意图的中文描述
    """
    descriptions = {
        "search_book": "查找书籍",
        "search_borrower": "按借阅人搜索",
        "recommend_book": "推荐书籍",
        "borrow_info": "查询借阅信息",
        "generate_summary": "生成书摘/心得",
        "organize_review": "整理书评",
        "goto_page": "跳转页面",
        "chat": "普通聊天",
    }
    return descriptions.get(intent, "未知意图")


# ==================== 测试用例 ====================
if __name__ == "__main__":
    # 测试意图识别
    test_cases = [
        "帮我找一本关于Python的书",
        "推荐几本适合小学生看的书",
        "我借了哪些书还没还",
        "帮我写一段读书心得",
        "帮我润色一下这段书评",
        "带我去借阅记录页面",
        "你好，图图",
        "这本书作者是谁",
        "有没有适合孩子看的科普书",
        "谁借走了《三体》",
    ]

    print("=== 意图识别测试 ===\n")
    for msg in test_cases:
        intent = recognize_intent(msg)
        desc = get_intent_description(intent)
        print(f"输入: {msg}")
        print(f"意图: {intent} ({desc})")
        print("-" * 40)
