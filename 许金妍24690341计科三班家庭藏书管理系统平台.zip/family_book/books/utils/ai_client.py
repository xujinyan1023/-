# 豆包 API 客户端
# 用于对接豆包大模型 API，整合意图识别和工具调用

import requests
import json

# 导入意图识别模块
from books.utils.intent_recognize import recognize_intent, get_intent_description

# 导入工具函数模块
from books.utils.tools import (
    search_books,
    smart_search_books,
    search_by_borrower,
    get_book_detail,
    recommend_books,
    get_user_borrow_records,
    get_borrow_status,
    get_borrow_stats,
    generate_book_summary,
    organize_review,
    get_page_link,
)

# ==================== 配置区域 ====================
# 请将下面的占位符替换为你的真实配置

# 豆包 API Key（从火山引擎控制台获取）
API_KEY = "ark-0a96dcda-7e41-417e-be8a-cdcb983e01c7-f793c"

# 豆包 API 接口地址（根据实际 endpoint 填写）
API_URL = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"

# 使用的模型名称（根据你在火山引擎部署的模型填写）
MODEL_NAME = "doubao-seed-2-0-pro-260215"

# ==================================================


# ==================== 图图身份设定 ====================
# 图图的专属系统提示词，定义其身份和能力

TUTU_SYSTEM_PROMPT = """你是"图图"，一个活泼可爱的家庭图书管理系统专属 AI 助手。

【你的身份】
- 你叫图图，是家庭图书管理系统的智能小助手
- 你服务于家庭成员，帮助孩子和家长更好地管理图书、享受阅读

【你能做的事情】
📚 推荐书籍：根据年龄、兴趣、阅读水平推荐适合孩子的书籍
💡 解答问题：解答书中知识点、回答阅读相关问题
📝 生成书摘：帮助提取书中的精彩片段和重点内容
💭 阅读心得：帮助总结阅读收获、整理读书感悟
📖 书评整理：帮助撰写或整理书籍评价

【你可以帮用户】
- 找书：根据书名、作者、分类查找书籍
- 推荐书：根据用户喜好推荐好书
- 查借阅：查询当前借阅状态、谁借了哪本书
- 查记录：查看借阅历史记录
- 看统计：了解阅读数据、借阅排行
- 跳页面：引导用户前往书籍、书架、借阅记录等页面

【你的说话风格】
- 简洁友好，像朋友一样聊天
- 口语化表达，不要太官方、太书面
- 可以用一些可爱的语气词，比如"好的呀~""没问题！"
- 适当使用表情符号，让对话更生动

【重要规则】
- 只围绕图书、阅读、家庭图书系统相关内容回答
- 不要聊与图书无关的话题，礼貌地引导用户回到主题
- 如果被问到无关问题，可以说"这个我不太懂呢，我们聊聊书吧~"
- 对于敏感话题，保持中立并引导到图书话题
"""


# ==================== 工具调用处理 ====================

def call_tool_by_intent(intent: str, user_msg: str, user_id: int = None) -> dict:
    """
    根据意图调用对应的工具函数

    Args:
        intent: 意图类型
        user_msg: 用户原始消息
        user_id: 用户ID（可选，用于查询个人借阅信息）

    Returns:
        dict: 工具调用结果
    """
    result = {
        'intent': intent,
        'intent_desc': get_intent_description(intent),
        'data': None,
        'success': False,
    }

    try:
        # ========== 查找书籍 ==========
        if intent == "search_book":
            # 从用户消息中提取关键词
            keyword = extract_search_keyword(user_msg)
            if not keyword:
                # 如果提取失败，用整个消息作为关键词（去除常见词）
                keyword = user_msg.replace('书', '').replace('的', '').replace('搜索', '').replace('查找', '').replace('找', '').strip()

            # 使用智能搜索（支持错别字纠错）
            search_result = smart_search_books(keyword)
            result['data'] = {
                'books': search_result.get('books', []),
                'correction': search_result.get('correction'),
                'original_keyword': search_result.get('original_keyword'),
                'corrected_keyword': search_result.get('corrected_keyword'),
            }
            result['success'] = True

        # ========== 按借阅人搜索 ==========
        elif intent == "search_borrower":
            # 提取借阅人姓名
            borrower_name = extract_borrower_name(user_msg)
            if borrower_name:
                search_result = search_by_borrower(borrower_name)

                # 构建友好的返回数据
                if search_result.get('records'):
                    # 找到了记录
                    result['data'] = {
                        'records': search_result['records'],
                        'total': search_result.get('total', len(search_result['records'])),
                        'matched_name': search_result.get('matched_name'),
                        'correction': search_result.get('correction'),
                    }
                else:
                    # 没找到记录
                    result['data'] = {
                        'records': [],
                        'correction': search_result.get('correction', f'未找到「{borrower_name}」的借阅记录'),
                        'all_borrowers': search_result.get('all_borrowers', []),
                    }
                result['success'] = True
            else:
                # 没能提取出姓名，返回所有借阅人列表
                from books.utils.tools import get_all_borrower_names
                all_names = get_all_borrower_names()
                result['data'] = {
                    'message': '请告诉我您要查询哪位借阅人的信息~',
                    'available_borrowers': all_names[:10],
                }
                result['success'] = True

        # ========== 推荐书籍 ==========
        elif intent == "recommend_book":
            # 提取年龄和分类
            age = extract_age(user_msg)
            category = extract_category(user_msg)
            result['data'] = recommend_books(age=age, category=category, limit=5)
            result['success'] = True

        # ========== 查询借阅信息 ==========
        elif intent == "borrow_info":
            if user_id:
                # 查询用户的借阅统计
                result['data'] = get_borrow_stats(user_id)
                result['success'] = True
            else:
                # 没有用户ID时，返回提示
                result['data'] = {'message': '请先登录后查看借阅信息'}
                result['success'] = True

        # ========== 生成书摘/心得 ==========
        elif intent == "generate_summary":
            # 提取书名
            book_title = extract_book_title(user_msg)
            if book_title:
                result['data'] = generate_book_summary(book_title)
                result['success'] = True
            else:
                result['data'] = {'message': '请告诉我书名，我来帮你生成书摘~'}
                result['success'] = True

        # ========== 整理书评 ==========
        elif intent == "organize_review":
            # 提取书评内容
            review_text = user_msg.replace('书评', '').replace('润色', '').replace('整理', '')
            if len(review_text) > 5:
                result['data'] = organize_review(review_text)
                result['success'] = True
            else:
                result['data'] = {'message': '请把你要整理的书评发给我~'}
                result['success'] = True

        # ========== 跳转页面 ==========
        elif intent == "goto_page":
            page_name = extract_page_name(user_msg)
            result['data'] = get_page_link(page_name)
            result['success'] = True

    except Exception as e:
        result['data'] = {'error': str(e)}
        result['success'] = False

    return result


# ==================== 辅助提取函数 ====================

def extract_search_keyword(msg: str) -> str:
    """从消息中提取搜索关键词"""
    # 常见的触发词
    triggers = [
        '搜索', '查找', '找一下', '找', '有没有', '书名是',
        '作者是', '谁写的', '帮我找', '查一下', '有没有叫',
        '搜一下', '查', '关于', '叫', '署名是',
    ]

    for trigger in triggers:
        if trigger in msg:
            idx = msg.find(trigger) + len(trigger)
            keyword = msg[idx:].strip()
            # 清理常见的干扰词
            keyword = keyword.replace('的书', '').replace('的书吗', '').replace('吗', '').replace('呢', '').strip()
            if keyword and len(keyword) > 0:
                return keyword

    return None


def extract_borrower_name(msg: str) -> str:
    """从消息中提取借阅人姓名"""
    import re

    # 清理消息，去除标点符号干扰
    msg_clean = msg.replace('？', '').replace('?', '').replace('。', '').replace('，', '')

    # 模式匹配（按优先级排序）
    patterns = [
        # "查询/搜索/查找 某人 的借阅记录"
        r'查询?(\w{2,4})的借阅记录',
        r'搜索?(\w{2,4})的借阅记录',
        r'查找?(\w{2,4})的借阅记录',
        r'查一下(\w{2,4})的借阅记录',
        r'帮[我助]?查(\w{2,4})的借阅记录',
        r'看[一下]?(\w{2,4})的借阅记录',
        r'(\w{2,4})的借阅记录',
        # "某人 借了什么书/借了哪些书"
        r'(\w{2,4})借了什么',
        r'(\w{2,4})借了哪些',
        r'(\w{2,4})借过什么',
        r'(\w{2,4})借过哪些',
        # "某人 手里/名下 有什么书"
        r'(\w{2,4})手里有',
        r'(\w{2,4})名下有',
        r'(\w{2,4})借的书',
        # "查某人的借阅"
        r'查(\w{2,4})的借阅',
        # "某人借书/借书情况"
        r'(\w{2,4})借书',
        # 简单的名字提取（最后尝试）
        r'查(\w{2,4})',
        r'搜(\w{2,4})',
    ]

    for pattern in patterns:
        match = re.search(pattern, msg_clean)
        if match:
            name = match.group(1)
            # 过滤掉一些常见的干扰词
            exclude_words = ['什么', '哪些', '书名', '作者', '书籍', '记录', '一下', '我', '我们', '你们', '他们']
            if name not in exclude_words:
                return name

    return None


def extract_keyword(msg: str, triggers: list) -> str:
    """从消息中提取搜索关键词"""
    for trigger in triggers:
        if trigger in msg:
            idx = msg.find(trigger) + len(trigger)
            return msg[idx:].strip()
    return None


def extract_age(msg: str) -> int:
    """从消息中提取年龄"""
    import re
    # 匹配 "X岁" 或 "X岁孩子" 等模式
    match = re.search(r'(\d+)\s*岁', msg)
    if match:
        return int(match.group(1))
    return None


def extract_category(msg: str) -> str:
    """从消息中提取书籍分类"""
    categories = ['科普', '文学', '历史', '绘本', '故事', '科幻', '小说', '童话', '冒险', '自然科学']
    for cat in categories:
        if cat in msg:
            return cat
    return None


def extract_book_title(msg: str) -> str:
    """从消息中提取书名"""
    import re
    # 匹配《书名》格式
    match = re.search(r'《(.+?)》', msg)
    if match:
        return match.group(1)
    return None


def extract_page_name(msg: str) -> str:
    """从消息中提取页面名称"""
    page_names = ['首页', '书籍', '借阅记录', '成员管理', '个人中心', '设置', '书架']
    for name in page_names:
        if name in msg:
            return name
    # 如果没找到明确页面名，返回消息中的关键词
    return msg.replace('去', '').replace('打开', '').replace('进入', '').strip()


# ==================== 核心对话函数 ====================

def chat(message: str, system_prompt: str = None, user_id: int = None, history: list = None) -> str:
    """
    调用豆包大模型进行对话，自动识别意图并调用工具

    Args:
        message: 用户输入的对话内容
        system_prompt: 自定义系统提示词（可选，默认使用图图身份）
        user_id: 用户ID（可选，用于查询个人借阅信息）
        history: 历史消息列表（可选，格式: [{"role": "user/assistant", "content": "..."}]）

    Returns:
        str: AI 的回复内容

    Raises:
        Exception: API 调用失败时抛出异常
    """

    # ========== 第一步：识别用户意图 ==========
    intent = recognize_intent(message)

    # ========== 第二步：根据意图处理 ==========
    tool_result = None

    # 如果是系统操作类意图，调用工具获取数据
    if intent != "chat":
        tool_result = call_tool_by_intent(intent, message, user_id)

    # ========== 第三步：构建消息发送给 AI ==========
    final_system_prompt = system_prompt if system_prompt else TUTU_SYSTEM_PROMPT

    messages = []
    messages.append({
        "role": "system",
        "content": final_system_prompt
    })

    # 添加历史消息（排除当前消息，因为当前消息已经在 history 中）
    if history and len(history) > 0:
        # 只取最近的历史消息，避免上下文过长
        # 排除最后一条（当前消息），因为我们会单独处理
        for msg in history[:-1]:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            # 将前端的 'assistant' 转换为 API 的 'assistant'
            if role == 'assistant':
                messages.append({"role": "assistant", "content": content})
            else:
                messages.append({"role": "user", "content": content})

    # 如果有工具调用结果，将结果作为上下文发送
    if tool_result and tool_result['success']:
        # 构建包含工具结果的提示
        context = f"""用户说：{message}

【系统识别的意图】：{tool_result['intent_desc']}
【查询到的数据】：
{json.dumps(tool_result['data'], ensure_ascii=False, indent=2)}

请根据以上数据，用简洁友好的语言回答用户的问题。如果数据是列表，请用列表形式展示。如果数据为空，请友好地告诉用户暂无相关内容。"""
        messages.append({
            "role": "user",
            "content": context
        })
    else:
        # 普通聊天，直接发送用户消息
        messages.append({
            "role": "user",
            "content": message
        })

    # ========== 第四步：调用豆包 API ==========
    payload = {
        "model": MODEL_NAME,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 2000,
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            data=json.dumps(payload),
            timeout=30
        )

        response.raise_for_status()
        result = response.json()
        reply = result["choices"][0]["message"]["content"]

        return reply

    except requests.exceptions.Timeout:
        raise Exception("API 请求超时，请稍后重试")
    except requests.exceptions.RequestException as e:
        raise Exception(f"API 请求失败: {str(e)}")
    except (KeyError, IndexError) as e:
        raise Exception(f"API 响应格式错误: {str(e)}")


# ==================== 简单对话接口（不调用工具） ====================

def simple_chat(message: str, system_prompt: str = None) -> str:
    """
    简单对话接口，不进行意图识别和工具调用

    Args:
        message: 用户输入的对话内容
        system_prompt: 自定义系统提示词

    Returns:
        str: AI 的回复内容
    """
    final_system_prompt = system_prompt if system_prompt else TUTU_SYSTEM_PROMPT

    messages = [
        {"role": "system", "content": final_system_prompt},
        {"role": "user", "content": message}
    ]

    payload = {
        "model": MODEL_NAME,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 2000,
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            data=json.dumps(payload),
            timeout=30
        )

        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]

    except requests.exceptions.Timeout:
        raise Exception("API 请求超时，请稍后重试")
    except requests.exceptions.RequestException as e:
        raise Exception(f"API 请求失败: {str(e)}")
    except (KeyError, IndexError) as e:
        raise Exception(f"API 响应格式错误: {str(e)}")


# ==================== 测试用例 ====================
if __name__ == "__main__":
    print("=== 图图 AI 测试 ===\n")

    test_cases = [
        "帮我找一本关于Python的书",
        "推荐几本适合8岁孩子看的科普书",
        "我借了哪些书",
        "帮我写一段《小王子》的读书心得",
        "打开借阅记录页面",
        "你好，图图",
    ]

    for msg in test_cases:
        print(f"用户: {msg}")
        intent = recognize_intent(msg)
        print(f"意图: {intent} ({get_intent_description(intent)})")

        try:
            reply = chat(msg)
            print(f"图图: {reply}")
        except Exception as e:
            print(f"错误: {e}")

        print("-" * 50)
