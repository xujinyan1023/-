from django.contrib import admin
from .models import Book, Reader, BorrowRecord, UserProfile, ShelfLocation, BookComment, BookNote, Category, RecentLogin, ChatMessage, Notification, OperationLog, BookCommentLike, ReadingCheckIn, UserBadge


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'sort_order', 'created_at']
    ordering = ['sort_order', 'name']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['book_name', 'author', 'isbn', 'status', 'book_type', 'place']
    list_filter = ['status', 'book_type']
    search_fields = ['book_name', 'author', 'isbn']


@admin.register(Reader)
class ReaderAdmin(admin.ModelAdmin):
    list_display = ['reader_name']


@admin.register(BorrowRecord)
class BorrowRecordAdmin(admin.ModelAdmin):
    list_display = ['book', 'borrower_name', 'borrow_date', 'return_date', 'is_returned']
    list_filter = ['is_returned']
    search_fields = ['book__book_name', 'borrower_name']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'reader', 'phone']
    list_filter = ['role']
    search_fields = ['user__username', 'phone']


@admin.register(RecentLogin)
class RecentLoginAdmin(admin.ModelAdmin):
    list_display = ['user', 'last_login', 'token_expires', 'password_verified_at', 'switch_count']
    search_fields = ['user__username']


@admin.register(ShelfLocation)
class ShelfLocationAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'created_at']


@admin.register(BookComment)
class BookCommentAdmin(admin.ModelAdmin):
    list_display = ['book', 'user', 'created_at']
    search_fields = ['book__book_name', 'user__username']


@admin.register(BookNote)
class BookNoteAdmin(admin.ModelAdmin):
    list_display = ['book', 'user', 'note_type', 'title', 'created_at']
    list_filter = ['note_type']
    search_fields = ['book__book_name', 'title']


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'created_at', 'content_preview']
    list_filter = ['role', 'created_at']
    search_fields = ['user__username', 'content']
    ordering = ['-created_at']

    def content_preview(self, obj):
        return obj.content[:50] + '...' if len(obj.content) > 50 else obj.content
    content_preview.short_description = '内容预览'


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['user', 'notification_type', 'title', 'is_read', 'created_at']
    list_filter = ['notification_type', 'is_read', 'created_at']
    search_fields = ['user__username', 'title', 'content']
    ordering = ['-created_at']


@admin.register(OperationLog)
class OperationLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'action', 'target_name', 'ip_address', 'created_at']
    list_filter = ['action', 'created_at']
    search_fields = ['user__username', 'target_name', 'detail']
    ordering = ['-created_at']


@admin.register(BookCommentLike)
class BookCommentLikeAdmin(admin.ModelAdmin):
    list_display = ['comment', 'user', 'created_at']
    search_fields = ['comment__book__book_name', 'user__username']
    ordering = ['-created_at']


@admin.register(ReadingCheckIn)
class ReadingCheckInAdmin(admin.ModelAdmin):
    list_display = ['user', 'checkin_date', 'created_at']
    list_filter = ['checkin_date']
    search_fields = ['user__username']
    ordering = ['-checkin_date']


@admin.register(UserBadge)
class UserBadgeAdmin(admin.ModelAdmin):
    list_display = ['user', 'badge_type', 'earned_at']
    list_filter = ['badge_type']
    search_fields = ['user__username']
    ordering = ['-earned_at']
