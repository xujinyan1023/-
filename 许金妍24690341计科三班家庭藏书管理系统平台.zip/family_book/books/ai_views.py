# AI 聊天视图
# 提供与 AI 对话的接口

import json
from django.http import JsonResponse, HttpResponse, StreamingHttpResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

from books.utils.ai_client import chat
from books.utils.ai_stream import chat_stream
from books.utils.tts import text_to_speech
from books.models import ChatMessage


@csrf_exempt
@require_http_methods(["POST"])
def chat_with_tutu(request):
    """
    与图图（图书助手）对话的接口

    请求:
        POST /api/ai/chat/
        Body: {"message": "用户的消息", "history": [{"role": "user/assistant", "content": "..."}]}

    响应:
        成功: {"success": true, "reply": "AI的回复内容"}
        失败: {"success": false, "error": "错误信息"}
    """

    try:
        # 解析请求体
        data = json.loads(request.body)

        # 获取用户消息
        message = data.get("message", "").strip()

        # 获取历史消息（可选）
        history = data.get("history", [])

        # 验证消息不为空
        if not message:
            return JsonResponse({
                "success": False,
                "error": "请输入消息内容"
            })

        # 获取当前登录用户ID（如果已登录）
        user_id = None
        if request.user.is_authenticated:
            user_id = request.user.id

        # 调用 AI 客户端获取回复（自动进行意图识别和工具调用）
        reply = chat(message, user_id=user_id, history=history)

        # 返回成功响应
        return JsonResponse({
            "success": True,
            "reply": reply
        })

    except json.JSONDecodeError:
        return JsonResponse({
            "success": False,
            "error": "请求格式错误"
        })

    except Exception as e:
        # 捕获所有异常，返回友好提示
        return JsonResponse({
            "success": False,
            "error": "AI 服务暂时不可用，请稍后重试"
        })


@csrf_exempt
@require_http_methods(["POST"])
def chat_stream_view(request):
    """
    流式对话接口 - 逐字输出 AI 回复

    请求:
        POST /api/ai/chat/stream/
        Body: {"message": "用户的消息", "history": [...]}

    响应:
        Server-Sent Events (SSE) 格式的流式数据
        data: {"content": "文本片段"}
        data: [DONE]
    """

    try:
        # 解析请求体
        data = json.loads(request.body)

        # 获取用户消息
        message = data.get("message", "").strip()

        # 获取历史消息（可选）
        history = data.get("history", [])

        # 验证消息不为空
        if not message:
            return JsonResponse({
                "success": False,
                "error": "请输入消息内容"
            })

        # 获取当前登录用户
        user = request.user if request.user.is_authenticated else None
        user_id = user.id if user else None

        # 保存用户消息到数据库
        if user:
            ChatMessage.objects.create(
                user=user,
                role='user',
                content=message
            )

        # 用于累积完整回复
        full_reply = []

        # 创建流式响应生成器
        def generate():
            nonlocal full_reply
            try:
                for chunk in chat_stream(message, user_id=user_id, history=history):
                    full_reply.append(chunk)
                    # SSE 格式：data: {...}
                    yield f"data: {json.dumps({'content': chunk}, ensure_ascii=False)}\n\n"

                # 发送结束标志
                yield "data: [DONE]\n\n"

                # 保存AI回复到数据库
                if user and full_reply:
                    ChatMessage.objects.create(
                        user=user,
                        role='assistant',
                        content=''.join(full_reply)
                    )

            except Exception as e:
                yield f"data: {json.dumps({'error': str(e)}, ensure_ascii=False)}\n\n"

        # 返回流式响应
        response = StreamingHttpResponse(
            generate(),
            content_type='text/event-stream'
        )
        response['Cache-Control'] = 'no-cache'
        response['X-Accel-Buffering'] = 'no'  # 禁用 nginx 缓冲

        return response

    except json.JSONDecodeError:
        return JsonResponse({
            "success": False,
            "error": "请求格式错误"
        })

    except Exception as e:
        return JsonResponse({
            "success": False,
            "error": "AI 服务暂时不可用，请稍后重试"
        })


# ========== 聊天记录管理 API ==========

@login_required
@require_http_methods(["GET"])
def get_chat_history(request):
    """
    获取用户的聊天历史记录

    请求:
        GET /api/ai/chat/history/

    响应:
        {"success": true, "messages": [...]}
    """
    try:
        # 获取最近50条消息
        messages = ChatMessage.objects.filter(user=request.user)[:50]

        data = [{
            'id': msg.id,
            'role': msg.role,
            'content': msg.content,
            'created_at': msg.created_at.strftime('%Y-%m-%d %H:%M:%S')
        } for msg in messages]

        return JsonResponse({
            'success': True,
            'messages': data
        })

    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


@login_required
@require_http_methods(["POST"])
def clear_chat_history(request):
    """
    清空用户的聊天历史记录

    请求:
        POST /api/ai/chat/history/clear/

    响应:
        {"success": true, "deleted_count": N}
    """
    try:
        deleted_count, _ = ChatMessage.objects.filter(user=request.user).delete()

        return JsonResponse({
            'success': True,
            'deleted_count': deleted_count
        })

    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


@csrf_exempt
@require_http_methods(["POST"])
def tts_speak(request):
    """
    语音合成接口 - 将文本转换为语音

    请求:
        POST /api/ai/tts/
        Body: {"text": "要朗读的文本"}

    响应:
        成功: {"success": true, "audio": "base64音频数据", "format": "mp3"}
        失败: {"success": false, "error": "错误信息", "fallback": true}
    """
    try:
        data = json.loads(request.body)
        text = data.get("text", "").strip()

        if not text:
            return JsonResponse({
                "success": False,
                "error": "文本不能为空"
            })

        # 调用 TTS 服务
        result = text_to_speech(text)

        return JsonResponse(result)

    except json.JSONDecodeError:
        return JsonResponse({
            "success": False,
            "error": "请求格式错误"
        })
    except Exception as e:
        return JsonResponse({
            "success": False,
            "error": f"语音合成失败: {str(e)}",
            "fallback": True
        })
