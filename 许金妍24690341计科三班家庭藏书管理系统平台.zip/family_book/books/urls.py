 # 导入Django的路径工具
from django.urls import path
# 导入我们刚写的所有视图函数
from . import views
from . import ai_views

# +++++++++++ 这两行是你必须加的！解决图片显示问题 +++++++++++
from django.conf import settings
from django.conf.urls.static import static
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# 配置 网址 → 函数 的对应关系
urlpatterns = [
    # 首页（空地址）→ 图书列表函数
    path("", views.book_list, name="book_list"),
    # 登录/注册
    path("login/", views.login_view, name="login"),
    path("register/", views.register_view, name="register"),
    path("logout/", views.logout_view, name="logout"),
    path("change-password/", views.change_password_view, name="change_password"),
    # /add/ → 录入新书函数
    path("add/", views.book_add, name="book_add"),
    # /search/ → 搜索图书函数
    path("search/", views.book_search, name="search"),
    # /borrow/数字/ → 借还书函数
    path("borrow/<int:book_id>/", views.borrow_return, name="borrow_return"),
    # /records/ → 借阅记录函数
    path("records/", views.borrow_list, name="borrow_list"),
    path("records/delete/<int:record_id>/", views.borrow_record_delete, name="borrow_record_delete"),
    path("edit/<int:book_id>/", views.book_edit, name="book_edit"),
    path("delete/<int:book_id>/", views.book_delete, name="book_delete"),
    path("family/", views.family_list, name="family_list"),
    path("family/add/", views.family_add, name="family_add"),
    path("family/delete/<int:member_id>/", views.family_delete, name="family_delete"),
    # API 路由
    path("api/books/", views.api_books_list, name="api_books_list"),
    path("api/books/search/", views.api_books_search, name="api_books_search"),
    path("api/books/borrow-counts/", views.api_books_borrow_counts, name="api_books_borrow_counts"),
    path("api/book/<int:book_id>/", views.api_update_book, name="api_update_book"),
    path("api/users/", views.api_users_list, name="api_users_list"),
    path("api/book/isbn/<str:isbn>/", views.api_book_by_isbn, name="api_book_by_isbn"),
    path("api/book/search/", views.api_book_search, name="api_book_search"),
    # 书架位置管理
    path("api/shelf/locations/", views.api_shelf_locations, name="api_shelf_locations"),
    path("api/shelf/location/add/", views.api_shelf_location_add, name="api_shelf_location_add"),
    path("api/shelf/location/edit/<int:loc_id>/", views.api_shelf_location_edit, name="api_shelf_location_edit"),
    path("api/shelf/location/delete/<int:loc_id>/", views.api_shelf_location_delete, name="api_shelf_location_delete"),
    # 借阅统计
    path("api/borrow/statistics/", views.api_borrow_statistics, name="api_borrow_statistics"),
    path("api/borrow/fix-names/", views.api_fix_borrower_names, name="api_fix_borrower_names"),
    # 书籍评论
    path("api/book/<int:book_id>/comments/", views.api_book_comments, name="api_book_comments"),
    path("api/book/<int:book_id>/comment/add/", views.api_book_comment_add, name="api_book_comment_add"),
    path("api/comment/<int:comment_id>/delete/", views.api_book_comment_delete, name="api_book_comment_delete"),
    # 书摘书评
    path("api/notes/", views.api_book_notes, name="api_book_notes"),
    path("api/note/add/", views.api_book_note_add, name="api_book_note_add"),
    path("api/note/<int:note_id>/delete/", views.api_book_note_delete, name="api_book_note_delete"),
    # 图书分类
    path("api/categories/", views.api_categories_list, name="api_categories_list"),
    path("api/category/add/", views.api_category_add, name="api_category_add"),
    path("api/category/edit/<int:category_id>/", views.api_category_edit, name="api_category_edit"),
    path("api/category/delete/<int:category_id>/", views.api_category_delete, name="api_category_delete"),
    # 书籍借阅信息
    path("api/book/<int:book_id>/borrow-info/", views.api_book_borrow_info, name="api_book_borrow_info"),
    # 快速登录
    path("api/recent-logins/", views.api_recent_logins, name="api_recent_logins"),
    path("api/quick-login/", views.api_quick_login, name="api_quick_login"),
    # 用户账户信息
    path("api/user/info/", views.api_user_info, name="api_user_info"),
    path("api/user/update-name/", views.api_update_display_name, name="api_update_display_name"),
    path("api/user/update-phone/", views.api_update_phone, name="api_update_phone"),
    path("api/user/upload-avatar/", views.api_upload_avatar, name="api_upload_avatar"),
    # 管理员管理成员
    path("api/members/", views.api_members_list, name="api_members_list"),
    path("api/member/<int:user_id>/update/", views.api_member_update, name="api_member_update"),
    path("api/member/<int:user_id>/reset-password/", views.api_member_reset_password, name="api_member_reset_password"),
    path("api/member/<int:user_id>/delete/", views.api_member_delete, name="api_member_delete"),
    # 借阅人列表（用于筛选）
    path("api/borrowers/", views.api_borrowers_list, name="api_borrowers_list"),
    # 搜索借阅记录
    path("api/borrow-records/search/", views.api_borrow_records_search, name="api_borrow_records_search"),
    # 借阅提醒
    path("api/borrow/reminders/", views.api_borrow_reminders, name="api_borrow_reminders"),
    # 借阅图表数据
    path("api/borrow/chart-data/", views.api_borrow_chart_data, name="api_borrow_chart_data"),
    # 导入导出书单
    path("api/books/export/", views.api_export_books, name="api_export_books"),
    path("api/books/import/", views.api_import_books, name="api_import_books"),
    path("api/books/template/", views.api_download_template, name="api_download_template"),
    # AI 聊天
    path("api/ai/chat/", ai_views.chat_with_tutu, name="ai_chat"),
    # AI 流式聊天
    path("api/ai/chat/stream/", ai_views.chat_stream_view, name="ai_chat_stream"),
    # AI 聊天历史记录
    path("api/ai/chat/history/", ai_views.get_chat_history, name="ai_chat_history"),
    path("api/ai/chat/history/clear/", ai_views.clear_chat_history, name="ai_chat_history_clear"),
    # AI 语音合成
    path("api/ai/tts/", ai_views.tts_speak, name="ai_tts"),
    # 通知提醒
    path("api/notifications/", views.api_notifications_list, name="api_notifications_list"),
    path("api/notification/<int:notification_id>/read/", views.api_notification_read, name="api_notification_read"),
    path("api/notifications/read-all/", views.api_notification_read_all, name="api_notification_read_all"),
    path("api/check-due-reminders/", views.api_check_due_reminders, name="api_check_due_reminders"),
    # 数据库备份
    path("api/database/backup/", views.api_database_backup, name="api_database_backup"),
    # 操作日志
    path("api/operation-logs/", views.api_operation_logs, name="api_operation_logs"),
    # 批量操作
    path("api/batch/borrow/", views.api_batch_borrow, name="api_batch_borrow"),
    path("api/batch/return/", views.api_batch_return, name="api_batch_return"),
    path("api/batch/delete-books/", views.api_batch_delete_books, name="api_batch_delete_books"),
    # 阅读统计报表
    path("api/reading/statistics/", views.api_reading_statistics, name="api_reading_statistics"),
    path("api/reading/report/", views.api_reading_report, name="api_reading_report"),
    # 书籍二维码
    path("api/book/<int:book_id>/qrcode/", views.api_book_qrcode, name="api_book_qrcode"),
    # 书评点赞
    path("api/comment/<int:comment_id>/like/", views.api_comment_like, name="api_comment_like"),
    path("api/comment/<int:comment_id>/likes/", views.api_comment_likes, name="api_comment_likes"),
    # 阅读打卡
    path("api/checkin/", views.api_checkin, name="api_checkin"),
    path("api/checkin/status/", views.api_checkin_status, name="api_checkin_status"),
    path("api/badges/", views.api_user_badges, name="api_user_badges"),
]

# +++++++++++ 最后再加这一行！让媒体文件生效 +++++++++++
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)