from django import forms
from .models import Book, Reader


class BookForm(forms.ModelForm):
    """书籍表单验证"""

    class Meta:
        model = Book
        fields = ['book_name', 'author', 'isbn', 'book_type', 'place', 'description', 'cover']
        widgets = {
            'book_name': forms.TextInput(attrs={'class': 'form-control', 'required': True}),
            'author': forms.TextInput(attrs={'class': 'form-control', 'required': True}),
            'isbn': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入ISBN号'}),
            'book_type': forms.Select(attrs={'class': 'form-select', 'required': True}),
            'place': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：书架第3层'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': '请输入书籍简介...'}),
        }

    def clean_book_name(self):
        name = self.cleaned_data.get('book_name', '')
        name = name.strip()
        if len(name) < 1:
            raise forms.ValidationError('书名不能为空')
        if len(name) > 255:
            raise forms.ValidationError('书名不能超过255个字符')
        return name

    def clean_author(self):
        author = self.cleaned_data.get('author', '')
        author = author.strip()
        if len(author) < 1:
            raise forms.ValidationError('作者不能为空')
        return author

    def clean_isbn(self):
        isbn = self.cleaned_data.get('isbn', '')
        if isbn:
            isbn = isbn.replace('-', '').replace(' ', '')
            if not isbn.isdigit():
                raise forms.ValidationError('ISBN只能包含数字')
            if len(isbn) not in [10, 13]:
                raise forms.ValidationError('ISBN应为10位或13位数字')
        return isbn or None


class ReaderForm(forms.ModelForm):
    """借阅人表单验证"""

    class Meta:
        model = Reader
        fields = ['reader_name']
        widgets = {
            'reader_name': forms.TextInput(attrs={'class': 'form-control', 'required': True}),
        }

    def clean_reader_name(self):
        name = self.cleaned_data.get('reader_name', '')
        name = name.strip()
        if len(name) < 1:
            raise forms.ValidationError('借阅人姓名不能为空')
        if len(name) > 50:
            raise forms.ValidationError('姓名不能超过50个字符')
        return name
