        // 数据存储
        let allBooks = [];
        let allRecords = [];
        let currentMonth = new Date();
        let currentCategory = 'all';
        let currentStatus = 'all';
        let currentShelf = 'all';
        let currentShelfStatus = 'all';
        let borrowedBookIds = new Set(); // 已借出未归还的书籍ID

        // 页面加载时初始化数据
        document.addEventListener('DOMContentLoaded', function() {
            allBooks = Array.from(document.querySelectorAll('.book-card')).map(card => ({
                id: card.dataset.bookId,
                book_name: card.dataset.bookName,
                author: card.dataset.author,
                book_type: card.dataset.bookType,
                place: card.dataset.place,
                isbn: card.dataset.isbn,
                status: card.dataset.status,
                cover: card.dataset.cover,
                description: card.dataset.description,
                borrow_count: 0 // 初始化借阅次数
            }));

            allRecords = Array.from(document.querySelectorAll('.record-item')).map(item => ({
                book_name: item.dataset.bookName,
                author: item.dataset.author,
                borrower: item.dataset.borrower,
                date: item.dataset.date,
                borrowDate: item.dataset.borrowDate,
                returnDate: item.dataset.returnDate,
                status: item.dataset.status
            }));

            // 从 Django 模板数据初始化已借出书籍ID
            if (window.djangoData && window.djangoData.borrowedBookIds) {
                window.djangoData.borrowedBookIds.forEach(id => borrowedBookIds.add(id));
            }

            // 加载借阅统计数据
            loadBorrowCountData();

            initSubNavs();
            initBookCards();
            initCalendar();
            initStatusFilter();
            initShelfStatusFilter();
            loadCategories(); // 加载动态分类
            loadShelfLocations(); // 加载自定义书架位置
            loadBorrowersList(); // 加载借阅人列表（管理员筛选用）

            // 页面加载后应用默认排序
            setTimeout(() => {
                filterBooks();
            }, 100);

            // 初始化设置页面数据
            initSettingsPage();

            // 初始化图图拖拽功能
            initDraggableBall();

            // 初始化AI对话会话（使用本地存储）
            initChatSessions();

            // 加载聊天历史记录（如果用户已登录且有服务器历史）
            if (window.djangoData && window.djangoData.currentUser) {
                // 可选：从服务器加载历史记录
                // loadChatHistory();
            }

            // 初始化主题设置
            initTheme();

            // 事件委托：处理动态内容中的关闭按钮
            document.addEventListener('click', function(e) {
                const btn = e.target.closest('.btn-close-modal');
                if (btn || (e.target.tagName === 'BUTTON' && e.target.textContent.includes('关闭'))) {
                    e.preventDefault();
                    closeScanModal();
                }
            });

            // 全局 Enter 键提交支持
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                    // 查找当前可见的弹窗中的提交按钮
                    const visibleModal = document.querySelector('.scan-modal-overlay[style*="flex"], .book-modal-overlay[style*="flex"]');
                    if (visibleModal) {
                        const submitBtn = visibleModal.querySelector('.btn-primary:not([type="button"])') ||
                                        visibleModal.querySelector('button[onclick*="submit"], button[onclick*="add"], button[onclick*="save"]');
                        if (submitBtn && e.target.tagName === 'INPUT') {
                            e.preventDefault();
                            submitBtn.click();
                        }
                    }
                }
                // ESC 键关闭弹窗
                if (e.key === 'Escape') {
                    closeBookModal();
                    closeScanModal();
                    closeShelfModal();
                }
            });
        });

        // 初始化设置页面数据
        function initSettingsPage() {
            const settingsPane = document.getElementById('settings-pane');
            if (settingsPane && settingsPane.classList.contains('active')) {
                // 加载当前用户信息
                loadUserInfo();
                // 加载打卡状态
                loadCheckinStatus();
                // 加载徽章
                loadUserBadges();
                // 如果是管理员，加载成员列表
                const membersList = document.getElementById('members-list');
                if (membersList) {
                    loadMembersList();
                }
            }
        }

        // 初始化状态筛选
        function initStatusFilter() {
            document.querySelectorAll('#status-filter-bar .status-filter-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#status-filter-bar .status-filter-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    currentStatus = this.dataset.status;
                    filterBooks();
                });
            });
        }

        // 初始化书架状态筛选
        function initShelfStatusFilter() {
            document.querySelectorAll('#shelf-status-filter-bar .status-filter-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#shelf-status-filter-bar .status-filter-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    currentShelfStatus = this.dataset.status;
                    filterShelfBooks(currentShelf);
                });
            });
        }

        // 初始化二级导航
        function initSubNavs() {
            // 书籍分类导航
            document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    currentCategory = this.dataset.category;
                    filterBooks();
                });
            });

            // 书架位置导航
            document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    filterShelfBooks(this.dataset.shelf);
                });
            });

            // 记录视图导航
            document.querySelectorAll('#records-sub-nav .sub-nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#records-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');

                    const listView = document.getElementById('records-list-view');
                    const calendarView = document.getElementById('records-calendar-view');
                    const statisticsView = document.getElementById('records-statistics-view');
                    const filterBar = document.getElementById('records-filter-bar');

                    // 隐藏所有视图
                    listView.style.display = 'none';
                    calendarView.style.display = 'none';
                    statisticsView.style.display = 'none';

                    const view = this.dataset.view;
                    if (view === 'list') {
                        listView.style.display = 'block';
                        filterBar.style.display = 'block';
                    } else if (view === 'calendar') {
                        calendarView.style.display = 'block';
                        filterBar.style.display = 'none';
                        // 初始化日期选择器并加载图表
                        initCalendarView();
                    } else if (view === 'statistics') {
                        statisticsView.style.display = 'block';
                        filterBar.style.display = 'none';
                        loadStatistics();
                        loadBorrowReminders();
                    }
                });
            });

            // 设置子标签导航
            document.querySelectorAll('#settings-sub-nav .sub-nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('#settings-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');

                    const subtab = this.dataset.subtab;
                    document.getElementById('members-sub-pane').style.display = subtab === 'members' ? 'block' : 'none';
                    document.getElementById('account-sub-pane').style.display = subtab === 'account' ? 'block' : 'none';
                    document.getElementById('data-sub-pane').style.display = subtab === 'data' ? 'block' : 'none';

                    // 加载对应数据
                    if (subtab === 'members') {
                        loadMembersList();
                    } else if (subtab === 'account') {
                        loadUserInfo();
                    }
                });
            });
        }

        // 左侧导航切换
        document.querySelectorAll('.left-sidebar .nav-item').forEach(item => {
            item.addEventListener('click', function() {
                const tab = this.dataset.tab;
                if (!tab) return;

                document.querySelectorAll('.left-sidebar .nav-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');

                const titles = {
                    'books': '📚 书籍',
                    'shelf': '📚 书架',
                    'notes': '📝 书摘书评',
                    'records': '📋 借阅记录',
                    'settings': '⚙️ 设置'
                };
                document.getElementById('page-title').textContent = titles[tab];

                document.querySelectorAll('.content-pane').forEach(pane => pane.classList.remove('active'));
                const targetPane = document.getElementById(tab + '-pane');
                if (targetPane) {
                    targetPane.classList.add('active');
                }

                // 控制浮动按钮显示
                updateFabButton(tab);

                // 初始化书架视图
                if (tab === 'shelf') {
                    filterShelfBooks('all');
                }

                // 初始化书摘书评视图
                if (tab === 'notes') {
                    loadNotes();
                    loadNotesBookFilter();
                }

                // 初始化借阅记录视图
                if (tab === 'records') {
                    initRecordsStatistics();
                    // 确保搜索栏和列表视图正确显示
                    const filterBar = document.getElementById('records-filter-bar');
                    if (filterBar) filterBar.style.display = 'block';
                    const listView = document.getElementById('records-list-view');
                    if (listView) listView.classList.remove('hidden');
                }

                // 初始化设置视图：超级管理员加载用户列表
                if (tab === 'settings') {
                    const membersList = document.getElementById('members-list');
                    if (membersList) {
                        loadMembersList();
                    }
                    // 加载当前用户账户信息
                    loadUserInfo();
                }
            });
        });

        // 根据页面更新浮动按钮
        function updateFabButton(tab) {
            const fabContainer = document.getElementById('fabContainer');
            const fabMenu = document.getElementById('fabMenu');

            if (!fabContainer) return;

            // 只在书籍和书架页面显示
            if (tab === 'books' || tab === 'shelf') {
                fabContainer.style.display = 'block';

                // 根据页面生成不同菜单
                if (tab === 'books') {
                    fabMenu.innerHTML = `
                        <div class="fab-menu-item" onclick="openBarcodeScanner()">
                            <span class="icon">📷</span>
                            <span class="text">条形码录入</span>
                        </div>
                        <div class="fab-menu-item" onclick="openISBNInput()">
                            <span class="icon">🔢</span>
                            <span class="text">ISBN录入</span>
                        </div>
                        <a href="/add/" class="fab-menu-item">
                            <span class="icon">✏️</span>
                            <span class="text">手动录入</span>
                        </a>
                    `;
                } else if (tab === 'shelf') {
                    fabMenu.innerHTML = `
                        <div class="fab-menu-item" onclick="openAddShelfModal()">
                            <span class="icon">🏠</span>
                            <span class="text">添加书架位置</span>
                        </div>
                        <div class="fab-menu-item" onclick="openManageShelfModal()">
                            <span class="icon">⚙️</span>
                            <span class="text">管理书架位置</span>
                        </div>
                    `;
                }
            } else {
                fabContainer.style.display = 'none';
            }
        }

        // 页面加载时初始化浮动按钮
        document.addEventListener('DOMContentLoaded', function() {
            updateFabButton('books');
        });

        // 综合筛选书籍（分类 + 状态）
        function filterBooks() {
            // 获取当前排序选项
            const sortSelect = document.getElementById('books-sort-select');
            const sortBy = sortSelect ? sortSelect.value : 'name_asc';

            // 先筛选书籍
            let filteredBooks = allBooks.filter(book => {
                const matchCategory = currentCategory === 'all' || book.book_type === currentCategory;
                let matchStatus = true;
                if (currentStatus !== 'all') {
                    if (currentStatus === '在架') {
                        matchStatus = book.status === '在架';
                    } else if (currentStatus === '借出') {
                        matchStatus = book.status === '借出';
                    } else if (currentStatus === '未归还') {
                        matchStatus = book.status === '借出';
                    }
                }
                return matchCategory && matchStatus;
            });

            // 排序
            if (sortBy && filteredBooks.length > 0) {
                filteredBooks.sort((a, b) => {
                    switch (sortBy) {
                        case 'name_asc':
                            return (a.book_name || '').localeCompare(b.book_name || '', 'zh-CN');
                        case 'name_desc':
                            return (b.book_name || '').localeCompare(a.book_name || '', 'zh-CN');
                        case 'author_asc':
                            return (a.author || '').localeCompare(b.author || '', 'zh-CN');
                        case 'author_desc':
                            return (b.author || '').localeCompare(a.author || '', 'zh-CN');
                        case 'borrow_count':
                            return (b.borrow_count || 0) - (a.borrow_count || 0);
                        default:
                            return 0;
                    }
                });
            }

            // 渲染筛选和排序后的书籍
            renderSortedBooks(filteredBooks);
        }

        // 检查书籍是否有借阅记录（已归还）
        function hasBorrowHistory(bookId) {
            return allRecords.some(record => {
                // 通过书名匹配（简化处理）
                const book = allBooks.find(b => b.id == bookId);
                // 只匹配已归还的记录
                return book && record.book_name === book.book_name && record.status === 'returned';
            });
        }

        // 检查书籍是否有任何借阅记录
        function hasAnyBorrowRecord(bookId) {
            const book = allBooks.find(b => b.id == bookId);
            if (!book) return false;
            return allRecords.some(record => record.book_name === book.book_name);
        }

        // 按分类筛选书籍（保留兼容）
        function filterBooksByCategory(category) {
            currentCategory = category;
            filterBooks();
        }

        // 搜索书籍（AJAX）
        function searchBooks() {
            const keyword = document.getElementById('book-search-input')?.value.trim() || '';
            const container = document.getElementById('books-list');
            if (!container) return;

            // 如果关键词为空，重新加载页面回到初始状态
            if (!keyword) {
                window.location.href = '/';
                return;
            }

            container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><p class="mt-2">搜索中...</p></div>';

            let url = `/api/books/search/?keyword=${encodeURIComponent(keyword)}`;
            if (currentCategory !== 'all') {
                url += `&category=${encodeURIComponent(currentCategory)}`;
            }
            if (currentStatus !== 'all') {
                url += `&status=${encodeURIComponent(currentStatus)}`;
            }

            fetch(url)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        if (data.books.length === 0) {
                            // 智能搜索建议
                            let suggestion = '';
                            const similarBooks = allBooks.filter(book => {
                                const name = (book.book_name || '').toLowerCase();
                                const author = (book.author || '').toLowerCase();
                                const kw = keyword.toLowerCase();
                                // 模糊匹配：包含部分关键词或发音相似
                                return name.includes(kw) || author.includes(kw) ||
                                       kw.split('').some(char => name.includes(char));
                            }).slice(0, 3);

                            if (similarBooks.length > 0) {
                                suggestion = `
                                    <div class="mt-3 p-3" style="background: #f8f9fa; border-radius: 12px;">
                                        <p class="mb-2"><strong>您是否要搜索：</strong></p>
                                        ${similarBooks.map(book => `
                                            <div class="d-flex align-items-center mb-2 p-2 bg-white rounded" style="cursor: pointer;" onclick="showBookDetailByName('${book.book_name.replace(/'/g, "\\'")}')">
                                                ${book.cover ? `<img src="${book.cover}" style="width: 40px; height: 50px; object-fit: cover; border-radius: 4px; margin-right: 10px;">` : '<span style="font-size: 24px; margin-right: 10px;">📖</span>'}
                                                <div>
                                                    <div style="font-weight: 500;">${book.book_name}</div>
                                                    <small class="text-muted">${book.author || '未知作者'}</small>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                `;
                            }

                            container.innerHTML = `
                                <div class="text-center py-5" style="color: #999;">
                                    <div style="font-size: 48px; margin-bottom: 15px;">📚</div>
                                    <h4>未找到相关书籍</h4>
                                    <p class="mt-2 text-muted">没有找到与"${keyword}"相关的书籍</p>
                                    ${suggestion}
                                    <button class="btn btn-primary mt-3" onclick="clearSearch()" style="border-radius: 20px;">
                                        🔄 显示全部书籍
                                    </button>
                                </div>
                            `;
                            return;
                        }

                        container.innerHTML = data.books.map(book => `
                            <div class="book-card" data-book-id="${book.id}"
                                 data-book-name="${book.book_name}"
                                 data-author="${book.author}"
                                 data-book-type="${book.book_type}"
                                 data-place="${book.place}"
                                 data-isbn="${book.isbn}"
                                 data-status="${book.status}"
                                 data-publisher="${book.publisher}"
                                 data-publish-date="${book.publish_date}"
                                 data-cover="${book.cover}"
                                 data-description="${book.description}"
                                 draggable="true">
                                <div class="d-flex align-items-center">
                                    ${book.cover
                                        ? `<img src="${book.cover}" class="book-cover-small" alt="${book.book_name}">`
                                        : '<div class="book-cover-small bg-secondary d-flex align-items-center justify-content-center text-white" style="width:60px;height:80px;border-radius:6px;margin-right:15px;font-size:24px;">📖</div>'
                                    }
                                    <div style="flex: 1;">
                                        <h6 class="mb-1 text-truncate" style="max-width: 200px;">${book.book_name}</h6>
                                        <small class="text-muted">作者：${book.author}</small>
                                        ${book.publisher ? `<small class="text-muted d-block">出版社：${book.publisher}</small>` : ''}
                                        <div class="mt-2">
                                            <span class="status-badge ${book.status === '借出' ? 'status-borrowed' : 'status-available'}">
                                                ${book.status === '借出' ? '已借出' : '可借阅'}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('');

                        // 更新全局数据
                        allBooks = data.books;

                        // 加载借阅次数数据后应用当前排序
                        loadBorrowCountData();
                        setTimeout(() => {
                            const sortSelect = document.getElementById('books-sort-select');
                            if (sortSelect && sortSelect.value) {
                                sortBooksList();
                            }
                        }, 500);

                        // 重新绑定点击事件
                        initBookCards();
                    } else {
                        container.innerHTML = `
                            <div class="text-center py-5" style="color: #999;">
                                <div style="font-size: 48px; margin-bottom: 15px;">⚠️</div>
                                <h4>搜索出错</h4>
                                <p class="mt-2"><a href="javascript:clearSearch()" style="color: #667eea;">清除搜索</a></p>
                            </div>
                        `;
                    }
                })
                .catch(err => {
                    console.error('搜索失败:', err);
                    container.innerHTML = `
                        <div class="text-center py-5" style="color: #999;">
                            <div style="font-size: 48px; margin-bottom: 15px;">⚠️</div>
                            <h4>搜索失败，请重试</h4>
                            <p class="mt-2"><a href="javascript:clearSearch()" style="color: #667eea;">清除搜索</a></p>
                        </div>
                    `;
                });
        }

        // 清除搜索
        function clearSearch() {
            const input = document.getElementById('book-search-input');
            if (input) input.value = '';
            window.location.href = '/';
        }

        // 书籍列表排序
        function sortBooksList() {
            // 排序时重新应用筛选，这样排序和筛选就能一起工作
            filterBooks();
        }

        // 渲染排序后的书籍列表
        function renderSortedBooks(books) {
            const container = document.getElementById('books-list');
            if (!container) return;

            if (books.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-5" style="color: #999;">
                        <div style="font-size: 48px; margin-bottom: 15px;">📚</div>
                        <h4>暂无书籍</h4>
                    </div>
                `;
                return;
            }

            container.innerHTML = books.map(book => `
                <div class="book-card" data-book-id="${book.id}"
                     data-book-name="${book.book_name}"
                     data-author="${book.author}"
                     data-book-type="${book.book_type}"
                     data-place="${book.place}"
                     data-isbn="${book.isbn}"
                     data-status="${book.status}"
                     data-publisher="${book.publisher || ''}"
                     data-publish-date="${book.publish_date || ''}"
                     data-cover="${book.cover || ''}"
                     data-description="${book.description || ''}"
                     draggable="true">
                    <div class="d-flex align-items-center">
                        ${book.cover
                            ? `<img src="${book.cover}" class="book-cover-small" alt="${book.book_name}">`
                            : '<div class="book-cover-small bg-secondary d-flex align-items-center justify-content-center text-white" style="width:60px;height:80px;border-radius:6px;margin-right:15px;font-size:24px;">📖</div>'
                        }
                        <div style="flex: 1;">
                            <h6 class="mb-1 text-truncate" style="max-width: 200px;">${book.book_name}</h6>
                            <small class="text-muted">作者：${book.author || '未知'}</small>
                            ${book.publisher ? `<small class="text-muted d-block">出版社：${book.publisher}</small>` : ''}
                            <div class="mt-2">
                                <span class="status-badge ${book.status === '借出' ? 'status-borrowed' : 'status-available'}">
                                    ${book.status === '借出' ? '已借出' : '可借阅'}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');

            // 重新绑定点击事件
            initBookCards();
        }

        // 搜索框事件监听
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('book-search-input');
            if (searchInput) {
                let bookSearchTimeout = null;

                // 回车触发搜索
                searchInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        if (bookSearchTimeout) clearTimeout(bookSearchTimeout);
                        searchBooks();
                    }
                });

                // 输入变化时自动搜索（带防抖）
                searchInput.addEventListener('input', function(e) {
                    if (bookSearchTimeout) clearTimeout(bookSearchTimeout);

                    const keyword = this.value.trim();

                    if (keyword === '') {
                        // 输入框为空时，延迟后刷新页面
                        bookSearchTimeout = setTimeout(() => {
                            // 再次确认输入框确实为空
                            if (document.getElementById('book-search-input')?.value.trim() === '') {
                                window.location.href = '/';
                            }
                        }, 500);
                    } else {
                        // 有内容时，延迟后自动搜索
                        bookSearchTimeout = setTimeout(() => {
                            searchBooks();
                        }, 500);
                    }
                });
            }
        });

        // 按位置筛选书架书籍
        function filterShelfBooks(shelf) {
            currentShelf = shelf;
            const container = document.getElementById('shelf-books-container');
            const searchInput = document.getElementById('shelf-search-input');
            const searchKeyword = searchInput ? searchInput.value.trim().toLowerCase() : '';

            let filteredBooks = [];

            // 按位置筛选
            if (shelf === 'all') {
                filteredBooks = allBooks;
            } else {
                filteredBooks = allBooks.filter(book =>
                    book.place && book.place.includes(shelf)
                );
            }

            // 按状态筛选
            if (currentShelfStatus !== 'all') {
                if (currentShelfStatus === '未归还') {
                    // 未归还 = 状态为"借出"的书
                    filteredBooks = filteredBooks.filter(book => book.status === '借出');
                } else {
                    filteredBooks = filteredBooks.filter(book => book.status === currentShelfStatus);
                }
            }

            // 按搜索关键词筛选
            if (searchKeyword) {
                filteredBooks = filteredBooks.filter(book =>
                    (book.book_name && book.book_name.toLowerCase().includes(searchKeyword)) ||
                    (book.author && book.author.toLowerCase().includes(searchKeyword))
                );
            }

            // 排序功能
            const sortSelect = document.getElementById('shelf-sort-select');
            const sortBy = sortSelect ? sortSelect.value : 'default';

            if (sortBy !== 'default' && filteredBooks.length > 0) {
                filteredBooks.sort((a, b) => {
                    switch (sortBy) {
                        case 'name_asc':
                            return (a.book_name || '').localeCompare(b.book_name || '', 'zh-CN');
                        case 'name_desc':
                            return (b.book_name || '').localeCompare(a.book_name || '', 'zh-CN');
                        case 'author_asc':
                            return (a.author || '').localeCompare(b.author || '', 'zh-CN');
                        case 'author_desc':
                            return (b.author || '').localeCompare(a.author || '', 'zh-CN');
                        case 'borrow_count':
                            return (b.borrow_count || 0) - (a.borrow_count || 0);
                        default:
                            return 0;
                    }
                });
            }

            if (filteredBooks.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-5" style="color: #999;">
                        <div style="font-size: 48px;">📚</div>
                        <h5>该位置暂无书籍</h5>
                        <p class="small mt-2">尝试调整筛选条件</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = filteredBooks.map(book => `
                <div class="book-card" data-book-id="${book.id || ''}" draggable="true"
                     data-book-name="${book.book_name || '未知书名'}"
                     data-author="${book.author || '未知作者'}"
                     data-book-type="${book.book_type || ''}"
                     data-place="${book.place || ''}"
                     data-isbn="${book.isbn || ''}"
                     data-status="${book.status || '在架'}"
                     data-cover="${book.cover || ''}"
                     data-description="${book.description || ''}">
                    <div class="d-flex align-items-center">
                        ${book.cover ? `<img src="${book.cover}" class="book-cover-small">` : '<div class="book-cover-small bg-secondary d-flex align-items-center justify-content-center text-white" style="width:60px;height:80px;border-radius:6px;margin-right:15px;font-size:24px;">📖</div>'}
                        <div style="flex: 1;">
                            <h6 class="mb-1 text-truncate" style="max-width: 200px;">${book.book_name || '未知书名'}</h6>
                            <small class="text-muted">作者：${book.author || '未知'}</small>
                            <div class="mt-2">
                                <span class="status-badge ${book.status === '借出' ? 'status-borrowed' : 'status-available'}">
                                    ${book.status === '借出' ? '已借出' : '可借阅'}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');

            initBookCards();
        }

        // 初始化书籍卡片点击事件
        function initBookCards() {
            document.querySelectorAll('.book-card[data-book-id]').forEach(card => {
                // 拖拽事件
                card.addEventListener('dragstart', function(e) {
                    this.classList.add('dragging');
                    e.dataTransfer.setData('bookId', this.dataset.bookId);
                    e.dataTransfer.effectAllowed = 'move';
                });

                card.addEventListener('dragend', function() {
                    this.classList.remove('dragging');
                    document.querySelectorAll('.drop-target').forEach(el => el.classList.remove('drop-target'));
                });

                // 点击查看详情或选中
                card.addEventListener('click', function(e) {
                    // 如果是拖拽操作，不触发点击
                    if (this.dataset.dragged === 'true') {
                        this.dataset.dragged = 'false';
                        return;
                    }

                    const bookId = parseInt(this.dataset.bookId);

                    // 批量模式下，点击选中/取消选中
                    if (batchMode) {
                        const checkbox = this.querySelector('.book-checkbox');
                        if (checkbox) {
                            checkbox.checked = !checkbox.checked;
                            toggleBookSelection(bookId);
                            this.classList.toggle('selected', checkbox.checked);
                        }
                        return;
                    }

                    // 普通模式，显示详情
                    const bookData = {
                        id: this.dataset.bookId,
                        book_name: this.dataset.bookName,
                        author: this.dataset.author,
                        book_type: this.dataset.bookType,
                        place: this.dataset.place,
                        isbn: this.dataset.isbn,
                        status: this.dataset.status,
                        cover: this.dataset.cover,
                        description: this.dataset.description
                    };
                    showBookModal(bookData);
                });
            });

            // 初始化拖放目标
            initDropTargets();
        }

        // 初始化拖放目标
        function initDropTargets() {
            // 书籍分类导航作为拖放目标
            document.querySelectorAll('#books-sub-nav .sub-nav-item:not([data-category="all"])').forEach(item => {
                item.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('drop-target');
                });

                item.addEventListener('dragleave', function() {
                    this.classList.remove('drop-target');
                });

                item.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('drop-target');

                    const bookId = e.dataTransfer.getData('bookId');
                    if (bookId) {
                        updateBookCategory(bookId, this.dataset.category);
                    }
                });
            });

            // 书架位置导航作为拖放目标
            document.querySelectorAll('#shelf-sub-nav .sub-nav-item:not([data-shelf="all"])').forEach(item => {
                item.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('drop-target');
                });

                item.addEventListener('dragleave', function() {
                    this.classList.remove('drop-target');
                });

                item.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('drop-target');

                    const bookId = e.dataTransfer.getData('bookId');
                    if (bookId) {
                        updateBookPlace(bookId, this.dataset.shelf);
                    }
                });
            });
        }

        // 更新书籍分类
        function updateBookCategory(bookId, category) {
            fetch(`/api/book/${bookId}/`, {
                method: 'POST',  // 使用 POST 替代 PATCH，兼容性更好
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ book_type: category })
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(data => {
                        throw new Error(data.error || `HTTP错误: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showToast(`已将书籍移动到「${category}」分类`);
                    setTimeout(() => location.reload(), 500);
                } else {
                    showToast('更新失败：' + (data.error || '未知错误'), 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('更新失败：' + error.message, 'error');
            });
        }

        // 更新书籍位置
        function updateBookPlace(bookId, place) {
            fetch(`/api/book/${bookId}/`, {
                method: 'POST',  // 使用 POST 替代 PATCH
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ place: place })
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(data => {
                        throw new Error(data.error || `HTTP错误: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showToast(`已将书籍移动到「${place}」`);
                    const bookIndex = allBooks.findIndex(b => b.id === bookId);
                    if (bookIndex !== -1) {
                        allBooks[bookIndex].place = place;
                    }
                    const activeShelf = document.querySelector('#shelf-sub-nav .sub-nav-item.active');
                    if (activeShelf) {
                        filterShelfBooks(activeShelf.dataset.shelf);
                    }
                } else {
                    showToast('更新失败：' + (data.error || '未知错误'), 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('更新失败：' + error.message, 'error');
            });
        }

        // 显示提示信息
        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            toast.className = `alert alert-${type === 'error' ? 'danger' : 'success'} position-fixed`;
            toast.style.cssText = 'top: 20px; right: 20px; z-index: 10000; min-width: 300px; animation: slideIn 0.3s ease-out;';
            toast.innerHTML = message;
            document.body.appendChild(toast);
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s ease-out';
                setTimeout(() => toast.remove(), 300);
            }, 2500);
        }

        // 显示书籍详情弹窗
        let currentBookId = null; // 保存当前查看的书籍ID

        function showBookModal(bookData) {
            currentBookId = bookData.id; // 保存书籍ID供其他函数使用
            const modal = document.getElementById('bookModal');
            const content = document.getElementById('bookModalContent');

            // 先显示基本信息
            content.innerHTML = `
                <div style="text-align: center; margin-bottom: 20px;">
                    ${bookData.cover ? `<img src="${bookData.cover}" class="book-cover-modal">` : '<div class="book-cover-modal bg-secondary d-flex align-items-center justify-content-center" style="height:250px;color:white;font-size:48px;">📖</div>'}
                </div>
                <div class="detail-row">
                    <div class="detail-label">书名</div>
                    <div class="detail-value" style="font-size: 18px;">${bookData.book_name}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">作者</div>
                    <div class="detail-value">${bookData.author}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">出版社</div>
                    <div class="detail-value">${bookData.publisher || '未填写'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">出版日期</div>
                    <div class="detail-value">${bookData.publish_date || '未填写'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">分类</div>
                    <div class="detail-value">${bookData.book_type}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">位置</div>
                    <div class="detail-value">${bookData.place || '未填写'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">ISBN</div>
                    <div class="detail-value">${bookData.isbn || '未填写'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">状态</div>
                    <div class="detail-value">
                        <span class="status-badge ${bookData.status === '借出' ? 'status-borrowed' : 'status-available'}">
                            ${bookData.status === '借出' ? '已借出' : '可借阅'}
                        </span>
                        <span id="borrower-info" class="ms-2"></span>
                    </div>
                </div>
                ${bookData.description ? `
                <div class="detail-row" style="flex-direction: column; align-items: flex-start;">
                    <div class="detail-label" style="margin-bottom: 8px;">介绍</div>
                    <div class="detail-value" style="font-size: 14px; line-height: 1.6; color: #555;">${bookData.description}</div>
                </div>
                ` : ''}
                <div class="mt-4" style="display: flex; gap: 10px;">
                    <a id="borrow-btn" href="/borrow/${bookData.id}/" class="btn btn-outline-primary" style="flex: 1;">
                        ${bookData.status === '借出' ? '↩️ 归还' : '📤 借出'}
                    </a>
                    <button class="btn btn-outline-info" onclick="showBookQRCode(${bookData.id})" title="分享二维码">
                        📱
                    </button>
                    ${window.djangoData && window.djangoData.isSuperuser ? `<a href="/edit/${bookData.id}/" class="btn btn-outline-secondary" style="flex: 1;">编辑</a>` : ''}
                </div>

                <!-- 评论区 -->
                <div class="mt-4 pt-3" style="border-top: 1px solid #e0e0e0;">
                    <h6 class="mb-3">💬 评论</h6>
                    <div id="book-comments" class="mb-3" style="max-height: 250px; overflow-y: auto;">
                        <p class="text-muted small">加载中...</p>
                    </div>
                    <div class="input-group">
                        <input type="text" id="comment-input" class="form-control" placeholder="写下你的评论...">
                        <button class="btn btn-primary" onclick="submitComment(${bookData.id})">发送</button>
                    </div>
                </div>
            `;

            modal.style.display = 'flex';
            loadBookComments(bookData.id);

            // 如果书籍已借出，加载借阅信息
            if (bookData.status === '借出') {
                loadBorrowInfo(bookData.id);
            }
        }

        // 加载书籍借阅信息
        function loadBorrowInfo(bookId) {
            fetch(`/api/book/${bookId}/borrow-info/`)
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.data.is_borrowed) {
                        const info = data.data;
                        // 显示借阅人信息
                        const borrowerInfo = document.getElementById('borrower-info');
                        if (borrowerInfo && info.borrower) {
                            borrowerInfo.innerHTML = `<span class="text-muted small">借阅人：<strong>${info.borrower}</strong></span>`;
                        }

                        // 更新归还按钮
                        const borrowBtn = document.getElementById('borrow-btn');
                        if (borrowBtn) {
                            if (info.can_return) {
                                borrowBtn.innerHTML = '↩️ 归还';
                                borrowBtn.className = 'btn btn-outline-success';
                            } else {
                                // 无权归还，禁用按钮并提示
                                borrowBtn.innerHTML = '🔒 无权归还';
                                borrowBtn.className = 'btn btn-outline-secondary disabled';
                                borrowBtn.href = '#';
                                borrowBtn.onclick = function(e) {
                                    e.preventDefault();
                                    showToast('您无权归还此书籍，只有借阅人本人或管理员可以归还', 'error');
                                };
                            }
                        }
                    }
                });
        }

        // 加载书籍评论（带点赞功能）
        function loadBookComments(bookId) {
            const container = document.getElementById('book-comments');
            fetch(`/api/book/${bookId}/comments/`)
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.comments.length > 0) {
                        container.innerHTML = data.comments.map(c => `
                            <div class="mb-2 p-2" style="background: #f8f9fa; border-radius: 8px;" data-comment-id="${c.id}">
                                <div class="d-flex justify-content-between align-items-start">
                                    <small class="fw-bold">${c.user}</small>
                                    <div class="d-flex align-items-center gap-2">
                                        <button class="btn btn-sm like-btn ${c.liked ? 'liked' : ''}" onclick="toggleCommentLike(${c.id})"
                                                style="border: none; background: transparent; font-size: 12px; padding: 2px 6px; cursor: pointer;">
                                            ${c.liked ? '❤️' : '🤍'} ${c.like_count || 0}
                                        </button>
                                        ${c.can_delete ? `<button class="btn btn-sm text-danger" onclick="deleteComment(${c.id}, ${bookId})" style="border: none; background: transparent; font-size: 12px; padding: 2px 6px;">🗑️</button>` : ''}
                                    </div>
                                </div>
                                <div class="small mt-1">${c.content}</div>
                                <small class="text-muted">${c.created_at}</small>
                            </div>
                        `).join('');
                    } else {
                        container.innerHTML = '<p class="text-muted small mb-0">暂无评论，快来抢沙发吧！</p>';
                    }
                })
                .catch(() => {
                    container.innerHTML = '<p class="text-muted small mb-0">加载失败</p>';
                });
        }

        // 删除评论
        function deleteComment(commentId, bookId) {
            showConfirmModal({
                icon: '🗑️',
                title: '删除评论',
                message: '确定要删除这条评论吗？',
                warning: '此操作不可恢复',
                btnText: '确认删除',
                onConfirm: () => {
                    fetch(`/api/comment/${commentId}/delete/`, {
                        method: 'POST',
                        headers: { 'X-CSRFToken': getCsrfToken() }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            loadBookComments(bookId);
                            showToast('评论已删除');
                        } else {
                            showToast(data.error || '删除失败', 'error');
                        }
                    });
                }
            });
        }

        // 提交评论
        function submitComment(bookId) {
            const input = document.getElementById('comment-input');
            const content = input.value.trim();
            if (!content) {
                showToast('请输入评论内容', 'error');
                return;
            }

            fetch(`/api/book/${bookId}/comment/add/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ content: content })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    input.value = '';
                    loadBookComments(bookId);
                    showToast('评论成功');
                } else {
                    showToast(data.error || '评论失败', 'error');
                }
            })
            .catch(() => {
                showToast('网络错误', 'error');
            });
        }

        // 关闭书籍详情弹窗
        function closeBookModal() {
            const modal = document.getElementById('bookModal');
            if (modal) modal.style.display = 'none';
        }

        // 点击遮罩层关闭弹窗
        document.getElementById('bookModal')?.addEventListener('click', function(e) {
            if (e.target === this) {
                closeBookModal();
            }
        });

        // 删除借阅记录
        function deleteRecord(recordId, bookName) {
            showConfirmModal({
                icon: '📋',
                title: '删除借阅记录',
                message: '确定要删除这条借阅记录吗？',
                details: [
                    { label: '书籍名称', value: `《${bookName}》` }
                ],
                warning: '删除后数据无法恢复',
                btnText: '确认删除',
                onConfirm: () => {
                    fetch(`/records/delete/${recordId}/`, {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': getCsrfToken()
                        }
                    }).then(response => {
                        if (response.ok) {
                            showToast('借阅记录已删除');
                            location.reload();
                        } else {
                            showToast('删除失败', 'error');
                        }
                    }).catch(error => {
                        showToast('网络错误', 'error');
                    });
                }
            });
        }

        // 筛选借阅记录（本地筛选）
        function filterRecords() {
            const filter = document.getElementById('record-filter').value;
            const month = document.getElementById('record-month').value;

            document.querySelectorAll('#records-list-view .record-item').forEach(item => {
                const status = item.dataset.status;
                const recordDate = item.dataset.date; // 格式: Y-m
                const recordMonth = recordDate ? parseInt(recordDate.split('-')[1]) : 0;

                const matchFilter = filter === 'all' || status === filter;
                const matchMonth = month === 'all' || recordMonth === parseInt(month);

                if (matchFilter && matchMonth) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // 搜索借阅记录（AJAX方式）
        function searchRecords() {
            const searchBook = document.getElementById('record-search-book')?.value.trim() || '';
            const searchBorrower = document.getElementById('record-search-borrower')?.value.trim() || '';
            const searchAuthor = document.getElementById('record-search-author')?.value.trim() || '';
            const recordFilter = document.getElementById('record-filter')?.value || 'all';
            const searchMonth = document.getElementById('record-month')?.value || 'all';

            // 构建URL - 只添加非空参数
            let url = '/api/borrow-records/search/?';
            if (searchBook) url += 'search_book=' + encodeURIComponent(searchBook) + '&';
            if (searchBorrower) url += 'search_borrower=' + encodeURIComponent(searchBorrower) + '&';
            if (searchAuthor) url += 'search_author=' + encodeURIComponent(searchAuthor) + '&';
            url += 'filter=' + recordFilter + '&';
            url += 'month=' + searchMonth;

            // 获取容器
            const container = document.getElementById('records-list-view');
            if (!container) return;

            container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><p class="mt-2">搜索中...</p></div>';

            fetch(url)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        if (data.records.length === 0) {
                            container.innerHTML = `
                                <div class="text-center py-5" style="color: #999;">
                                    <div style="font-size: 48px; margin-bottom: 15px;">📋</div>
                                    <h4>未找到匹配的借阅记录</h4>
                                    <p class="mt-2">请尝试其他搜索条件，或<button class="btn btn-link p-0" onclick="clearRecordSearch()" style="color: #667eea;">清空筛选</button></p>
                                </div>
                            `;
                            return;
                        }

                        container.innerHTML = data.records.map(record => `
                            <div class="record-item"
                                 data-record-id="${record.id}"
                                 data-book-name="${record.book_name}"
                                 data-author="${record.author}"
                                 data-borrower="${record.borrower_name}"
                                 data-borrow-date="${record.borrow_date.substring(0, 10)}"
                                 data-return-date="${record.return_date ? record.return_date.substring(0, 10) : ''}"
                                 data-status="${record.is_returned ? 'returned' : 'borrowed'}">
                                <div class="d-flex align-items-center">
                                    ${record.cover
                                        ? `<img src="${record.cover}" class="book-cover-small" alt="${record.book_name}">`
                                        : '<div class="book-cover-small bg-secondary d-flex align-items-center justify-content-center text-white" style="width:60px;height:80px;border-radius:6px;margin-right:15px;font-size:24px;">📖</div>'
                                    }
                                    <div style="flex: 1;">
                                        <h6 class="mb-1 text-truncate" style="max-width: 200px;">${record.book_name}</h6>
                                        <small class="text-muted">作者：${record.author} | 借阅人：${record.borrower_name}</small>
                                        <div class="mt-2" style="font-size: 12px; color: #666;">
                                            <div>借出：${record.borrow_date}</div>
                                            ${record.return_date
                                                ? '<div style="color: #28a745;">归还：' + record.return_date + '</div>'
                                                : '<div style="color: #dc3545;">未归还</div>'
                                            }
                                        </div>
                                    </div>
                                    ${window.djangoData && window.djangoData.isSuperuser
                                        ? '<div class="ms-2"><button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(' + record.id + ', \'' + record.book_name + '\')" title="删除记录">🗑️</button></div>'
                                        : ''
                                    }
                                </div>
                            </div>
                        `).join('');

                        // 更新全局记录数据
                        allRecords = data.records.map(r => ({
                            book_name: r.book_name,
                            author: r.author,
                            borrower: r.borrower_name,
                            date: r.borrow_date.substring(0, 7),
                            borrowDate: r.borrow_date.substring(0, 10),
                            returnDate: r.return_date ? r.return_date.substring(0, 10) : null,
                            status: r.is_returned ? 'returned' : 'borrowed'
                        }));
                    } else {
                        container.innerHTML = '<div class="text-center py-5 text-muted">搜索失败，请重试</div>';
                    }
                })
                .catch(err => {
                    console.error('搜索失败:', err);
                    container.innerHTML = '<div class="text-center py-5 text-muted">搜索失败，请重试</div>';
                });
        }

        // 借阅记录输入框事件监听
        document.addEventListener('DOMContentLoaded', function() {
            const recordInputs = ['record-search-book', 'record-search-borrower', 'record-search-author'];
            let recordSearchTimeout = null;

            recordInputs.forEach(id => {
                const input = document.getElementById(id);
                if (input) {
                    // 回车触发搜索
                    input.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            if (recordSearchTimeout) clearTimeout(recordSearchTimeout);
                            searchRecords();
                        }
                    });

                    // 输入变化时自动搜索（带防抖）
                    input.addEventListener('input', function(e) {
                        if (recordSearchTimeout) clearTimeout(recordSearchTimeout);
                        recordSearchTimeout = setTimeout(() => {
                            searchRecords();
                        }, 500);
                    });
                }
            });

            // 下拉框变化时立即搜索
            const filterSelect = document.getElementById('record-filter');
            const monthSelect = document.getElementById('record-month');
            if (filterSelect) {
                filterSelect.addEventListener('change', function() {
                    searchRecords();
                });
            }
            if (monthSelect) {
                monthSelect.addEventListener('change', function() {
                    searchRecords();
                });
            }
        });

        // 清除借阅记录搜索
        function clearRecordSearch() {
            const bookInput = document.getElementById('record-search-book');
            const borrowerInput = document.getElementById('record-search-borrower');
            const authorInput = document.getElementById('record-search-author');
            const filterSelect = document.getElementById('record-filter');
            const monthSelect = document.getElementById('record-month');

            if (bookInput) bookInput.value = '';
            if (borrowerInput) borrowerInput.value = '';
            if (authorInput) authorInput.value = '';
            if (filterSelect) filterSelect.value = 'all';
            if (monthSelect) monthSelect.value = 'all';

            // 直接调用搜索函数，刷新数据
            searchRecords();
        }

        // 初始化日历
        function initCalendar() {
            renderCalendar();
        }

        // 渲染日历
        function renderCalendar() {
            const year = currentMonth.getFullYear();
            const month = currentMonth.getMonth();

            document.getElementById('calendar-title').textContent = `${year}年${month + 1}月`;

            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const today = new Date();

            let html = '';

            // 空白格
            for (let i = 0; i < firstDay; i++) {
                html += '<div class="calendar-day"></div>';
            }

            // 日期格子
            for (let day = 1; day <= daysInMonth; day++) {
                const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
                const dayEvents = [];

                // 查找当天的借阅记录（使用完整日期）
                allRecords.forEach(record => {
                    // 检查借出日期
                    if (record.borrowDate) {
                        const borrowDateParts = record.borrowDate.split('-');
                        const borrowYear = parseInt(borrowDateParts[0]);
                        const borrowMonth = parseInt(borrowDateParts[1]) - 1;
                        const borrowDay = parseInt(borrowDateParts[2]);

                        if (borrowYear === year && borrowMonth === month && borrowDay === day) {
                            dayEvents.push({ text: `📤 ${record.book_name}`, type: 'borrow', book: record.book_name, borrower: record.borrower, date: record.borrowDate });
                        }
                    }

                    // 检查归还日期
                    if (record.returnDate) {
                        const returnDateParts = record.returnDate.split('-');
                        const returnYear = parseInt(returnDateParts[0]);
                        const returnMonth = parseInt(returnDateParts[1]) - 1;
                        const returnDay = parseInt(returnDateParts[2]);

                        if (returnYear === year && returnMonth === month && returnDay === day) {
                            dayEvents.push({ text: `↩️ ${record.book_name}`, type: 'return', book: record.book_name, borrower: record.borrower, date: record.returnDate });
                        }
                    }
                });

                const hasEvents = dayEvents.length > 0;
                html += `
                    <div class="calendar-day ${isToday ? 'today' : ''} ${hasEvents ? 'has-events' : ''}" ${hasEvents ? `onclick="showDayEvents(${year}, ${month}, ${day})" style="cursor: pointer;"` : ''}>
                        <div class="calendar-day-number">${day}</div>
                        ${dayEvents.slice(0, 2).map(e => `<div class="calendar-event ${e.type === 'return' ? 'calendar-event-return' : ''}" title="${e.type === 'return' ? '归还' : '借出'}">${e.text}</div>`).join('')}
                        ${dayEvents.length > 2 ? `<div class="calendar-event" style="background: #6c757d;">+${dayEvents.length - 2} 更多</div>` : ''}
                    </div>
                `;
            }

            const grid = document.querySelector('#records-calendar-view .calendar-grid');
            const existingDays = grid.querySelectorAll('.calendar-day');
            existingDays.forEach(d => d.remove());
            grid.insertAdjacentHTML('beforeend', html);
        }

        // 显示某天的详细借阅记录
        function showDayEvents(year, month, day) {
            const dayEvents = [];

            allRecords.forEach(record => {
                // 检查借出日期
                if (record.borrowDate) {
                    const borrowDateParts = record.borrowDate.split('-');
                    const borrowYear = parseInt(borrowDateParts[0]);
                    const borrowMonth = parseInt(borrowDateParts[1]) - 1;
                    const borrowDay = parseInt(borrowDateParts[2]);

                    if (borrowYear === year && borrowMonth === month && borrowDay === day) {
                        dayEvents.push({
                            text: `📤 借出《${record.book_name}》`,
                            type: 'borrow',
                            book: record.book_name,
                            borrower: record.borrower,
                            time: record.borrowDate,
                            returnTime: record.returnDate || null
                        });
                    }
                }

                // 检查归还日期
                if (record.returnDate) {
                    const returnDateParts = record.returnDate.split('-');
                    const returnYear = parseInt(returnDateParts[0]);
                    const returnMonth = parseInt(returnDateParts[1]) - 1;
                    const returnDay = parseInt(returnDateParts[2]);

                    if (returnYear === year && returnMonth === month && returnDay === day) {
                        dayEvents.push({
                            text: `↩️ 归还《${record.book_name}》`,
                            type: 'return',
                            book: record.book_name,
                            borrower: record.borrower,
                            time: record.returnDate
                        });
                    }
                }
            });

            if (dayEvents.length === 0) return;

            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = `📅 ${year}年${month + 1}月${day}日 借阅记录`;

            content.innerHTML = `
                <div class="isbn-input-section">
                    ${dayEvents.map(e => `
                        <div class="d-flex align-items-start gap-3 p-3 mb-2" style="background: ${e.type === 'return' ? '#d4edda' : '#f8d7da'}; border-radius: 10px;">
                            <div style="font-size: 24px;">${e.type === 'return' ? '↩️' : '📤'}</div>
                            <div style="flex: 1;">
                                <div class="fw-bold">${e.book}</div>
                                <div class="small text-muted">
                                    ${e.type === 'return' ? '归还' : '借出'} · 借阅人：${e.borrower || '未知'}
                                </div>
                                <div class="small text-muted mt-1">
                                    ${e.type === 'return' ? '归还时间' : '借阅时间'}：${e.time || '未知'}
                                </div>
                                ${e.type === 'borrow' && e.returnTime ? `<div class="small text-success mt-1">归还时间：${e.returnTime}</div>` : ''}
                                ${e.type === 'borrow' && !e.returnTime ? `<div class="small text-warning mt-1">状态：未归还</div>` : ''}
                            </div>
                        </div>
                    `).join('')}
                    <div class="text-center mt-3">
                        <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
                    </div>
                </div>
            `;

            modal.style.display = 'flex';
        }

        // 切换月份
        function changeMonth(delta) {
            currentMonth.setMonth(currentMonth.getMonth() + delta);
            renderCalendar();
            // 更新日期选择器
            updateDateSelectors();
        }

        // 更新日期选择器为当前月份
        function updateDateSelectors() {
            const startInput = document.getElementById('calendar-start-date');
            const endInput = document.getElementById('calendar-end-date');
            if (startInput && endInput) {
                const year = currentMonth.getFullYear();
                const month = currentMonth.getMonth();
                // 设置为本月第一天和最后一天
                startInput.value = `${year}-${String(month + 1).padStart(2, '0')}-01`;
                const lastDay = new Date(year, month + 1, 0).getDate();
                endInput.value = `${year}-${String(month + 1).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
            }
        }

        // 图表实例
        let borrowChart = null;

        // 初始化日历视图
        function initCalendarView() {
            // 初始化日期选择器
            const startInput = document.getElementById('calendar-start-date');
            const endInput = document.getElementById('calendar-end-date');

            if (startInput && endInput) {
                // 设置默认值为本月
                const now = new Date();
                const year = now.getFullYear();
                const month = now.getMonth();

                const firstDay = new Date(year, month, 1);
                const lastDay = new Date(year, month + 1, 0);

                startInput.value = firstDay.toISOString().split('T')[0];
                endInput.value = lastDay.toISOString().split('T')[0];

                // 加载默认图表数据
                loadBorrowChart(startInput.value, endInput.value);
            }
        }

        // 加载日历数据（包括图表）
        function loadCalendarData() {
            const startDate = document.getElementById('calendar-start-date').value;
            const endDate = document.getElementById('calendar-end-date').value;

            if (!startDate || !endDate) {
                showToast('请选择起止日期', 'error');
                return;
            }

            // 加载图表数据
            loadBorrowChart(startDate, endDate);

            // 更新日历视图
            const startParts = startDate.split('-');
            currentMonth = new Date(parseInt(startParts[0]), parseInt(startParts[1]) - 1, 1);
            renderCalendar();
        }

        // 加载借阅图表
        function loadBorrowChart(startDate, endDate) {
            fetch(`/api/borrow/chart-data/?start_date=${startDate}&end_date=${endDate}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        renderBorrowChart(data.data);
                    } else {
                        showToast('加载图表数据失败', 'error');
                    }
                })
                .catch(error => {
                    console.error('加载图表失败:', error);
                    showToast('加载图表失败', 'error');
                });
        }

        // 渲染借阅图表
        function renderBorrowChart(data) {
            const ctx = document.getElementById('borrow-chart');
            if (!ctx) return;

            // 销毁旧图表
            if (borrowChart) {
                borrowChart.destroy();
            }

            // 计算最大借阅次数，用于设置Y轴范围
            const maxCount = Math.max(...data.borrow_counts, ...data.return_counts, 5);
            const yMax = Math.ceil(maxCount * 1.2); // 留20%空间

            // 创建新图表 - 使用柱状图更直观
            borrowChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [
                        {
                            label: '借阅',
                            data: data.borrow_counts,
                            backgroundColor: 'rgba(102, 126, 234, 0.8)',
                            borderColor: '#667eea',
                            borderWidth: 1,
                            borderRadius: 4,
                        },
                        {
                            label: '归还',
                            data: data.return_counts,
                            backgroundColor: 'rgba(40, 167, 69, 0.8)',
                            borderColor: '#28a745',
                            borderWidth: 1,
                            borderRadius: 4,
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false, // 固定容器高度
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + context.parsed.y + '次';
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            display: true,
                            title: {
                                display: true,
                                text: '日期'
                            },
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: '次数'
                            },
                            beginAtZero: true,
                            max: yMax,
                            ticks: {
                                stepSize: 1 // 整数刻度
                            }
                        }
                    }
                }
            });

            // 更新统计摘要
            const summary = data.summary;
            const chartContainer = document.getElementById('calendar-chart-container');
            if (chartContainer && summary) {
                // 在图表上方添加统计摘要
                let summaryHtml = `
                    <div class="row text-center mb-3">
                        <div class="col">
                            <div class="small text-muted">期间借阅</div>
                            <div class="fw-bold text-primary">${summary.total_borrowed}次</div>
                        </div>
                        <div class="col">
                            <div class="small text-muted">期间归还</div>
                            <div class="fw-bold text-success">${summary.total_returned}次</div>
                        </div>
                        <div class="col">
                            <div class="small text-muted">馆藏总数</div>
                            <div class="fw-bold">${summary.total_books}本</div>
                        </div>
                        <div class="col">
                            <div class="small text-muted">当前借出</div>
                            <div class="fw-bold text-danger">${summary.borrowed_books}本</div>
                        </div>
                    </div>
                `;
                // 在图表canvas前面插入摘要
                const existingSummary = chartContainer.querySelector('.chart-summary');
                if (existingSummary) {
                    existingSummary.remove();
                }
                const summaryDiv = document.createElement('div');
                summaryDiv.className = 'chart-summary';
                summaryDiv.innerHTML = summaryHtml;
                ctx.parentNode.insertBefore(summaryDiv, ctx);
            }
        }

        // ========== 浮动按钮和录入功能 ==========

        // 切换浮动菜单
        function toggleFabMenu() {
            const fabMenu = document.getElementById('fabMenu');
            const fabBtn = document.getElementById('fabBtn');
            fabMenu.classList.toggle('show');
            fabBtn.classList.toggle('active');
        }

        // 点击其他地方关闭菜单
        document.addEventListener('click', function(e) {
            const fabContainer = document.querySelector('.fab-container');
            if (fabContainer && !fabContainer.contains(e.target)) {
                document.getElementById('fabMenu')?.classList.remove('show');
                document.getElementById('fabBtn')?.classList.remove('active');
            }
        });

        // 打开条形码扫描
        function openBarcodeScanner() {
            toggleFabMenu();
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📷 条形码录入';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div id="scanner-container" style="position: relative; background: #000; border-radius: 12px; overflow: hidden; height: 400px;">
                        <video id="barcode-video" style="width: 100%; height: 100%; object-fit: cover;"></video>
                        <div id="scan-overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 85%; height: 180px; border: 3px solid #667eea; border-radius: 12px; box-shadow: 0 0 0 9999px rgba(0,0,0,0.4);"></div>
                        <div id="scan-hint" style="position: absolute; bottom: 20px; left: 0; right: 0; text-align: center; color: white; font-size: 14px;">将书籍条形码对准框内</div>
                    </div>
                    <div id="scan-status" class="text-center mt-3">
                        <button id="startScanBtn" class="btn btn-primary" onclick="startCamera()">
                            📷 开启摄像头
                        </button>
                        <button id="stopScanBtn" class="btn btn-secondary" onclick="stopCamera()" style="display: none;">
                            ⏹️ 停止扫描
                        </button>
                    </div>
                    <div class="mt-4">
                        <label class="form-label">或直接输入条形码：</label>
                        <div class="input-group">
                            <input type="text" id="barcodeInput" class="form-control" placeholder="输入条形码数字">
                            <button class="btn btn-primary" onclick="searchByBarcode()">查询</button>
                        </div>
                    </div>
                    <div id="isbnResult" class="mt-3"></div>
                </div>
            `;
            modal.style.display = 'flex';
        }

        // 摄像头和条形码扫描
        let videoStream = null;
        let scanInterval = null;
        let lastDetectedCode = null;
        let detectCount = 0;

        // 播放成功音效
        function playSuccessSound() {
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                oscillator.frequency.value = 800;
                oscillator.type = 'sine';
                gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
                oscillator.start(audioCtx.currentTime);
                oscillator.stop(audioCtx.currentTime + 0.3);
                if (navigator.vibrate) navigator.vibrate(100);
            } catch(e) { console.log('音效播放失败:', e); }
        }

        async function startCamera() {
            try {
                const video = document.getElementById('barcode-video');
                videoStream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }
                });
                video.srcObject = videoStream;
                video.play();
                document.getElementById('startScanBtn').style.display = 'none';
                document.getElementById('stopScanBtn').style.display = 'inline-block';
                document.getElementById('scan-hint').textContent = '扫描中...请将条形码对准框内';
                startBarcodeScanning();
            } catch (error) {
                console.error('摄像头错误:', error);
                alert('无法访问摄像头，请确保已授权摄像头权限');
            }
        }

        function stopCamera() {
            // 先停止Quagga
            if (typeof Quagga !== 'undefined') {
                try {
                    Quagga.stop();
                } catch(e) { console.log('Quagga停止错误:', e); }
            }
            // 再停止摄像头流
            if (videoStream) {
                videoStream.getTracks().forEach(track => {
                    track.stop();
                    track.enabled = false;
                });
                videoStream = null;
            }
            // 清除video元素
            const video = document.getElementById('barcode-video');
            if (video) {
                video.srcObject = null;
                video.pause();
            }
            if (scanInterval) { clearInterval(scanInterval); scanInterval = null; }
            lastDetectedCode = null;
            detectCount = 0;
            const startBtn = document.getElementById('startScanBtn');
            const stopBtn = document.getElementById('stopScanBtn');
            const hint = document.getElementById('scan-hint');
            if (startBtn) startBtn.style.display = 'inline-block';
            if (stopBtn) stopBtn.style.display = 'none';
            if (hint) hint.textContent = '将书籍条形码对准框内';
        }

        function startBarcodeScanning() {
            // 方案1: 优先使用浏览器原生 BarcodeDetector API
            if ('BarcodeDetector' in window) {
                console.log('使用原生 BarcodeDetector API');
                initNativeBarcodeDetector();
                return;
            }

            // 方案2: 加载 QuaggaJS（多个CDN备用）
            if (typeof Quagga === 'undefined') {
                const cdnUrls = [
                    'https://cdn.jsdelivr.net/npm/@ericblade/quagga2@1.8.4/dist/quagga.min.js',
                    'https://unpkg.com/@ericblade/quagga2@1.8.4/dist/quagga.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js'
                ];
                loadScriptWithFallback(cdnUrls, 0, initQuagga, useManualInputFallback);
            } else {
                initQuagga();
            }
        }

        // 多CDN加载函数
        function loadScriptWithFallback(urls, index, onSuccess, onFail) {
            if (index >= urls.length) {
                console.log('所有CDN都加载失败');
                onFail();
                return;
            }
            const script = document.createElement('script');
            script.src = urls[index];
            script.onload = () => { console.log('脚本加载成功:', urls[index]); onSuccess(); };
            script.onerror = () => {
                console.log('CDN加载失败:', urls[index]);
                loadScriptWithFallback(urls, index + 1, onSuccess, onFail);
            };
            document.head.appendChild(script);
        }

        // 原生 BarcodeDetector 方案
        async function initNativeBarcodeDetector() {
            try {
                const video = document.getElementById('barcode-video');
                const formats = await BarcodeDetector.getSupportedFormats();
                console.log('支持的条码格式:', formats);

                const detector = new BarcodeDetector({
                    formats: ['ean_13', 'ean_8', 'code_128']
                });

                scanInterval = setInterval(async () => {
                    try {
                        const barcodes = await detector.detect(video);
                        if (barcodes.length > 0) {
                            const code = barcodes[0].rawValue;
                            console.log('检测到条码:', code);
                            if (code === lastDetectedCode) {
                                detectCount++;
                                if (detectCount >= 2) {
                                    clearInterval(scanInterval);
                                    playSuccessSound();
                                    document.getElementById('barcodeInput').value = code;
                                    document.getElementById('scan-hint').textContent = `✅ 识别成功: ${code}`;
                                    stopCamera();
                                    setTimeout(() => searchByBarcode(), 500);
                                }
                            } else {
                                lastDetectedCode = code;
                                detectCount = 1;
                                document.getElementById('scan-hint').textContent = `正在识别: ${code}...`;
                            }
                        }
                    } catch(e) {}
                }, 200);
            } catch (error) {
                console.error('BarcodeDetector初始化失败:', error);
                useManualInputFallback();
            }
        }

        function initQuagga() {
            const video = document.getElementById('barcode-video');
            Quagga.init({
                inputStream: {
                    name: "Live", type: "LiveStream", target: video,
                    constraints: { facingMode: "environment", width: { min: 640, ideal: 1280 }, height: { min: 480, ideal: 720 } },
                    area: { top: "20%", right: "10%", left: "10%", bottom: "20%" }
                },
                decoder: { readers: ["ean_reader", "ean_8_reader", "code_128_reader"], multiple: false },
                locate: true,
                frequency: 10
            }, function(err) {
                if (err) {
                    console.error('Quagga初始化失败:', err);
                    useManualInputFallback();
                    return;
                }
                Quagga.start();
                Quagga.onDetected(onBarcodeDetected);
            });
        }

        function onBarcodeDetected(result) {
            if (result && result.codeResult) {
                const code = result.codeResult.code;
                if (code === lastDetectedCode) {
                    detectCount++;
                    if (detectCount >= 2) {
                        playSuccessSound();
                        document.getElementById('barcodeInput').value = code;
                        document.getElementById('scan-hint').textContent = `✅ 识别成功: ${code}`;
                        stopCamera();
                        setTimeout(() => searchByBarcode(), 500);
                    }
                } else {
                    lastDetectedCode = code;
                    detectCount = 1;
                    document.getElementById('scan-hint').textContent = `正在识别: ${code}...`;
                }
            }
        }

        // 手动输入备选方案
        function useManualInputFallback() {
            console.log('使用手动输入模式');
            document.getElementById('scan-hint').innerHTML = `
                <span class="text-warning">⚠️ 自动扫描不可用</span>
                <br><small>请手动输入ISBN或使用键盘扫码枪</small>
            `;
            // 聚焦到输入框
            const input = document.getElementById('barcodeInput');
            if (input) {
                input.style.display = 'block';
                input.focus();
                // 监听输入变化
                input.oninput = function() {
                    const val = this.value.replace(/[-\s]/g, '');
                    if (val.length >= 10) {
                        playSuccessSound();
                        stopCamera();
                        searchByBarcode();
                    }
                };
            }
        }

        function simpleBarcodeScan() {
            useManualInputFallback();
        }

        // 打开ISBN输入
        function openISBNInput() {
            toggleFabMenu();
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '🔢 ISBN录入';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="text-center py-3">
                        <div style="font-size: 48px; margin-bottom: 15px;">🔢</div>
                        <h5>ISBN快速录入</h5>
                        <p class="text-muted mt-2">输入ISBN号自动获取书籍信息</p>
                    </div>
                    <div class="mt-3">
                        <label class="form-label">ISBN号：</label>
                        <div class="input-group">
                            <input type="text" id="isbnInput" class="form-control" placeholder="如：9787111234567" maxlength="17">
                            <button class="btn btn-primary" onclick="searchByISBN()">查询</button>
                        </div>
                        <div class="form-text">支持10位或13位ISBN，可包含连字符</div>
                    </div>
                    <div id="isbnResult" class="mt-3"></div>
                </div>
            `;
            modal.style.display = 'flex';

            // 回车键查询
            document.getElementById('isbnInput')?.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') searchByISBN();
            });
        }

        // 通过条形码查询
        function searchByBarcode() {
            const barcode = document.getElementById('barcodeInput').value.trim();
            if (!barcode) {
                showToast('请输入条形码', 'error');
                return;
            }
            // 条形码通常就是ISBN
            searchBookByCode(barcode);
        }

        // 通过ISBN查询
        function searchByISBN() {
            const isbn = document.getElementById('isbnInput').value.trim();
            if (!isbn) {
                showToast('请输入ISBN号', 'error');
                return;
            }
            searchBookByCode(isbn);
        }

        // 通过编码查询书籍信息
        function searchBookByCode(code) {
            const resultDiv = document.getElementById('isbnResult') || document.getElementById('barcodeInput').parentElement.parentElement;
            resultDiv.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary"></div><p class="mt-2">正在查询书库...</p><small class="text-muted">最多等待4秒</small></div>';

            // 清理ISBN格式
            const cleanIsbn = code.replace(/[-\s]/g, '');

            // 调用后端API查询，设置4秒超时
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 4000);

            fetch(`/api/book/isbn/${cleanIsbn}/`, { signal: controller.signal })
                .then(response => response.json())
                .then(data => {
                    clearTimeout(timeoutId);
                    if (data.success && data.book) {
                        showBookResult(data.book);
                    } else {
                        const isNetworkError = data.network_error === true;
                        showManualEntry(cleanIsbn, data.error || '书库未收录此ISBN', isNetworkError);
                    }
                })
                .catch(error => {
                    clearTimeout(timeoutId);
                    console.error('查询错误:', error);
                    showManualEntry(cleanIsbn, '当前网络无法连接图书数据库，请手动录入书籍信息', true);
                });
        }

        // 显示手动录入提示
        function showManualEntry(isbn, reason, isNetworkError) {
            const resultDiv = document.getElementById('isbnResult');
            if (!resultDiv) {
                console.error('showManualEntry: 找不到 isbnResult 元素');
                alert(`ISBN: ${isbn}\n${reason}`);
                return;
            }
            const alertClass = isNetworkError ? 'alert-warning' : 'alert-info';
            const icon = isNetworkError ? '⚠️' : 'ℹ️';
            const showSearch = !isNetworkError; // 网络错误时隐藏搜索功能

            resultDiv.innerHTML = `
                <div class="alert ${alertClass}">
                    <div class="mb-3">
                        <strong>${icon} ISBN: ${isbn}</strong>
                        <p class="small text-muted mb-0">${reason}</p>
                    </div>
                    ${showSearch ? `
                    <div class="mb-3">
                        <label class="form-label small">或输入书名搜索：</label>
                        <div class="input-group input-group-sm">
                            <input type="text" id="titleSearchInput" class="form-control" placeholder="输入书名搜索豆瓣书库">
                            <button class="btn btn-primary" onclick="searchByTitle()">搜索</button>
                        </div>
                    </div>
                    <div id="titleSearchResult"></div>
                    <hr>
                    ` : ''}
                    <a href="/add/?isbn=${isbn}" class="btn btn-success btn-sm">
                        ✏️ 手动录入此ISBN
                    </a>
                </div>
            `;

            // 回车搜索
            document.getElementById('titleSearchInput')?.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') searchByTitle();
            });
        }

        // 通过书名搜索
        function searchByTitle() {
            const query = document.getElementById('titleSearchInput')?.value.trim();
            if (!query) return;

            const resultDiv = document.getElementById('titleSearchResult');
            if (!resultDiv) {
                console.error('searchByTitle: 找不到 titleSearchResult 元素');
                return;
            }
            resultDiv.innerHTML = '<div class="text-center py-2"><div class="spinner-border spinner-border-sm"></div> 搜索中...</div>';

            fetch(`/api/book/search/?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.books.length > 0) {
                        resultDiv.innerHTML = data.books.map(book => `
                            <div class="card mb-2" style="cursor: pointer;" onclick="selectBookFromSearch('${book.book_name.replace(/'/g, "\\'")}', '${book.author || ''}', '${book.cover || ''}')">
                                <div class="card-body p-2 d-flex align-items-center gap-2">
                                    ${book.cover ? `<img src="${book.cover}" style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">` : '<div style="width:40px;height:55px;background:#f0f0f0;border-radius:4px;display:flex;align-items:center;justify-content:center;">📖</div>'}
                                    <div>
                                        <div class="small fw-bold">${book.book_name}</div>
                                        <div class="small text-muted">${book.author || '未知作者'}</div>
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    } else {
                        const errorMsg = data.network_error ? '⚠️ 网络连接失败' : '未找到相关书籍';
                        resultDiv.innerHTML = `<div class="small text-muted">${errorMsg}</div>`;
                    }
                })
                .catch(error => {
                    resultDiv.innerHTML = '<div class="small text-warning">⚠️ 网络连接失败，请手动录入</div>';
                });
        }

        // 选择搜索结果中的书籍
        function selectBookFromSearch(title, author, cover) {
            const isbn = document.getElementById('isbnInput')?.value || document.getElementById('barcodeInput')?.value || '';
            const book = {
                book_name: title,
                author: author,
                isbn: isbn,
                cover: cover
            };
            showBookResult(book);
        }

        // 显示查询到的书籍结果
        function showBookResult(book) {
            const resultDiv = document.getElementById('isbnResult');
            if (!resultDiv) {
                console.error('showBookResult: 找不到 isbnResult 元素');
                alert(`找到书籍: ${book.book_name}\n作者: ${book.author || '未知'}\nISBN: ${book.isbn || '无'}`);
                return;
            }

            // 构建详细信息HTML
            let detailHtml = `
                <div class="isbn-result">
                    <div class="d-flex align-items-start gap-3">
                        ${book.cover ? `<img src="${book.cover}" style="width: 100px; height: 140px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">` : '<div style="width:100px;height:140px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:40px;color:white;">📖</div>'}
                        <div style="flex: 1;">
                            <h5 class="mb-2" style="color: #333; font-weight: 600;">${book.book_name}</h5>
                            <p class="mb-1" style="color: #555;"><span style="color:#888;">✍️ 作者：</span>${book.author || '未知'}</p>
                            <p class="mb-1" style="color: #555;"><span style="color:#888;">📚 ISBN：</span>${book.isbn || '无'}</p>
                            ${book.publisher ? `<p class="mb-1" style="color: #555;"><span style="color:#888;">🏛️ 出版社：</span>${book.publisher}</p>` : ''}
                            ${book.publish_date ? `<p class="mb-1" style="color: #555;"><span style="color:#888;">📅 出版日期：</span>${book.publish_date}</p>` : ''}
                            ${book.pages ? `<p class="mb-1" style="color: #555;"><span style="color:#888;">📄 页数：</span>${book.pages}页</p>` : ''}
                            ${book.price ? `<p class="mb-1" style="color: #555;"><span style="color:#888;">💰 定价：</span>${book.price}</p>` : ''}
                            ${book.rating ? `<p class="mb-1" style="color: #555;"><span style="color:#888;">⭐ 豆瓣评分：</span>${book.rating}</p>` : ''}
                        </div>
                    </div>
                    ${book.description ? `
                    <div class="mt-3 p-3" style="background: #f8f9fa; border-radius: 10px; border-left: 4px solid #667eea;">
                        <div style="color: #666; font-size: 13px; font-weight: 500; margin-bottom: 5px;">📝 内容简介</div>
                        <p style="color: #444; font-size: 14px; line-height: 1.6; margin: 0;">${book.description.length > 200 ? book.description.substring(0, 200) + '...' : book.description}</p>
                    </div>
                    ` : ''}
                    <div class="mt-3 d-flex gap-2">
                        <a href="/add/?isbn=${book.isbn}&title=${encodeURIComponent(book.book_name)}&author=${encodeURIComponent(book.author || '')}" class="btn btn-success flex-grow-1">
                            ✅ 录入此书
                        </a>
                        <button class="btn btn-outline-secondary" onclick="document.getElementById('isbnInput').value='';document.getElementById('isbnResult').innerHTML='';">
                            重新查询
                        </button>
                    </div>
                </div>
            `;
            resultDiv.innerHTML = detailHtml;
        }

        // 关闭扫描弹窗
        function closeScanModal() {
            console.log('closeScanModal called');
            try {
                stopCamera(); // stopCamera已经处理了Quagga和摄像头
            } catch(e) {
                console.log('清理资源时出错:', e);
            }
            const modal = document.getElementById('scanModal');
            if (modal) {
                modal.style.display = 'none';
            }
        }

        // 点击遮罩关闭
        document.getElementById('scanModal')?.addEventListener('click', function(e) {
            if (e.target === this) {
                console.log('Overlay clicked');
                closeScanModal();
            }
        });

        // ========== 书架位置管理 ==========

        // 打开添加书架弹窗
        function openAddShelfModal() {
            toggleFabMenu();
            const modal = document.getElementById('shelfModal');
            const content = document.getElementById('shelfModalContent');
            document.getElementById('shelfModalTitle').textContent = '🏠 添加书架位置';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="mb-3">
                        <label class="form-label">位置名称</label>
                        <input type="text" id="shelf-name" class="form-control" placeholder="如：客厅书架、卧室床头柜">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">位置描述（可选）</label>
                        <input type="text" id="shelf-desc" class="form-control" placeholder="如：靠窗位置">
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1" onclick="addShelfLocation()">添加</button>
                        <button class="btn btn-secondary" onclick="closeShelfModal()">取消</button>
                    </div>
                </div>
            `;
            modal.style.display = 'flex';
        }

        // 打开管理书架弹窗
        function openManageShelfModal() {
            toggleFabMenu();
            const modal = document.getElementById('shelfModal');
            const content = document.getElementById('shelfModalContent');
            document.getElementById('shelfModalTitle').textContent = '⚙️ 管理书架位置';

            content.innerHTML = `<div class="isbn-input-section"><p class="text-center">加载中...</p></div>`;

            fetch('/api/shelf/locations/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        let html = '<div class="isbn-input-section">';
                        if (data.locations.length === 0) {
                            html += '<p class="text-center text-muted">暂无自定义书架位置</p>';
                        } else {
                            data.locations.forEach(loc => {
                                html += `
                                    <div class="d-flex align-items-center justify-content-between p-3 mb-2" style="background: #f8f9fa; border-radius: 10px;">
                                        <div>
                                            <strong>${loc.name}</strong>
                                            <br><small class="text-muted">${loc.book_count} 本书 ${loc.description ? '· ' + loc.description : ''}</small>
                                        </div>
                                        <div>
                                            <button class="btn btn-sm btn-outline-primary me-1" onclick="editShelfLocation(${loc.id}, '${loc.name}', '${loc.description || ''}')">编辑</button>
                                            <button class="btn btn-sm btn-outline-danger" onclick="deleteShelfLocation(${loc.id}, '${loc.name}')">删除</button>
                                        </div>
                                    </div>
                                `;
                            });
                        }
                        html += '</div>';
                        content.innerHTML = html;
                    }
                });

            modal.style.display = 'flex';
        }

        // 添加书架位置
        function addShelfLocation() {
            const name = document.getElementById('shelf-name').value.trim();
            const desc = document.getElementById('shelf-desc').value.trim();
            if (!name) { showToast('请输入位置名称', 'error'); return; }

            // 获取CSRF token
            const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]')?.value ||
                              document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

            fetch('/api/shelf/location/add/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken
                },
                body: JSON.stringify({ name, description: desc })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('添加成功');
                    closeShelfModal();
                    loadShelfLocations();
                } else {
                    showToast(data.error || '添加失败', 'error');
                }
            })
            .catch(error => {
                console.error('添加书架位置失败:', error);
                showToast('添加失败，请重试', 'error');
            });
        }

        // 编辑书架位置
        function editShelfLocation(id, name, desc) {
            const modal = document.getElementById('shelfModal');
            const content = document.getElementById('shelfModalContent');
            document.getElementById('shelfModalTitle').textContent = '✏️ 编辑书架位置';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="mb-3">
                        <label class="form-label">位置名称</label>
                        <input type="text" id="shelf-name" class="form-control" value="${name}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">位置描述</label>
                        <input type="text" id="shelf-desc" class="form-control" value="${desc}">
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1" onclick="saveShelfLocation(${id})">保存</button>
                        <button class="btn btn-secondary" onclick="openManageShelfModal()">返回</button>
                    </div>
                </div>
            `;
        }

        // 保存书架位置编辑
        function saveShelfLocation(id) {
            const name = document.getElementById('shelf-name').value.trim();
            const desc = document.getElementById('shelf-desc').value.trim();
            if (!name) { showToast('请输入位置名称', 'error'); return; }

            const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]')?.value ||
                              document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

            fetch(`/api/shelf/location/edit/${id}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken
                },
                body: JSON.stringify({ name, description: desc })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('保存成功');
                    openManageShelfModal();
                    loadShelfLocations();
                } else {
                    showToast(data.error || '保存失败', 'error');
                }
            })
            .catch(error => {
                console.error('保存书架位置失败:', error);
                showToast('保存失败，请重试', 'error');
            });
        }

        // 删除书架位置
        function deleteShelfLocation(id, name) {
            showConfirmModal({
                icon: '📚',
                title: '删除书架位置',
                message: '确定要删除这个书架位置吗？',
                details: [
                    { label: '位置名称', value: name }
                ],
                warning: '相关书籍的存放位置不会被清除',
                btnText: '确认删除',
                onConfirm: () => {
                    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]')?.value ||
                                      document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

                    fetch(`/api/shelf/location/delete/${id}/`, {
                        method: 'POST',
                        headers: { 'X-CSRFToken': csrfToken }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast('删除成功');
                            openManageShelfModal();
                            loadShelfLocations();
                        } else {
                            showToast(data.error || '删除失败', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('删除书架位置失败:', error);
                        showToast('删除失败，请重试', 'error');
                    });
                }
            });
        }

        // ========== 图书分类管理 ==========

        // 加载分类到导航
        function loadCategories() {
            fetch('/api/categories/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const nav = document.getElementById('books-sub-nav');
                        nav.innerHTML = '';

                        // 添加"全部"选项
                        const allItem = document.createElement('div');
                        allItem.className = 'sub-nav-item active';
                        allItem.dataset.category = 'all';
                        allItem.textContent = '全部';
                        allItem.addEventListener('click', function() {
                            document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                            this.classList.add('active');
                            currentCategory = 'all';
                            filterBooks();
                        });
                        nav.appendChild(allItem);

                        // 添加各个分类
                        data.categories.forEach(cat => {
                            const item = document.createElement('div');
                            item.className = 'sub-nav-item';
                            item.dataset.category = cat.name;
                            item.textContent = cat.name;
                            item.addEventListener('click', function() {
                                document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                                this.classList.add('active');
                                currentCategory = cat.name;
                                filterBooks();
                            });
                            // 拖放支持
                            item.addEventListener('dragover', function(e) {
                                e.preventDefault();
                                this.classList.add('drop-target');
                            });
                            item.addEventListener('dragleave', function() {
                                this.classList.remove('drop-target');
                            });
                            item.addEventListener('drop', function(e) {
                                e.preventDefault();
                                this.classList.remove('drop-target');
                                const bookId = e.dataTransfer.getData('bookId');
                                if (bookId) {
                                    updateBookCategory(bookId, this.dataset.category);
                                }
                            });
                            nav.appendChild(item);
                        });
                    }
                });
        }

        // 打开分类管理弹窗
        function openCategoryModal() {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📚 分类管理';

            // 先加载分类列表
            fetch('/api/categories/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        content.innerHTML = `
                            <div class="p-3">
                                <div class="mb-4">
                                    <h6 class="mb-3">添加新分类</h6>
                                    <div class="input-group">
                                        <input type="text" id="newCategoryName" class="form-control" placeholder="输入分类名称">
                                        <button class="btn btn-primary" onclick="addCategory()">添加</button>
                                    </div>
                                </div>
                                <hr>
                                <h6 class="mb-3">现有分类</h6>
                                <div id="categoryList">
                                    ${data.categories.map(cat => `
                                        <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-light rounded" data-category-id="${cat.id}">
                                            <div>
                                                <span class="category-name">${cat.name}</span>
                                                <small class="text-muted ms-2">(${cat.book_count}本书)</small>
                                            </div>
                                            <div>
                                                <button class="btn btn-sm btn-outline-primary me-1" onclick="editCategory(${cat.id}, '${cat.name}')">编辑</button>
                                                <button class="btn btn-sm btn-outline-danger" onclick="deleteCategory(${cat.id}, '${cat.name}', ${cat.book_count})">删除</button>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                                <div class="text-center mt-4">
                                    <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
                                </div>
                            </div>
                        `;
                    }
                });

            modal.style.display = 'flex';
        }

        // 添加分类
        function addCategory() {
            const name = document.getElementById('newCategoryName').value.trim();
            if (!name) {
                showToast('请输入分类名称', 'error');
                return;
            }

            fetch('/api/category/add/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ name: name })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('添加成功');
                    loadCategories();
                    openCategoryModal(); // 刷新弹窗内容
                } else {
                    showToast(data.error || '添加失败', 'error');
                }
            });
        }

        // 编辑分类
        function editCategory(id, oldName) {
            const newName = prompt('请输入新的分类名称:', oldName);
            if (newName && newName.trim() && newName !== oldName) {
                fetch(`/api/category/edit/${id}/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: JSON.stringify({ name: newName.trim() })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('修改成功');
                        loadCategories();
                        openCategoryModal();
                    } else {
                        showToast(data.error || '修改失败', 'error');
                    }
                });
            }
        }

        // 删除分类
        function deleteCategory(id, name, bookCount) {
            const details = [{ label: '分类名称', value: name }];
            let warning = '';
            if (bookCount > 0) {
                details.push({ label: '包含书籍', value: `${bookCount} 本` });
                warning = '删除后这些书将归入"其他"分类';
            }

            showConfirmModal({
                icon: '📂',
                title: '删除分类',
                message: '确定要删除这个分类吗？',
                details: details,
                warning: warning,
                btnText: '确认删除',
                onConfirm: () => {
                    fetch(`/api/category/delete/${id}/`, {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': getCsrfToken()
                        }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast('删除成功');
                            loadCategories();
                            openCategoryModal();
                        } else {
                            showToast(data.error || '删除失败', 'error');
                        }
                    });
                }
            });
        }

        // 加载书架位置到导航（仅加载自定义位置）
        function loadShelfLocations() {
            fetch('/api/shelf/locations/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const nav = document.getElementById('shelf-sub-nav');
                        // 移除之前的自定义位置（保留默认位置）
                        const customItems = nav.querySelectorAll('.sub-nav-item.custom');
                        customItems.forEach(item => item.remove());

                        // 添加自定义位置
                        data.locations.forEach(loc => {
                            const item = document.createElement('div');
                            item.className = 'sub-nav-item custom';
                            item.dataset.shelf = loc.name;
                            item.textContent = loc.name;
                            item.addEventListener('click', function() {
                                document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                                this.classList.add('active');
                                filterShelfBooks(this.dataset.shelf);
                            });
                            nav.appendChild(item);
                        });
                    }
                });
        }

        // 加载借阅人列表（管理员筛选用）
        function loadBorrowersList() {
            const select = document.getElementById('record-search-borrower');
            if (!select) return;  // 非管理员没有这个元素

            fetch('/api/borrowers/')
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.borrowers.length > 0) {
                        // 保留第一个"全部借阅人"选项
                        select.innerHTML = '<option value="">全部借阅人</option>';
                        data.borrowers.forEach(name => {
                            const option = document.createElement('option');
                            option.value = name;
                            option.textContent = name;
                            select.appendChild(option);
                        });

                        // 如果URL中有search_borrower参数，设置选中值
                        const urlParams = new URLSearchParams(window.location.search);
                        const currentBorrower = urlParams.get('search_borrower');
                        if (currentBorrower) {
                            select.value = currentBorrower;
                        }
                    }
                });
        }

        // 关闭书架弹窗
        function closeShelfModal() {
            const modal = document.getElementById('shelfModal');
            if (modal) modal.style.display = 'none';
        }

        document.getElementById('shelfModal')?.addEventListener('click', function(e) {
            if (e.target === this) closeShelfModal();
        });

        // ========== 借阅统计功能 ==========

        // 加载借阅次数数据
        function loadBorrowCountData() {
            fetch('/api/books/borrow-counts/')
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.counts) {
                        // 更新 allBooks 中的借阅次数
                        allBooks.forEach(book => {
                            if (data.counts[book.id]) {
                                book.borrow_count = data.counts[book.id];
                            }
                        });
                        // 如果当前选择的是借阅次数排序，重新排序
                        const sortSelect = document.getElementById('books-sort-select');
                        if (sortSelect && sortSelect.value === 'borrow_count') {
                            filterBooks();
                        }
                    }
                })
                .catch(err => {
                    console.log('加载借阅次数失败:', err);
                });
        }

        // 修复借阅人姓名
        function fixBorrowerNames() {
            showConfirmModal({
                icon: '🔧',
                title: '修复借阅人姓名',
                message: '确定要修复借阅记录中缺失的借阅人姓名吗？',
                warning: '系统将自动匹配用户ID补充姓名',
                btnText: '确认修复',
                onConfirm: () => {
                    fetch('/api/borrow/fix-names/', {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': getCsrfToken()
                        }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast(`修复完成！共修复 ${data.fixed_count} 条记录`);
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            showToast(data.error || '修复失败', 'error');
                        }
                    })
                    .catch(() => {
                        showToast('网络错误', 'error');
                    });
                }
            });
        }

        function loadStatistics() {
            // 显示加载状态
            const loadingHtml = '<p class="text-muted text-center">加载中...</p>';
            const errorHtml = '<p class="text-danger text-center">加载失败，请重试</p>';

            fetch('/api/borrow/statistics/')
                .then(r => {
                    if (!r.ok) throw new Error('网络错误');
                    return r.json();
                })
                .then(data => {
                    if (data.success) {
                        renderStatistics(data.data);
                    } else {
                        // 显示错误信息
                        document.getElementById('stat-borrower-rank').innerHTML = errorHtml;
                        document.getElementById('stat-book-rank').innerHTML = errorHtml;
                        document.getElementById('stat-unreturned').innerHTML = errorHtml;
                        document.getElementById('stat-category').innerHTML = errorHtml;
                    }
                })
                .catch(err => {
                    console.error('加载统计数据失败:', err);
                    document.getElementById('stat-borrower-rank').innerHTML = errorHtml;
                    document.getElementById('stat-book-rank').innerHTML = errorHtml;
                    document.getElementById('stat-unreturned').innerHTML = errorHtml;
                    document.getElementById('stat-category').innerHTML = errorHtml;
                });
        }

        function renderStatistics(stats) {
            // 安全获取数据，防止undefined错误
            const collectionStats = stats.collection_stats || { total: 0, borrowed: 0, by_category: [] };
            const weeklyStats = stats.weekly_stats || { borrows: 0, returns: 0 };
            const borrowerStats = stats.borrower_stats || [];
            const bookStats = stats.book_stats || [];
            const unreturnedBooks = stats.unreturned_books || [];

            // 快速统计
            const totalEl = document.getElementById('stat-total-books');
            const borrowedEl = document.getElementById('stat-borrowed');
            const weeklyEl = document.getElementById('stat-weekly');
            const weeklyReturnsEl = document.getElementById('stat-weekly-returns');

            if (totalEl) totalEl.textContent = collectionStats.total;
            if (borrowedEl) borrowedEl.textContent = collectionStats.borrowed;
            if (weeklyEl) weeklyEl.textContent = weeklyStats.borrows;
            if (weeklyReturnsEl) weeklyReturnsEl.textContent = weeklyStats.returns;

            // 在架书籍数量
            const availableEl = document.getElementById('stat-available-books');
            if (availableEl) {
                availableEl.textContent = collectionStats.total - collectionStats.borrowed;
            }

            // 借阅人排行 - 可点击查看借阅历史
            const borrowerRank = document.getElementById('stat-borrower-rank');
            if (borrowerRank) {
                if (borrowerStats.length > 0) {
                    borrowerRank.innerHTML = borrowerStats.map((b, i) => `
                        <div class="d-flex align-items-center justify-content-between py-2 ${i > 0 ? 'border-top' : ''}" style="cursor: pointer;" onclick="showBorrowerHistory('${b.borrower_name || ''}')">
                            <div>
                                <span class="badge ${i < 3 ? 'bg-warning' : 'bg-secondary'} me-2">${i + 1}</span>
                                ${b.borrower_name || '未知'}
                            </div>
                            <div>
                                <span class="badge bg-primary">${b.count}本</span>
                                <small class="text-muted ms-1">▶</small>
                            </div>
                        </div>
                    `).join('');
                } else {
                    borrowerRank.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
                }
            }

            // 热门书籍 - 可点击查看书籍详情
            const bookRank = document.getElementById('stat-book-rank');
            if (bookRank) {
                if (bookStats.length > 0) {
                    bookRank.innerHTML = bookStats.map((b, i) => {
                        const bookName = b.book__book_name || '未知';
                        return `
                            <div class="d-flex align-items-center justify-content-between py-2 ${i > 0 ? 'border-top' : ''}" style="cursor: pointer;" onclick="showBookDetailByName('${bookName.replace(/'/g, "\\'")}')">
                                <div>
                                    <span class="badge ${i < 3 ? 'bg-warning' : 'bg-secondary'} me-2">${i + 1}</span>
                                    《${bookName}》
                                </div>
                                <div>
                                    <span class="badge bg-primary">${b.count}次</span>
                                    <small class="text-muted ms-1">▶</small>
                                </div>
                            </div>
                        `;
                    }).join('');
                } else {
                    bookRank.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
                }
            }

            // 未归还书籍
            const unreturned = document.getElementById('stat-unreturned');
            if (unreturned) {
                if (unreturnedBooks.length > 0) {
                    unreturned.innerHTML = unreturnedBooks.map(b => `
                        <div class="d-flex justify-content-between py-2 border-top">
                            <div>
                                <div>${b.book_name || '未知'}</div>
                                <small class="text-muted">借阅人：${b.borrower || '未知'}</small>
                            </div>
                            <small class="text-muted">${b.borrow_date || '-'}</small>
                        </div>
                    `).join('');
                } else {
                    unreturned.innerHTML = '<p class="text-muted text-center mb-0">全部已归还 ✓</p>';
                }
            }

            // 藏书分类
            const category = document.getElementById('stat-category');
            if (category) {
                if (collectionStats.by_category && collectionStats.by_category.length > 0) {
                    const total = collectionStats.total || 1;
                    category.innerHTML = collectionStats.by_category.map(c => {
                        const percent = Math.round((c.count || 0) / total * 100);
                        return `
                            <div class="mb-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <span>${c.book_type || '未分类'}</span>
                                    <span>${c.count}本 (${percent}%)</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar" style="width: ${percent}%; background: #667eea;"></div>
                                </div>
                            </div>
                        `;
                    }).join('');
                } else {
                    category.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
                }
            }
        }

        // 初始化借阅记录统计（页面切换时调用）
        function initRecordsStatistics() {
            // 加载借阅人筛选列表（超级管理员）
            if (window.djangoData && window.djangoData.isSuperuser) {
                const borrowerSelect = document.getElementById('record-borrower');
                if (borrowerSelect) {
                    // 从API加载已注册用户
                    fetch('/api/users/')
                        .then(r => r.json())
                        .then(data => {
                            if (data.success) {
                                let options = '<option value="all">全部借阅人</option>';
                                data.users.forEach(user => {
                                    const displayName = user.reader_name || user.username;
                                    options += `<option value="${displayName}">${displayName}</option>`;
                                });
                                borrowerSelect.innerHTML = options;
                            }
                        });
                }
            }
        }

        // ========== 账户信息功能 ==========

        // 加载用户账户信息
        function loadUserInfo() {
            // 账号和注册时间由Django模板直接渲染，这里只更新其他信息
            fetch('/api/user/info/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const user = data.user;
                        const phoneTextEl = document.getElementById('info-phone-text');
                        if (phoneTextEl) {
                            phoneTextEl.textContent = user.phone || '未设置';
                        }
                    }
                })
                .catch(error => {
                    console.error('加载用户信息失败:', error);
                });
        }

        // ========== 成员管理功能 ==========

        // 加载已注册用户列表（仅超级管理员可用）
        function loadMembersList() {
            const container = document.getElementById('members-list');
            if (!container) return;

            container.innerHTML = `
                <div class="settings-card" style="text-align: center; color: #999;">
                    <p>加载中...</p>
                </div>
            `;

            fetch('/api/members/')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.members.length === 0) {
                            container.innerHTML = `
                                <div class="settings-card" style="text-align: center; color: #999;">
                                    <p>暂无注册用户</p>
                                </div>
                            `;
                            return;
                        }
                        container.innerHTML = data.members.map(user => `
                            <div class="settings-card">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar" style="width: 48px; height: 48px; font-size: 18px; margin-right: 12px; overflow: hidden;">
                                            ${user.avatar ? `<img src="${user.avatar}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">` : user.display_name.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <div style="font-weight: 600; font-size: 16px;">${user.display_name}</div>
                                            <small class="text-muted">账号: ${user.account} | ${user.phone}</small>
                                        </div>
                                    </div>
                                    <span class="badge ${user.is_superuser ? 'bg-primary' : 'bg-secondary'}" style="font-size: 12px;">
                                        ${user.role}
                                    </span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center pt-2" style="border-top: 1px solid #f0f0f0;">
                                    <small class="text-muted">
                                        借阅: ${user.total_borrowed}次 | 当前借: ${user.current_borrowed}本
                                    </small>
                                    <div>
                                        <button class="btn btn-sm btn-outline-primary me-1" style="border-radius: 6px; font-size: 12px;" onclick="editMember(${user.id}, '${user.display_name}', '${user.phone}', ${user.is_superuser})">
                                            编辑
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary me-1" style="border-radius: 6px; font-size: 12px;" onclick="resetMemberPassword(${user.id}, '${user.display_name}')">
                                            重置密码
                                        </button>
                                        ${!user.is_superuser ? `
                                        <button class="btn btn-sm btn-outline-danger" style="border-radius: 6px; font-size: 12px;" onclick="deleteMember(${user.id}, '${user.display_name}')">
                                            删除
                                        </button>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    } else {
                        container.innerHTML = `
                            <div class="settings-card" style="text-align: center; color: #999;">
                                <p>${data.error || '无权限查看用户列表'}</p>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    container.innerHTML = `
                        <div class="settings-card" style="text-align: center; color: #999;">
                            <p>加载失败，请刷新重试</p>
                        </div>
                    `;
                });
        }

        // 编辑成员信息
        function editMember(userId, currentName, currentPhone, isSuperuser) {
            // 使用弹窗编辑
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '✏️ 编辑成员信息';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="mb-3">
                        <label class="form-label">用户名</label>
                        <input type="text" class="form-control" id="edit-display-name" value="${currentName}" placeholder="请输入用户名">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">手机号</label>
                        <input type="text" class="form-control" id="edit-phone" value="${currentPhone === '未设置' ? '' : currentPhone}" placeholder="请输入11位手机号">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">角色</label>
                        <select class="form-select" id="edit-role">
                            <option value="member" ${!isSuperuser ? 'selected' : ''}>普通成员</option>
                            <option value="admin" ${isSuperuser ? 'selected' : ''}>管理员</option>
                        </select>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1" onclick="submitEditMember(${userId}, ${isSuperuser})">保存</button>
                        <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
                    </div>
                </div>
            `;
            modal.style.display = 'flex';
        }

        // 提交成员编辑
        function submitEditMember(userId, wasAdmin) {
            const newName = document.getElementById('edit-display-name').value.trim();
            const newPhone = document.getElementById('edit-phone').value.trim();
            const newRole = document.getElementById('edit-role').value;

            if (!newName) {
                showToast('用户名不能为空', 'error');
                return;
            }

            if (newPhone && !/^\d{11}$/.test(newPhone)) {
                showToast('手机号格式不正确，请输入11位数字', 'error');
                return;
            }

            // 如果要把管理员降为普通成员，需要确认
            if (wasAdmin && newRole === 'member') {
                showConfirmModal({
                    icon: '⚠️',
                    title: '权限变更确认',
                    message: '确定要将该管理员降为普通成员吗？',
                    warning: '此操作可能会影响系统管理权限',
                    btnText: '确认降级',
                    onConfirm: () => {
                        doSubmitMemberEdit(userId, newName, newPhone, newRole);
                    }
                });
                return;
            }

            doSubmitMemberEdit(userId, newName, newPhone, newRole);
        }

        function doSubmitMemberEdit(userId, newName, newPhone, newRole) {
            fetch(`/api/member/${userId}/update/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    display_name: newName,
                    phone: newPhone,
                    role: newRole
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('修改成功！', 'success');
                    closeScanModal();
                    loadMembersList();
                } else {
                    showToast(data.error || '修改失败', 'error');
                }
            });
        }

        // 重置成员密码
        function resetMemberPassword(userId, displayName) {
            const newPassword = prompt(`请输入 ${displayName} 的新密码（至少6位）：`);
            if (!newPassword) return;

            if (newPassword.length < 6) {
                showToast('密码长度至少6位', 'error');
                return;
            }

            fetch(`/api/member/${userId}/reset-password/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ password: newPassword })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('密码重置成功！', 'success');
                } else {
                    showToast(data.error || '重置失败', 'error');
                }
            });
        }

        // 删除成员
        function deleteMember(userId, displayName) {
            showConfirmModal({
                icon: '👤',
                title: '删除成员',
                message: '确定要删除这个用户吗？',
                details: [
                    { label: '用户名称', value: displayName }
                ],
                warning: '此操作不可恢复！',
                btnText: '确认删除',
                onConfirm: () => {
                    fetch(`/api/member/${userId}/delete/`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRFToken': getCsrfToken()
                        }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast('删除成功！', 'success');
                            loadMembersList();
                        } else {
                            showToast(data.error || '删除失败', 'error');
                        }
                    });
                }
            });
        }

        // 编辑用户名
        function editDisplayName() {
            const currentName = document.getElementById('info-display-name-text').textContent;
            const newName = prompt('请输入新的用户名：', currentName);
            if (newName && newName !== currentName) {
                fetch('/api/user/update-name/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: JSON.stringify({ display_name: newName })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('info-display-name').textContent = newName;
                        document.getElementById('info-display-name-text').textContent = newName;
                        showToast('用户名修改成功！', 'success');
                    } else {
                        showToast(data.error || '修改失败', 'error');
                    }
                });
            }
        }

        // 编辑手机号
        function editPhone() {
            const currentPhone = document.getElementById('info-phone-text').textContent;
            const newPhone = prompt('请输入新的手机号（留空则清除）：', currentPhone === '未设置' ? '' : currentPhone);
            if (newPhone !== null) {
                fetch('/api/user/update-phone/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: JSON.stringify({ phone: newPhone })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('info-phone').textContent = data.phone;
                        document.getElementById('info-phone-text').textContent = data.phone;
                        showToast('手机号修改成功！', 'success');
                    } else {
                        showToast(data.error || '修改失败', 'error');
                    }
                });
            }
        }

        // 上传头像
        function uploadAvatar(input) {
            if (input.files && input.files[0]) {
                const formData = new FormData();
                formData.append('avatar', input.files[0]);

                fetch('/api/user/upload-avatar/', {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: formData
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        // 刷新页面以显示新头像
                        window.location.reload();
                    } else {
                        showToast(data.error || '上传失败', 'error');
                    }
                });
            }
        }

        // ========== 切换账号弹窗 ==========

        function openSwitchAccountModal() {
            const modalHtml = `
                <div class="switch-account-modal" id="switchAccountModal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 10000; display: flex; align-items: center; justify-content: center;">
                    <div style="background: white; border-radius: 16px; width: 90%; max-width: 400px; max-height: 80vh; overflow: hidden;">
                        <div style="padding: 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                            <h5 style="margin: 0;">🔄 切换账号</h5>
                            <button onclick="closeSwitchAccountModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #999;">×</button>
                        </div>
                        <div id="switch-account-list" style="padding: 20px; max-height: 400px; overflow-y: auto;">
                            <div class="text-center py-4">
                                <div class="spinner-border text-primary"></div>
                                <p class="mt-2 text-muted">加载中...</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
            loadSwitchAccountList();
        }

        function closeSwitchAccountModal() {
            const modal = document.getElementById('switchAccountModal');
            if (modal) modal.remove();
        }

        function loadSwitchAccountList() {
            const container = document.getElementById('switch-account-list');
            fetch('/api/recent-logins/')
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.users.length > 0) {
                        // 过滤掉当前用户
                        const currentUsername = window.djangoData ? window.djangoData.currentUser : '';
                        const users = data.users.filter(u => u.username !== currentUsername);
                        if (users.length === 0) {
                            container.innerHTML = `
                                <div class="text-center py-4 text-muted">
                                    <div style="font-size: 48px;">👤</div>
                                    <p>暂无其他登录账号</p>
                                </div>
                            `;
                            return;
                        }
                        container.innerHTML = users.map(user => `
                            <div class="switch-account-item" onclick="switchToAccount(${user.id}, ${user.can_quick_login}, '${user.display_name}')"
                                 style="display: flex; align-items: center; padding: 15px; border-radius: 12px; cursor: pointer; transition: background 0.2s; margin-bottom: 10px; border: 1px solid #eee;">
                                <div style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 18px; overflow: hidden;">
                                    ${user.avatar ? `<img src="${user.avatar}" style="width: 100%; height: 100%; object-fit: cover;">` : user.display_name.charAt(0).toUpperCase()}
                                </div>
                                <div style="flex: 1; margin-left: 15px;">
                                    <div style="font-weight: 600;">${user.display_name}</div>
                                    <small class="text-muted">${user.phone_masked || user.username} · ${user.is_superuser ? '管理员' : '普通成员'}</small>
                                </div>
                                <div style="text-align: right;">
                                    ${user.can_quick_login
                                        ? '<span style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 12px; font-size: 12px;">快速切换</span>'
                                        : '<span style="background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 12px; font-size: 12px;">需验证</span>'
                                    }
                                </div>
                            </div>
                        `).join('');

                        // 添加hover效果
                        container.querySelectorAll('.switch-account-item').forEach(item => {
                            item.addEventListener('mouseenter', () => item.style.background = '#f8f9fa');
                            item.addEventListener('mouseleave', () => item.style.background = 'white');
                        });
                    } else {
                        container.innerHTML = `
                            <div class="text-center py-4 text-muted">
                                <div style="font-size: 48px;">👤</div>
                                <p>暂无登录记录</p>
                            </div>
                        `;
                    }
                });
        }

        function switchToAccount(userId, canQuickLogin, displayName) {
            if (canQuickLogin) {
                // 10天内，尝试快速登录
                fetch('/api/quick-login/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: JSON.stringify({ user_id: userId })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        window.location.reload();
                    } else if (data.need_password) {
                        showPasswordPrompt(userId, displayName, data.reason);
                    } else {
                        showToast(data.error || '切换失败', 'error');
                    }
                });
            } else {
                // 超过10天，需要密码
                showPasswordPrompt(userId, displayName, '');
            }
        }

        function showPasswordPrompt(userId, displayName, reason) {
            const reasonHtml = reason ? `<div class="alert alert-info" style="margin-bottom: 15px; padding: 10px 15px; border-radius: 8px; font-size: 13px;"><strong>🔒 安全验证：</strong>${reason}</div>` : '';
            const passwordHtml = `
                <div class="password-prompt" style="padding: 20px;">
                    ${reasonHtml}
                    <p style="margin-bottom: 15px;">请输入 <strong>${displayName}</strong> 的密码验证：</p>
                    <input type="password" id="switchPassword" class="form-control" placeholder="请输入密码" style="border-radius: 12px; margin-bottom: 15px;" autofocus autocomplete="new-password">
                    <div style="display: flex; gap: 10px;">
                        <button onclick="loadSwitchAccountList()" class="btn btn-outline-secondary" style="flex: 1; border-radius: 12px;">返回</button>
                        <button onclick="submitSwitchPassword(${userId})" class="btn btn-primary" style="flex: 1; border-radius: 12px;">确认</button>
                    </div>
                </div>
            `;
            document.getElementById('switch-account-list').innerHTML = passwordHtml;
            setTimeout(() => document.getElementById('switchPassword')?.focus(), 100);
        }

        function submitSwitchPassword(userId) {
            const password = document.getElementById('switchPassword').value;
            if (!password) {
                showToast('请输入密码', 'error');
                return;
            }
            fetch('/api/quick-login/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ user_id: userId, password: password })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    showToast(data.error || '密码错误', 'error');
                }
            });
        }

        // ========== 书摘书评功能 ==========

        // 加载书摘书评列表
        function loadNotes() {
            const container = document.getElementById('notes-container');
            const activeNav = document.querySelector('#notes-sub-nav .sub-nav-item.active');
            const noteType = activeNav ? activeNav.dataset.noteType : 'all';
            const bookFilter = document.getElementById('notes-book-filter')?.value || 'all';

            container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><p class="mt-2">加载中...</p></div>';

            let url = `/api/notes/?note_type=${noteType}`;
            if (bookFilter !== 'all') {
                url += `&book_id=${bookFilter}`;
            }

            fetch(url)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        renderNotes(data.notes);
                    } else {
                        container.innerHTML = '<div class="text-center py-5 text-muted">加载失败</div>';
                    }
                })
                .catch(() => {
                    container.innerHTML = '<div class="text-center py-5 text-muted">网络错误</div>';
                });
        }

        // 渲染书摘书评列表
        function renderNotes(notes) {
            const container = document.getElementById('notes-container');
            if (notes.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-5" style="color: #999;">
                        <div style="font-size: 48px;">📝</div>
                        <h4>暂无书摘书评</h4>
                        <p class="mt-2">点击右上角添加你的第一条书摘或书评</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = notes.map(note => `
                <div class="card mb-3" style="border-radius: 12px; border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <span class="badge ${note.note_type === 'excerpt' ? 'bg-info' : 'bg-warning'} me-2">${note.note_type_display}</span>
                                <small class="text-muted">《${note.book_name}》</small>
                                ${note.note_type === 'review' ? `<small class="text-muted ms-2">by ${note.user}</small>` : ''}
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <small class="text-muted">${note.created_at}</small>
                                ${note.is_owner ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteNote(${note.id})" title="删除">🗑️</button>` : ''}
                            </div>
                        </div>
                        <h6 class="card-title">${note.title}</h6>
                        <p class="card-text text-muted small" style="white-space: pre-wrap;">${note.content}</p>
                        ${note.page_number ? `<small class="text-muted">📖 第 ${note.page_number} 页</small>` : ''}
                    </div>
                </div>
            `).join('');
        }

        // 加载书籍筛选下拉框
        function loadNotesBookFilter() {
            const select = document.getElementById('notes-book-filter');
            select.innerHTML = '<option value="all">全部书籍</option>';
            allBooks.forEach(book => {
                select.innerHTML += `<option value="${book.id}">${book.book_name}</option>`;
            });
        }

        // 书摘书评分类切换
        document.querySelectorAll('#notes-sub-nav .sub-nav-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('#notes-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                loadNotes();
            });
        });

        // 筛选书摘书评
        function filterNotes() {
            loadNotes();
        }

        // 打开添加书摘书评弹窗
        function openAddNoteModal() {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📝 添加书摘/书评';

            let bookOptions = allBooks.map(b => `<option value="${b.id}">${b.book_name}</option>`).join('');

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="mb-3">
                        <label class="form-label">选择书籍 *</label>
                        <select id="note-book" class="form-select" required>
                            <option value="">请选择书籍</option>
                            ${bookOptions}
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">类型 *</label>
                        <select id="note-type" class="form-select">
                            <option value="excerpt">书摘</option>
                            <option value="review">书评</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">标题 *</label>
                        <input type="text" id="note-title" class="form-control" placeholder="请输入标题">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">页码（可选）</label>
                        <input type="number" id="note-page" class="form-control" placeholder="如：42">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">内容 *</label>
                        <textarea id="note-content" class="form-control" rows="5" placeholder="请输入内容..."></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1" onclick="submitNote()">提交</button>
                        <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
                    </div>
                </div>
            `;
            modal.style.display = 'flex';
        }

        // 提交书摘书评
        function submitNote() {
            const bookId = document.getElementById('note-book').value;
            const noteType = document.getElementById('note-type').value;
            const title = document.getElementById('note-title').value.trim();
            const page = document.getElementById('note-page').value;
            const content = document.getElementById('note-content').value.trim();

            if (!bookId || !title || !content) {
                showToast('请填写完整信息', 'error');
                return;
            }

            fetch('/api/note/add/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    book_id: bookId,
                    note_type: noteType,
                    title: title,
                    page_number: page || null,
                    content: content
                })
            })
            .then(r => {
                if (!r.ok) {
                    throw new Error('服务器错误: ' + r.status);
                }
                return r.json();
            })
            .then(data => {
                if (data.success) {
                    showToast('添加成功');
                    closeScanModal();
                    loadNotes();
                } else {
                    showToast(data.error || '添加失败', 'error');
                }
            })
            .catch(err => {
                console.error('提交错误:', err);
                showToast('网络错误，请检查登录状态', 'error');
            });
        }

        // 删除书摘书评
        function deleteNote(noteId) {
            showConfirmModal({
                icon: '📝',
                title: '删除书摘书评',
                message: '确定要删除这条记录吗？',
                warning: '此操作不可恢复',
                btnText: '确认删除',
                onConfirm: () => {
                    fetch(`/api/note/${noteId}/delete/`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': getCsrfToken()
                        }
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast('删除成功');
                            loadNotes();
                        } else {
                            showToast(data.error || '删除失败', 'error');
                        }
                    })
                    .catch(() => {
                        showToast('网络错误', 'error');
                    });
                }
            });
        }

        // ========== 通用确认模态框 ==========
        let confirmCallback = null;

        function showConfirmModal(options) {
            const modal = document.getElementById('confirmModal');
            const icon = document.getElementById('confirmModalIcon');
            const title = document.getElementById('confirmModalTitle');
            const body = document.getElementById('confirmModalBody');
            const btn = document.getElementById('confirmModalBtn');

            icon.textContent = options.icon || '⚠️';
            title.textContent = options.title || '确认操作';
            btn.textContent = options.btnText || '确认删除';

            let bodyHtml = `<p>${options.message || '确定要执行此操作吗？'}</p>`;
            if (options.details && options.details.length > 0) {
                bodyHtml += '<div class="detail-box">';
                options.details.forEach(d => {
                    bodyHtml += `<div class="detail-item"><span class="detail-label">${d.label}</span><span class="detail-value">${d.value}</span></div>`;
                });
                bodyHtml += '</div>';
            }
            if (options.warning) {
                bodyHtml += `<p class="text-danger small mt-2">${options.warning}</p>`;
            }
            body.innerHTML = bodyHtml;

            confirmCallback = options.onConfirm || null;
            modal.classList.add('show');
        }

        function closeConfirmModal() {
            const modal = document.getElementById('confirmModal');
            modal.classList.remove('show');
            confirmCallback = null;
        }

        function executeConfirm() {
            if (confirmCallback) {
                confirmCallback();
            }
            closeConfirmModal();
        }

        // 获取CSRF Token
        function getCsrfToken() {
            // 优先从隐藏input获取
            const input = document.querySelector('[name=csrfmiddlewaretoken]');
            if (input && input.value) return input.value;

            // 从cookie获取
            const match = document.cookie.match(/csrftoken=([^;]+)/);
            if (match && match[1]) return match[1];

            return '';
        }

        // ========== 借阅提醒功能 ==========
        function loadBorrowReminders() {
            fetch('/api/borrow/reminders/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        renderBorrowReminders(data);
                    }
                })
                .catch(err => console.error('加载借阅提醒失败:', err));
        }

        function renderBorrowReminders(data) {
            const section = document.getElementById('borrow-reminders-section');
            const container = document.getElementById('borrow-reminders-list');

            if (!section || !container) return;

            const overdue = data.overdue || [];
            const reminders = data.reminders || [];

            if (overdue.length === 0 && reminders.length === 0) {
                section.style.display = 'none';
                return;
            }

            section.style.display = 'block';
            let html = '';

            if (overdue.length > 0) {
                html += '<div class="mb-3"><h6 class="text-danger">🔴 超期未还（超过30天）</h6><ul class="list-unstyled">';
                overdue.forEach(item => {
                    html += `<li class="d-flex justify-content-between align-items-center py-2 border-bottom">
                        <div>
                            <strong>${item.book_name}</strong>
                            <small class="text-muted ms-2">借阅人：${item.borrower}</small>
                        </div>
                        <span class="badge bg-danger">${item.days}天</span>
                    </li>`;
                });
                html += '</ul></div>';
            }

            if (reminders.length > 0) {
                html += '<div><h6 class="text-warning">🟡 即将提醒（超过14天）</h6><ul class="list-unstyled">';
                reminders.forEach(item => {
                    html += `<li class="d-flex justify-content-between align-items-center py-2 border-bottom">
                        <div>
                            <strong>${item.book_name}</strong>
                            <small class="text-muted ms-2">借阅人：${item.borrower}</small>
                        </div>
                        <span class="badge bg-warning text-dark">${item.days}天</span>
                    </li>`;
                });
                html += '</ul></div>';
            }

            container.innerHTML = html;
        }

        // ========== 导入导出书单功能 ==========
        function exportBooks() {
            showToast('正在导出书单...', 'info');
            window.location.href = '/api/books/export/';
        }

        function openImportModal() {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📥 批量导入书单';

            content.innerHTML = `
                <div class="isbn-input-section">
                    <div class="alert alert-info">
                        <strong>📋 导入说明：</strong><br>
                        • 支持 Excel (.xlsx, .xls) 和 CSV 格式文件<br>
                        • <strong>必填列</strong>：书名、作者<br>
                        • <strong>可选列</strong>：ISBN、分类、出版社、出版日期、存放位置、简介<br>
                        • 系统会自动跳过重复的书籍（按ISBN或书名+作者判断）
                    </div>

                    <div class="d-flex gap-2 mb-3">
                        <a href="/api/books/template/" class="btn btn-outline-primary btn-sm">
                            📥 下载模板文件
                        </a>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">选择文件</label>
                        <input type="file" id="import-file" class="form-control" accept=".xlsx,.xls,.csv">
                        <div class="form-text">支持 .xlsx、.xls、.csv 格式</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1" onclick="submitImport()">
                            <span id="import-btn-text">🚀 开始导入</span>
                        </button>
                        <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
                    </div>
                    <div id="import-result" class="mt-3" style="display: none;"></div>
                </div>
            `;
            modal.style.display = 'flex';
        }

        function submitImport() {
            const fileInput = document.getElementById('import-file');
            const resultDiv = document.getElementById('import-result');
            const btnText = document.getElementById('import-btn-text');

            if (!fileInput.files.length) {
                showToast('请选择要上传的文件', 'error');
                return;
            }

            const file = fileInput.files[0];
            const ext = file.name.split('.').pop().toLowerCase();

            if (!['xlsx', 'xls', 'csv'].includes(ext)) {
                showToast('请选择 Excel 或 CSV 格式的文件', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('file', file);

            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div> 正在导入，请稍候...</div>';
            btnText.textContent = '导入中...';

            fetch('/api/books/import/', {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCsrfToken()
                },
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                btnText.textContent = '🚀 开始导入';

                if (data.success) {
                    let resultHtml = `
                        <div class="alert alert-success mb-2">
                            <strong>✅ ${data.message}</strong>
                        </div>
                        <div class="import-stats">
                            <span class="badge bg-success me-2">成功 ${data.imported}</span>
                            ${data.skipped > 0 ? `<span class="badge bg-warning text-dark me-2">跳过 ${data.skipped}</span>` : ''}
                            ${data.failed > 0 ? `<span class="badge bg-danger">失败 ${data.failed}</span>` : ''}
                        </div>
                    `;

                    if (data.errors && data.errors.length > 0) {
                        resultHtml += `
                            <div class="mt-2">
                                <small class="text-muted">错误详情：</small>
                                <ul class="text-danger small mb-0">
                                    ${data.errors.map(e => `<li>${e}</li>`).join('')}
                                </ul>
                            </div>
                        `;
                    }

                    resultDiv.innerHTML = resultHtml;

                    if (data.imported > 0) {
                        showToast(`成功导入 ${data.imported} 本书籍`);
                        // 2秒后刷新页面
                        setTimeout(() => {
                            location.reload();
                        }, 2000);
                    }
                } else {
                    resultDiv.innerHTML = `<div class="alert alert-danger">❌ ${data.error}</div>`;
                    showToast('导入失败', 'error');
                }
            })
            .catch(err => {
                btnText.textContent = '🚀 开始导入';
                resultDiv.innerHTML = `<div class="alert alert-danger">网络错误，请检查连接后重试</div>`;
                showToast('网络错误', 'error');
            });
        }

        // ========== AI 聊天功能 ==========
        let aiChatMessages = [];

        // ========== 图图拖拽功能 ==========
        let isDragging = false;
        let dragStartTime = 0;
        let dragStartX = 0;
        let dragStartY = 0;
        let ballStartX = 0;
        let ballStartY = 0;
        let hasMoved = false;

        function initDraggableBall() {
            const ball = document.getElementById('aiChatBall');
            if (!ball) return;

            // 从本地存储恢复位置
            const savedPos = localStorage.getItem('aiChatBallPos');
            if (savedPos) {
                const pos = JSON.parse(savedPos);
                ball.style.right = 'auto';
                ball.style.left = pos.left + 'px';
                ball.style.top = pos.top + 'px';
                ball.style.transform = 'none';
            }

            // 鼠标事件
            ball.addEventListener('mousedown', startDrag);
            document.addEventListener('mousemove', onDrag);
            document.addEventListener('mouseup', endDrag);

            // 触摸事件（移动端）
            ball.addEventListener('touchstart', startDragTouch, { passive: false });
            document.addEventListener('touchmove', onDragTouch, { passive: false });
            document.addEventListener('touchend', endDragTouch);
        }

        function startDrag(e) {
            const ball = document.getElementById('aiChatBall');
            isDragging = true;
            hasMoved = false;
            dragStartTime = Date.now();
            dragStartX = e.clientX;
            dragStartY = e.clientY;

            const rect = ball.getBoundingClientRect();
            ballStartX = rect.left;
            ballStartY = rect.top;

            ball.classList.add('dragging');
            ball.style.right = 'auto';
            ball.style.transform = 'none';
            e.preventDefault();
        }

        function startDragTouch(e) {
            if (e.touches.length !== 1) return;
            const touch = e.touches[0];
            const ball = document.getElementById('aiChatBall');
            isDragging = true;
            hasMoved = false;
            dragStartTime = Date.now();
            dragStartX = touch.clientX;
            dragStartY = touch.clientY;

            const rect = ball.getBoundingClientRect();
            ballStartX = rect.left;
            ballStartY = rect.top;

            ball.classList.add('dragging');
            ball.style.right = 'auto';
            ball.style.transform = 'none';
            e.preventDefault();
        }

        function onDrag(e) {
            if (!isDragging) return;
            const ball = document.getElementById('aiChatBall');

            const deltaX = e.clientX - dragStartX;
            const deltaY = e.clientY - dragStartY;

            if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
                hasMoved = true;
            }

            let newX = ballStartX + deltaX;
            let newY = ballStartY + deltaY;

            // 边界限制
            const ballSize = 56;
            newX = Math.max(0, Math.min(window.innerWidth - ballSize, newX));
            newY = Math.max(0, Math.min(window.innerHeight - ballSize, newY));

            ball.style.left = newX + 'px';
            ball.style.top = newY + 'px';
        }

        function onDragTouch(e) {
            if (!isDragging || e.touches.length !== 1) return;
            const touch = e.touches[0];
            const ball = document.getElementById('aiChatBall');

            const deltaX = touch.clientX - dragStartX;
            const deltaY = touch.clientY - dragStartY;

            if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
                hasMoved = true;
            }

            let newX = ballStartX + deltaX;
            let newY = ballStartY + deltaY;

            const ballSize = 56;
            newX = Math.max(0, Math.min(window.innerWidth - ballSize, newX));
            newY = Math.max(0, Math.min(window.innerHeight - ballSize, newY));

            ball.style.left = newX + 'px';
            ball.style.top = newY + 'px';
            e.preventDefault();
        }

        function endDrag(e) {
            if (!isDragging) return;
            const ball = document.getElementById('aiChatBall');
            ball.classList.remove('dragging');
            saveBallPosition();
            isDragging = false;
        }

        function endDragTouch(e) {
            if (!isDragging) return;
            const ball = document.getElementById('aiChatBall');
            ball.classList.remove('dragging');
            saveBallPosition();
            isDragging = false;
        }

        function saveBallPosition() {
            const ball = document.getElementById('aiChatBall');
            if (!ball) return;
            const rect = ball.getBoundingClientRect();
            localStorage.setItem('aiChatBallPos', JSON.stringify({
                left: rect.left,
                top: rect.top
            }));
        }

        function toggleAiChat() {
            // 如果正在拖拽或刚移动过，不打开面板
            if (hasMoved) {
                hasMoved = false;
                return;
            }
            const ball = document.getElementById('aiChatBall');
            const panel = document.getElementById('aiChatPanel');

            // 根据球的位置调整面板位置
            const ballRect = ball.getBoundingClientRect();
            const panelWidth = 360;
            const panelHeight = 480;

            // 默认面板在球的左边
            let panelLeft = ballRect.left - panelWidth - 16;
            let panelTop = ballRect.top + (ballRect.height / 2) - (panelHeight / 2);

            // 如果左边空间不够，放在右边
            if (panelLeft < 10) {
                panelLeft = ballRect.right + 16;
            }

            // 如果右边也不够，放在左边并调整
            if (panelLeft + panelWidth > window.innerWidth - 10) {
                panelLeft = 10;
            }

            // 上下边界调整
            if (panelTop < 10) {
                panelTop = 10;
            }
            if (panelTop + panelHeight > window.innerHeight - 10) {
                panelTop = window.innerHeight - panelHeight - 10;
            }

            panel.style.left = panelLeft + 'px';
            panel.style.top = panelTop + 'px';
            panel.style.right = 'auto';
            panel.style.transform = 'none';

            panel.classList.toggle('active');
            if (panel.classList.contains('active')) {
                document.getElementById('aiChatInput').focus();
            }
        }

        // 新建对话
        function startNewChat() {
            // 创建新会话
            const newId = createNewChatSession();
            currentSessionId = newId;
            aiChatHistory = [];
            lastBotMessage = '';

            // 重置聊天界面
            const container = document.getElementById('aiChatMessages');
            const now = new Date();
            const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
            container.innerHTML = `
                <div class="ai-message ai-bot">
                    <div class="ai-message-content">
                        <p class="ai-paragraph">你好！我是图图，你的图书助手。</p>
                        <p class="ai-paragraph">有什么我可以帮你的吗？</p>
                    </div>
                    <div class="ai-message-time">${timeStr}</div>
                </div>
            `;

            // 更新历史列表
            updateHistoryListUI();

            showToast('已开始新对话');
            document.getElementById('aiChatInput').focus();
        }

        // 清除当前对话
        function clearAiChatHistory() {
            if (!confirm('确定要清空当前对话吗？')) {
                return;
            }

            // 清空当前会话消息
            aiChatHistory = [];

            // 更新会话数据
            if (currentSessionId) {
                const session = chatSessions.find(s => s.id === currentSessionId);
                if (session) {
                    session.messages = [];
                    session.title = '新对话';
                    saveChatSessions();
                }
            }

            // 重置聊天界面
            const container = document.getElementById('aiChatMessages');
            const now = new Date();
            const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
            container.innerHTML = `
                <div class="ai-message ai-bot">
                    <div class="ai-message-content"><p class="ai-paragraph">对话已清空！</p><p class="ai-paragraph">我是图图，有什么可以帮你的吗？</p></div>
                    <div class="ai-message-time">${timeStr}</div>
                </div>
            `;

            // 更新历史列表
            updateHistoryListUI();

            showToast('当前对话已清空');
        }

        // 加载聊天历史记录
        function loadChatHistory() {
            fetch('/api/ai/chat/history/')
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.messages.length > 0) {
                        const container = document.getElementById('aiChatMessages');

                        // 清空默认消息
                        container.innerHTML = '';

                        // 渲染历史消息
                        data.messages.forEach(msg => {
                            const type = msg.role === 'user' ? 'user' : 'bot';
                            appendAiMessage(msg.content, type);

                            // 同步更新前端历史记录数组
                            aiChatHistory.push({
                                role: msg.role === 'user' ? 'user' : 'assistant',
                                content: msg.content
                            });
                        });

                        // 更新最后一条机器人消息
                        const lastBotMsg = data.messages.filter(m => m.role === 'assistant').pop();
                        if (lastBotMsg) {
                            lastBotMessage = lastBotMsg.content;
                        }

                        // 滚动到底部
                        container.scrollTop = container.scrollHeight;
                    }
                })
                .catch(err => {
                    console.error('加载聊天历史失败:', err);
                });
        }

        function handleAiChatKeypress(event) {
            if (event.key === 'Enter') {
                sendAiMessage();
            }
        }

        // ========== AI 聊天状态 ==========
        let isAiLoading = false;
        let lastBotMessage = '你好！我是图图，你的图书助手。有什么我可以帮你的吗？'; // 初始化为欢迎消息
        let aiChatHistory = []; // 当前对话历史记录
        let chatSessions = []; // 所有对话会话
        let currentSessionId = null; // 当前活动会话ID

        // 初始化对话会话
        function initChatSessions() {
            const saved = localStorage.getItem('aiChatSessions');
            if (saved) {
                try {
                    chatSessions = JSON.parse(saved);
                    // 如果有历史会话，加载最近的
                    if (chatSessions.length > 0) {
                        const latest = chatSessions[0];
                        loadChatSession(latest.id);
                    }
                } catch (e) {
                    chatSessions = [];
                }
            }
        }

        // 保存对话会话到本地存储
        function saveChatSessions() {
            localStorage.setItem('aiChatSessions', JSON.stringify(chatSessions));
        }

        // 创建新对话会话
        function createNewChatSession() {
            const id = 'session_' + Date.now();
            const session = {
                id: id,
                title: '新对话',
                messages: [],
                createdAt: new Date().toISOString()
            };
            chatSessions.unshift(session);
            saveChatSessions();
            return id;
        }

        // 更新当前会话
        function updateCurrentSession() {
            if (!currentSessionId) return;
            const session = chatSessions.find(s => s.id === currentSessionId);
            if (session) {
                session.messages = [...aiChatHistory];
                // 根据第一条用户消息更新标题
                const firstUserMsg = session.messages.find(m => m.role === 'user');
                if (firstUserMsg) {
                    session.title = firstUserMsg.content.substring(0, 20) + (firstUserMsg.content.length > 20 ? '...' : '');
                }
                saveChatSessions();
            }
        }

        // 加载指定会话
        function loadChatSession(sessionId) {
            const session = chatSessions.find(s => s.id === sessionId);
            if (!session) return;

            currentSessionId = sessionId;
            aiChatHistory = [...session.messages];

            const container = document.getElementById('aiChatMessages');
            container.innerHTML = '';

            if (session.messages.length === 0) {
                const now = new Date();
                const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
                container.innerHTML = `
                    <div class="ai-message ai-bot">
                        <div class="ai-message-content"><p class="ai-paragraph">你好！我是图图，你的图书助手。</p><p class="ai-paragraph">有什么我可以帮你的吗？</p></div>
                        <div class="ai-message-time">${timeStr}</div>
                    </div>
                `;
            } else {
                session.messages.forEach(msg => {
                    const type = msg.role === 'user' ? 'user' : 'bot';
                    appendAiMessage(msg.content, type, msg.time);
                });
            }

            // 更新历史列表高亮
            updateHistoryListUI();
        }

        // 删除对话会话
        function deleteChatSession(sessionId, event) {
            event.stopPropagation();
            const index = chatSessions.findIndex(s => s.id === sessionId);
            if (index > -1) {
                chatSessions.splice(index, 1);
                saveChatSessions();

                // 如果删除的是当前会话
                if (currentSessionId === sessionId) {
                    if (chatSessions.length > 0) {
                        loadChatSession(chatSessions[0].id);
                    } else {
                        startNewChat();
                    }
                }

                updateHistoryListUI();
                showToast('对话已删除');
            }
        }

        // 切换历史侧边栏
        function toggleChatHistory() {
            const sidebar = document.getElementById('aiHistorySidebar');
            if (sidebar.style.display === 'none') {
                sidebar.style.display = 'flex';
                updateHistoryListUI();
            } else {
                sidebar.style.display = 'none';
            }
        }

        // 更新历史列表UI
        function updateHistoryListUI() {
            const list = document.getElementById('aiHistoryList');
            if (!list) return;

            if (chatSessions.length === 0) {
                list.innerHTML = `
                    <div class="ai-history-empty">
                        <div class="ai-history-empty-icon">💬</div>
                        <p>暂无历史对话</p>
                        <p class="small">点击"新对话"开始聊天</p>
                    </div>
                `;
                return;
            }

            list.innerHTML = chatSessions.map(session => {
                const date = new Date(session.createdAt);
                const timeStr = date.getMonth() + 1 + '/' + date.getDate() + ' ' +
                               date.getHours().toString().padStart(2, '0') + ':' +
                               date.getMinutes().toString().padStart(2, '0');
                const isActive = session.id === currentSessionId;
                return `
                    <div class="ai-history-item ${isActive ? 'active' : ''}" onclick="loadChatSession('${session.id}')">
                        <span class="ai-history-item-delete" onclick="deleteChatSession('${session.id}', event)" title="删除">×</span>
                        <div class="ai-history-item-title">${session.title || '新对话'}</div>
                        <div class="ai-history-item-time">${timeStr} · ${session.messages.length}条消息</div>
                    </div>
                `;
            }).join('');
        }

        function sendAiMessage() {
            const input = document.getElementById('aiChatInput');
            const message = input.value.trim();

            if (!message || isAiLoading) return;

            // 获取当前时间
            const now = new Date();
            const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

            // 显示用户消息
            appendAiMessage(message, 'user');
            input.value = '';

            // 添加到历史记录（包含时间）
            aiChatHistory.push({ role: 'user', content: message, time: timeStr });

            // 如果没有当前会话，创建一个
            if (!currentSessionId) {
                currentSessionId = createNewChatSession();
            }

            // 更新会话数据
            updateCurrentSession();

            // 显示loading状态
            isAiLoading = true;
            const sendBtn = document.getElementById('aiSendBtn');
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<span class="ai-loading-dots">思考中</span>';

            // 创建一个空的机器人消息容器（用于流式填充）
            const container = document.getElementById('aiChatMessages');
            const msgId = 'stream-msg-' + Date.now();
            const msgDiv = document.createElement('div');
            msgDiv.id = msgId;
            msgDiv.className = 'ai-message ai-bot';
            msgDiv.innerHTML = '<div class="ai-message-content"><span class="ai-stream-cursor">|</span></div>';
            container.appendChild(msgDiv);
            container.scrollTop = container.scrollHeight;

            // 用于累积完整回复
            let fullReply = '';

            // 发送流式请求
            const recentHistory = aiChatHistory.slice(-10);

            fetch('/api/ai/chat/stream/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    message: message,
                    history: recentHistory
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应异常');
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';

                // 递归读取流
                function readStream() {
                    return reader.read().then(({ done, value }) => {
                        if (done) {
                            // 流结束，清理并保存历史
                            finishStreaming(msgId, fullReply);
                            return;
                        }

                        // 解码数据
                        buffer += decoder.decode(value, { stream: true });

                        // 解析 SSE 数据
                        const lines = buffer.split('\n');
                        buffer = lines.pop() || ''; // 保留最后一个不完整的行

                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                const data = line.slice(6).trim();

                                if (data === '[DONE]') {
                                    // 结束标志
                                    finishStreaming(msgId, fullReply);
                                    return;
                                }

                                try {
                                    const json = JSON.parse(data);
                                    if (json.content) {
                                        fullReply += json.content;
                                        updateStreamMessage(msgId, fullReply);
                                    } else if (json.error) {
                                        fullReply = '抱歉，出了点问题：' + json.error;
                                        updateStreamMessage(msgId, fullReply);
                                        finishStreaming(msgId, fullReply);
                                        return;
                                    }
                                } catch (e) {
                                    // JSON 解析错误，忽略
                                }
                            }
                        }

                        // 继续读取
                        return readStream();
                    });
                }

                return readStream();
            })
            .catch(error => {
                console.error('流式请求失败:', error);
                updateStreamMessage(msgId, '网络错误，请检查连接');
                finishStreaming(msgId, fullReply || '网络错误，请检查连接');
            });

            // 更新流式消息内容
            function updateStreamMessage(id, content) {
                const el = document.getElementById(id);
                if (el) {
                    const formatted = formatMessageContent(content);
                    el.innerHTML = `<div class="ai-message-content">${formatted}<span class="ai-stream-cursor">|</span></div>`;
                    // 滚动到底部
                    const container = document.getElementById('aiChatMessages');
                    container.scrollTop = container.scrollHeight;
                }
            }

            // 完成流式输出
            function finishStreaming(id, content) {
                // 移除光标，显示最终内容
                const el = document.getElementById(id);
                const now = new Date();
                const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

                if (el) {
                    const formatted = formatMessageContent(content || '抱歉，没有收到回复');
                    el.innerHTML = `<div class="ai-message-content">${formatted}</div><div class="ai-message-time">${timeStr}</div>`;
                }

                // 重置状态
                sendBtn.disabled = false;
                sendBtn.textContent = '发送';
                isAiLoading = false;
                lastBotMessage = content;

                // 添加到历史记录（包含时间）
                if (content) {
                    aiChatHistory.push({ role: 'assistant', content: content, time: timeStr });
                    // 更新会话数据
                    updateCurrentSession();
                }
            }
        }

        function appendThinkingMessage() {
            const container = document.getElementById('aiChatMessages');
            const id = 'thinking-' + Date.now();
            const div = document.createElement('div');
            div.id = id;
            div.className = 'ai-message ai-bot ai-thinking';
            div.innerHTML = '<div class="ai-message-content"><span class="ai-loading-dots">正在思考</span></div>';
            container.appendChild(div);
            container.scrollTop = container.scrollHeight;
            return id;
        }

        function removeThinkingMessage(id) {
            const el = document.getElementById(id);
            if (el) el.remove();
        }

        function appendAiMessage(content, type, customTime) {
            const container = document.getElementById('aiChatMessages');
            const div = document.createElement('div');
            div.className = `ai-message ai-${type}`;

            // 处理文本格式：换行、分段
            const formattedContent = formatMessageContent(content);

            // 获取时间戳
            let timeStr;
            if (customTime) {
                timeStr = customTime;
            } else {
                const now = new Date();
                timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
            }

            if (type === 'bot') {
                div.innerHTML = `<div class="ai-message-content">${formattedContent}</div><div class="ai-message-time">${timeStr}</div>`;
                // 存储最后一条机器人消息
                lastBotMessage = content;
            } else {
                div.innerHTML = `<div class="ai-message-content">${formattedContent}</div><div class="ai-message-time">${timeStr}</div>`;
            }

            container.appendChild(div);
            container.scrollTop = container.scrollHeight;
        }

        // 格式化消息内容：处理换行、列表等
        function formatMessageContent(content) {
            if (!content) return '';

            // 转义HTML特殊字符
            let text = content
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');

            // 处理列表项（以 - 或 • 或数字开头）
            text = text.replace(/^[-•]\s*(.+)$/gm, '<li>$1</li>');
            text = text.replace(/^(\d+)[.、)]\s*(.+)$/gm, '<li>$2</li>');

            // 包装连续的列表项
            text = text.replace(/(<li>.*<\/li>\n?)+/g, function(match) {
                return '<ul class="ai-list">' + match + '</ul>';
            });

            // 处理换行（两个换行符变成段落，单个换行符变成<br>）
            text = text.replace(/\n\n+/g, '</p><p class="ai-paragraph">');
            text = text.replace(/\n/g, '<br>');

            // 包装成段落
            text = '<p class="ai-paragraph">' + text + '</p>';

            // 处理书名号
            text = text.replace(/《(.+?)》/g, '<span class="ai-book-title">《$1》</span>');

            return text;
        }

        // ========== 语音功能 ==========
        let recognition = null;
        let isRecording = false;
        let userStoppedRecording = false; // 标记是否用户主动停止

        // 语音输入
        window.startVoiceInput = function() {
            const voiceBtn = document.getElementById('aiVoiceBtn');

            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                alert('您的浏览器不支持语音输入功能，请使用Chrome浏览器');
                return;
            }

            if (isRecording) {
                userStoppedRecording = true;
                stopVoiceInput();
                return;
            }

            userStoppedRecording = false;
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();
            recognition.lang = 'zh-CN';
            recognition.continuous = true; // 持续识别，不会因停顿而停止
            recognition.interimResults = true;

            recognition.onstart = function() {
                isRecording = true;
                voiceBtn.classList.add('recording');
                voiceBtn.textContent = '⏹';
            };

            recognition.onresult = function(event) {
                let finalTranscript = '';
                let interimTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                document.getElementById('aiChatInput').value = finalTranscript || interimTranscript;
            };

            recognition.onerror = function(event) {
                console.error('语音识别错误:', event.error);
                if (event.error !== 'no-speech') {
                    stopVoiceInput();
                }
            };

            recognition.onend = function() {
                // 只有用户主动停止时才重置状态
                if (userStoppedRecording) {
                    const voiceBtn = document.getElementById('aiVoiceBtn');
                    isRecording = false;
                    voiceBtn.classList.remove('recording');
                    voiceBtn.textContent = '🎤';
                } else if (isRecording) {
                    // 非用户主动停止，自动重启
                    try {
                        recognition.start();
                    } catch(e) {
                        stopVoiceInput();
                    }
                }
            };

            recognition.start();
        };

        function stopVoiceInput() {
            const voiceBtn = document.getElementById('aiVoiceBtn');
            isRecording = false;
            userStoppedRecording = true;
            voiceBtn.classList.remove('recording');
            voiceBtn.textContent = '🎤';
            if (recognition) {
                recognition.stop();
                recognition = null;
            }
        }

        // ========== 语音合成功能 ==========
        let isSpeaking = false;
        let currentUtterance = null;
        let chineseVoice = null;
        let currentAudio = null; // 用于TTS音频播放

        // 初始化语音：选择最佳的中文语音（浏览器原生TTS备用）
        function initVoice() {
            if (!window.speechSynthesis) return;

            const voices = window.speechSynthesis.getVoices();
            const preferredVoices = [
                'Microsoft Huihui',
                'Google 普通话（中国大陆）',
                'Ting-Ting',
                'Sin-Ji',
                'Yaoyao',
            ];

            for (let voice of voices) {
                for (let name of preferredVoices) {
                    if (voice.name && voice.name.includes(name)) {
                        chineseVoice = voice;
                        return;
                    }
                }
            }

            for (let voice of voices) {
                if (voice.lang && voice.lang.includes('zh')) {
                    chineseVoice = voice;
                    return;
                }
            }
        }

        if (window.speechSynthesis) {
            window.speechSynthesis.onvoiceschanged = initVoice;
            initVoice();
        }

        // 使用火山方舟TTS朗读（优先）
        async function speakWithTTS(text) {
            try {
                const response = await fetch('/api/ai/tts/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCsrfToken()
                    },
                    body: JSON.stringify({ text: text })
                });

                const data = await response.json();

                if (data.success && data.audio) {
                    // 创建音频并播放
                    const audioData = 'data:audio/mp3;base64,' + data.audio;
                    currentAudio = new Audio(audioData);

                    currentAudio.onplay = function() {
                        isSpeaking = true;
                        updateSpeakButton(true);
                    };

                    currentAudio.onended = function() {
                        isSpeaking = false;
                        updateSpeakButton(false);
                        currentAudio = null;
                    };

                    currentAudio.onerror = function() {
                        isSpeaking = false;
                        updateSpeakButton(false);
                        currentAudio = null;
                        // 失败时使用浏览器TTS
                        speakWithBrowser(text);
                    };

                    await currentAudio.play();
                    return true;
                } else if (data.fallback) {
                    // TTS未配置，使用浏览器原生
                    speakWithBrowser(text);
                    return true;
                }
            } catch (error) {
                console.log('TTS API调用失败，使用浏览器原生语音');
            }

            // 失败时使用浏览器TTS
            speakWithBrowser(text);
            return true;
        }

        // 使用浏览器原生TTS朗读（备用）
        function speakWithBrowser(text) {
            if (!window.speechSynthesis) {
                console.log('浏览器不支持语音合成');
                return;
            }

            window.speechSynthesis.cancel();

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'zh-CN';
            if (chineseVoice) {
                utterance.voice = chineseVoice;
            }
            utterance.rate = 1.1;
            utterance.pitch = 1.0;

            utterance.onstart = function() {
                isSpeaking = true;
                updateSpeakButton(true);
            };

            utterance.onend = function() {
                isSpeaking = false;
                updateSpeakButton(false);
            };

            utterance.onerror = function() {
                isSpeaking = false;
                updateSpeakButton(false);
            };

            currentUtterance = utterance;
            window.speechSynthesis.speak(utterance);
        }

        // 朗读文本（自动选择TTS或浏览器原生）
        function speakText(text) {
            // 如果正在朗读，先停止
            if (isSpeaking) {
                stopSpeaking();
                return;
            }

            // 优先使用火山方舟TTS
            speakWithTTS(text);
        }

        // 停止朗读
        function stopSpeaking() {
            // 停止TTS音频
            if (currentAudio) {
                currentAudio.pause();
                currentAudio.currentTime = 0;
                currentAudio = null;
            }

            // 停止浏览器TTS
            if (window.speechSynthesis) {
                window.speechSynthesis.cancel();
            }

            isSpeaking = false;
            updateSpeakButton(false);
        }

        // 更新朗读按钮状态
        function updateSpeakButton(speaking) {
            const btn = document.getElementById('aiSpeakBtn');
            if (btn) {
                if (speaking) {
                    btn.classList.add('speaking');
                    btn.textContent = '🔇';
                } else {
                    btn.classList.remove('speaking');
                    btn.textContent = '🔊';
                }
            }
        }

        // 顶部朗读按钮点击事件
        window.toggleSpeak = function() {
            if (isSpeaking) {
                stopSpeaking();
            } else if (lastBotMessage) {
                speakText(lastBotMessage);
            }
        };

        // 暴露给外部使用
        window.speakTextByContent = speakText;

        // ========== 用户下拉菜单功能 ==========

        // 跳转到我的借阅记录
        function goToMyBorrowRecords() {
            // 切换到借阅记录面板
            document.querySelectorAll('.left-sidebar .nav-item').forEach(i => i.classList.remove('active'));
            document.querySelector('.left-sidebar .nav-item[data-tab="records"]').classList.add('active');
            document.getElementById('page-title').textContent = '📋 借阅记录';
            document.querySelectorAll('.content-pane').forEach(pane => pane.classList.remove('active'));
            document.getElementById('records-pane').classList.add('active');

            // 筛选当前用户的借阅记录
            const currentUser = window.djangoData?.currentUser || '';
            if (currentUser) {
                const borrowerSelect = document.getElementById('record-borrower');
                if (borrowerSelect) {
                    // 等待选项加载后设置
                    setTimeout(() => {
                        const displayName = document.getElementById('info-display-name')?.textContent || currentUser;
                        // 查找匹配的选项
                        Array.from(borrowerSelect.options).forEach(opt => {
                            if (opt.value === displayName || opt.textContent === displayName) {
                                borrowerSelect.value = opt.value;
                            }
                        });
                    }, 500);
                }
            }

            updateFabButton('records');
        }

        // 跳转到我的书摘
        function goToMyNotes() {
            // 切换到书摘书评面板
            document.querySelectorAll('.left-sidebar .nav-item').forEach(i => i.classList.remove('active'));
            document.querySelector('.left-sidebar .nav-item[data-tab="notes"]').classList.add('active');
            document.getElementById('page-title').textContent = '📝 书摘书评';
            document.querySelectorAll('.content-pane').forEach(pane => pane.classList.remove('active'));
            document.getElementById('notes-pane').classList.add('active');

            loadNotes();
            loadNotesBookFilter();
            updateFabButton('notes');
        }

        // 跳转到设置页面
        function goToSettings() {
            document.querySelectorAll('.left-sidebar .nav-item').forEach(i => i.classList.remove('active'));
            document.querySelector('.left-sidebar .nav-item[data-tab="settings"]').classList.add('active');
            document.getElementById('page-title').textContent = '⚙️ 设置';
            document.querySelectorAll('.content-pane').forEach(pane => pane.classList.remove('active'));
            document.getElementById('settings-pane').classList.add('active');

            // 加载用户信息
            loadUserInfo();

            // 如果是管理员，加载成员列表
            const membersList = document.getElementById('members-list');
            if (membersList) {
                loadMembersList();
            }

            updateFabButton('settings');
        }

        // 显示帮助与反馈信息
        function showHelpInfo() {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '❓ 帮助与反馈';

            content.innerHTML = `
                <div class="p-3">
                    <div class="mb-4">
                        <h6 class="mb-3">📖 使用帮助</h6>
                        <div class="help-section">
                            <div class="help-item">
                                <strong>📚 书籍管理</strong>
                                <p class="text-muted small mb-2">点击书籍卡片查看详情，支持借书、还书、编辑信息等操作。可通过分类、状态筛选书籍。</p>
                            </div>
                            <div class="help-item">
                                <strong>📷 条形码录入</strong>
                                <p class="text-muted small mb-2">点击右下角"+"按钮，选择"条形码录入"，扫描书籍背面条形码即可自动获取书籍信息。</p>
                            </div>
                            <div class="help-item">
                                <strong>📋 借阅记录</strong>
                                <p class="text-muted small mb-2">查看所有借阅历史，支持按日期、借阅人筛选，日历视图可直观查看借阅情况。</p>
                            </div>
                            <div class="help-item">
                                <strong>🤖 图图助手</strong>
                                <p class="text-muted small mb-2">点击右下角"图图"按钮，可与AI助手对话，推荐书籍、回答问题等。</p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="mb-3">
                        <h6 class="mb-3">💬 意见反馈</h6>
                        <p class="text-muted small">如有问题或建议，请联系管理员或在GitHub提交Issue。</p>
                    </div>
                    <div class="mb-3">
                        <h6 class="mb-3">ℹ️ 关于系统</h6>
                        <p class="text-muted small mb-1">家庭图书管理系统 v1.0</p>
                        <p class="text-muted small">基于 Django + Bootstrap 5 开发</p>
                    </div>
                    <div class="text-center mt-4">
                        <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
                    </div>
                </div>
            `;

            modal.style.display = 'flex';
        }

        // 下载导入模板
        function downloadTemplate() {
            window.location.href = '/api/books/template/';
        }

        // ========== 通知提醒功能 ==========
        let notificationCount = 0;

        function loadNotifications() {
            fetch('/api/notifications/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        notificationCount = data.unread_count;
                        updateNotificationBadge();
                        renderNotifications(data.notifications);
                    }
                });
        }

        function updateNotificationBadge() {
            const badge = document.getElementById('notification-badge');
            if (badge) {
                if (notificationCount > 0) {
                    badge.textContent = notificationCount > 99 ? '99+' : notificationCount;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            }
        }

        function renderNotifications(notifications) {
            const container = document.getElementById('notifications-list');
            if (!container) return;

            if (notifications.length === 0) {
                container.innerHTML = '<div class="text-center py-4 text-muted">暂无通知</div>';
                return;
            }

            container.innerHTML = notifications.map(n => `
                <div class="notification-item ${n.is_read ? '' : 'unread'}" data-id="${n.id}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <strong>${n.title}</strong>
                            <p class="mb-1 small">${n.content}</p>
                            <small class="text-muted">${n.created_at}</small>
                        </div>
                        ${!n.is_read ? '<span class="badge bg-primary">新</span>' : ''}
                    </div>
                </div>
            `).join('');
        }

        function markNotificationRead(id) {
            fetch(`/api/notification/${id}/read/`, {
                method: 'POST',
                headers: { 'X-CSRFToken': getCsrfToken() }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                }
            });
        }

        function markAllNotificationsRead() {
            fetch('/api/notifications/read-all/', {
                method: 'POST',
                headers: { 'X-CSRFToken': getCsrfToken() }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    showToast('已标记全部已读');
                }
            });
        }

        // 切换通知面板
        function toggleNotificationPanel() {
            const panel = document.getElementById('notification-panel');
            if (panel) {
                if (panel.style.display === 'none') {
                    panel.style.display = 'block';
                    loadNotifications();
                } else {
                    panel.style.display = 'none';
                }
            }
        }

        // 点击外部关闭通知面板
        document.addEventListener('click', function(e) {
            const panel = document.getElementById('notification-panel');
            const bell = document.querySelector('.notification-bell');
            if (panel && bell && !panel.contains(e.target) && !bell.contains(e.target)) {
                panel.style.display = 'none';
            }
        });

        // ========== 数据库备份功能 ==========
        function backupDatabase() {
            if (!confirm('确定要下载数据库备份文件吗？')) return;

            showToast('正在准备备份文件...', 'info');

            // 直接下载文件
            window.location.href = '/api/database/backup/';
        }

        // ========== 操作日志功能 ==========
        function loadOperationLogs(page = 1, action = 'all') {
            const container = document.getElementById('operation-logs-list');
            if (!container) return;

            container.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>';

            fetch(`/api/operation-logs/?page=${page}&action=${action}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        if (data.logs.length === 0) {
                            container.innerHTML = '<div class="text-center py-4 text-muted">暂无操作记录</div>';
                            return;
                        }

                        container.innerHTML = data.logs.map(log => `
                            <div class="log-item py-2 border-bottom">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <span class="badge bg-secondary me-2">${log.action_display}</span>
                                        <span class="fw-bold">${log.target_name || '-'}</span>
                                        ${log.detail ? `<small class="text-muted d-block">${log.detail}</small>` : ''}
                                    </div>
                                    <div class="text-end">
                                        <small class="text-muted">${log.user}</small>
                                        <small class="text-muted d-block">${log.created_at}</small>
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    }
                });
        }

        // ========== 批量操作功能 ==========
        let selectedBooks = new Set();
        let selectedRecords = new Set();
        let batchMode = false;
        let recordBatchMode = false;

        // 切换书籍批量模式
        function toggleBatchMode() {
            batchMode = !batchMode;
            const checkboxes = document.querySelectorAll('.batch-checkbox');
            const batchBorrowBtn = document.getElementById('batch-borrow-btn');
            const batchDeleteBtn = document.getElementById('batch-delete-btn');
            const cancelBtn = document.getElementById('cancel-batch-btn');
            const selectInfo = document.getElementById('batch-select-info');

            checkboxes.forEach(cb => {
                cb.style.display = batchMode ? 'block' : 'none';
            });

            if (batchBorrowBtn) batchBorrowBtn.style.display = batchMode ? 'inline-block' : 'none';
            if (batchDeleteBtn) batchDeleteBtn.style.display = batchMode ? 'inline-block' : 'none';
            if (cancelBtn) cancelBtn.style.display = batchMode ? 'inline-block' : 'none';
            if (selectInfo) selectInfo.style.display = batchMode ? 'block' : 'none';

            if (!batchMode) {
                selectedBooks.clear();
                document.querySelectorAll('.book-checkbox').forEach(cb => cb.checked = false);
                document.querySelectorAll('.book-card').forEach(card => card.classList.remove('selected'));
                updateSelectedCount();
            }
        }

        function cancelBatchMode() {
            batchMode = false;
            selectedBooks.clear();
            const checkboxes = document.querySelectorAll('.batch-checkbox');
            const batchBorrowBtn = document.getElementById('batch-borrow-btn');
            const batchDeleteBtn = document.getElementById('batch-delete-btn');
            const cancelBtn = document.getElementById('cancel-batch-btn');
            const selectInfo = document.getElementById('batch-select-info');

            checkboxes.forEach(cb => {
                cb.style.display = 'none';
            });
            if (batchBorrowBtn) batchBorrowBtn.style.display = 'none';
            if (batchDeleteBtn) batchDeleteBtn.style.display = 'none';
            if (cancelBtn) cancelBtn.style.display = 'none';
            if (selectInfo) selectInfo.style.display = 'none';
            document.querySelectorAll('.book-checkbox').forEach(cb => cb.checked = false);
            document.querySelectorAll('.book-card').forEach(card => card.classList.remove('selected'));
        }

        function toggleBookSelection(bookId) {
            if (selectedBooks.has(bookId)) {
                selectedBooks.delete(bookId);
            } else {
                selectedBooks.add(bookId);
            }
            updateSelectedCount();
            updateBatchButtons();
        }

        function updateSelectedCount() {
            const countEl = document.getElementById('selected-count');
            if (countEl) {
                countEl.textContent = selectedBooks.size;
            }
            const recordCountEl = document.getElementById('record-selected-count');
            if (recordCountEl) {
                recordCountEl.textContent = selectedRecords.size;
            }
        }

        // 切换借阅记录批量模式
        function toggleRecordBatchMode() {
            recordBatchMode = !recordBatchMode;
            const checkboxes = document.querySelectorAll('.record-checkbox');
            const batchReturnBtn = document.getElementById('batch-return-btn');
            const cancelBtn = document.getElementById('cancel-record-batch-btn');
            const selectInfo = document.getElementById('record-selected-info');

            checkboxes.forEach(cb => {
                cb.style.display = recordBatchMode ? 'block' : 'none';
            });

            if (batchReturnBtn) batchReturnBtn.style.display = recordBatchMode ? 'inline-block' : 'none';
            if (cancelBtn) cancelBtn.style.display = recordBatchMode ? 'inline-block' : 'none';
            if (selectInfo) selectInfo.style.display = recordBatchMode ? 'inline' : 'none';

            if (!recordBatchMode) {
                selectedRecords.clear();
                document.querySelectorAll('.record-select-checkbox').forEach(cb => cb.checked = false);
                document.querySelectorAll('.record-item').forEach(item => item.classList.remove('selected'));
                updateSelectedCount();
            }
        }

        function cancelRecordBatchMode() {
            recordBatchMode = false;
            selectedRecords.clear();
            const checkboxes = document.querySelectorAll('.record-checkbox');
            const batchReturnBtn = document.getElementById('batch-return-btn');
            const cancelBtn = document.getElementById('cancel-record-batch-btn');
            const selectInfo = document.getElementById('record-selected-info');

            checkboxes.forEach(cb => {
                cb.style.display = 'none';
            });
            if (batchReturnBtn) batchReturnBtn.style.display = 'none';
            if (cancelBtn) cancelBtn.style.display = 'none';
            if (selectInfo) selectInfo.style.display = 'none';
            document.querySelectorAll('.record-select-checkbox').forEach(cb => cb.checked = false);
        }

        function toggleRecordSelection(recordId) {
            if (selectedRecords.has(recordId)) {
                selectedRecords.delete(recordId);
            } else {
                selectedRecords.add(recordId);
            }
            updateSelectedCount();
            updateBatchButtons();
        }

        function updateBatchButtons() {
            const batchBorrowBtn = document.getElementById('batch-borrow-btn');
            const batchReturnBtn = document.getElementById('batch-return-btn');
            const batchDeleteBtn = document.getElementById('batch-delete-btn');

            if (batchBorrowBtn) {
                batchBorrowBtn.disabled = selectedBooks.size === 0;
            }
            if (batchReturnBtn) {
                batchReturnBtn.disabled = selectedRecords.size === 0;
            }
            if (batchDeleteBtn) {
                batchDeleteBtn.disabled = selectedBooks.size === 0;
            }
        }

        function confirmBatchDelete() {
            if (selectedBooks.size === 0) {
                showToast('请先选择要删除的书籍', 'error');
                return;
            }

            showConfirmModal({
                icon: '📚',
                title: '批量删除书籍',
                message: '确定要删除选中的书籍吗？',
                details: [
                    { label: '选中数量', value: `${selectedBooks.size} 本` }
                ],
                warning: '此操作不可恢复！',
                btnText: '确认删除',
                onConfirm: () => {
                    batchDeleteBooks();
                }
            });
        }

        function openBatchBorrowModal() {
            if (selectedBooks.size === 0) {
                showToast('请先选择要借阅的书籍', 'error');
                return;
            }

            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📚 批量借阅';

            // 加载借阅人列表
            fetch('/api/users/')
                .then(r => r.json())
                .then(data => {
                    const userOptions = data.success ? data.users.map(u =>
                        `<option value="${u.id}">${u.reader_name || u.username}</option>`
                    ).join('') : '';

                    content.innerHTML = `
                        <div class="p-3">
                            <p>已选择 <strong>${selectedBooks.size}</strong> 本书籍</p>
                            <div class="mb-3">
                                <label class="form-label">选择借阅人</label>
                                <select class="form-select" id="batch-borrower-select">
                                    <option value="">请选择借阅人</option>
                                    ${userOptions}
                                </select>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary flex-grow-1" onclick="submitBatchBorrow()">确认借阅</button>
                                <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
                            </div>
                        </div>
                    `;
                    modal.style.display = 'flex';
                });
        }

        function submitBatchBorrow() {
            const borrowerId = document.getElementById('batch-borrower-select').value;
            if (!borrowerId) {
                showToast('请选择借阅人', 'error');
                return;
            }

            fetch('/api/batch/borrow/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    book_ids: Array.from(selectedBooks),
                    borrower_id: parseInt(borrowerId)
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message);
                    closeScanModal();
                    selectedBooks.clear();
                    window.location.reload();
                } else {
                    showToast(data.error || '操作失败', 'error');
                }
            });
        }

        function openBatchReturnModal() {
            if (selectedRecords.size === 0) {
                showToast('请先选择要归还的记录', 'error');
                return;
            }

            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📚 批量归还';

            // 加载书架位置列表
            fetch('/api/shelf/locations/')
                .then(r => r.json())
                .then(data => {
                    const locations = data.success ? data.locations : [];
                    const locationOptions = locations.map(l =>
                        `<option value="${l.name}">${l.name}</option>`
                    ).join('');

                    content.innerHTML = `
                        <div class="p-3">
                            <p>已选择 <strong>${selectedRecords.size}</strong> 条借阅记录</p>
                            <div class="mb-3">
                                <label class="form-label">选择归还位置</label>
                                <select class="form-select" id="batch-return-place">
                                    <option value="未填写">未填写</option>
                                    ${locationOptions}
                                </select>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary flex-grow-1" onclick="submitBatchReturn()">确认归还</button>
                                <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
                            </div>
                        </div>
                    `;
                    modal.style.display = 'flex';
                });
        }

        function submitBatchReturn() {
            const returnPlace = document.getElementById('batch-return-place').value;

            fetch('/api/batch/return/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    record_ids: Array.from(selectedRecords),
                    return_place: returnPlace
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message);
                    closeScanModal();
                    selectedRecords.clear();
                    window.location.reload();
                } else {
                    showToast(data.error || '操作失败', 'error');
                }
            });
        }

        function batchDeleteBooks() {
            if (selectedBooks.size === 0) {
                showToast('请先选择要删除的书籍', 'error');
                return;
            }

            fetch('/api/batch/delete-books/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    book_ids: Array.from(selectedBooks)
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message);
                    selectedBooks.clear();
                    window.location.reload();
                } else {
                    showToast(data.error || '操作失败', 'error');
                }
            });
        }

        // ========== 阅读统计报表功能 ==========

        // 加载月度阅读报告
        function loadMonthlyReport() {
            const monthSelect = document.getElementById('report-month-select');
            const container = document.getElementById('monthly-report-content');
            if (!monthSelect || !container) return;

            const month = monthSelect.value;
            const year = new Date().getFullYear();

            container.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div> 加载中...</div>';

            fetch(`/api/reading/report/?year=${year}&month=${month}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const report = data.report;
                        container.innerHTML = `
                            <div class="row text-center mb-3">
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #667eea; margin: 0;">${report.total_borrows}</h4>
                                        <small class="text-muted">借阅次数</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #28a745; margin: 0;">${report.total_returns}</h4>
                                        <small class="text-muted">归还次数</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #17a2b8; margin: 0;">${report.new_books}</h4>
                                        <small class="text-muted">新增书籍</small>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="small text-muted">🔥 最受欢迎</h6>
                                    ${report.popular_books.length > 0 ? `
                                        <ul class="list-unstyled small mb-0">
                                            ${report.popular_books.slice(0, 3).map(b => `<li>《${b.book__book_name}》(${b.count}次)</li>`).join('')}
                                        </ul>
                                    ` : '<p class="small text-muted">暂无数据</p>'}
                                </div>
                                <div class="col-md-6">
                                    <h6 class="small text-muted">📖 最活跃读者</h6>
                                    ${report.active_readers.length > 0 ? `
                                        <ul class="list-unstyled small mb-0">
                                            ${report.active_readers.slice(0, 3).map(r => `<li>${r.borrower_name}(${r.count}本)</li>`).join('')}
                                        </ul>
                                    ` : '<p class="small text-muted">暂无数据</p>'}
                                </div>
                            </div>
                        `;
                    } else {
                        container.innerHTML = '<p class="text-danger text-center">加载失败</p>';
                    }
                })
                .catch(() => {
                    container.innerHTML = '<p class="text-danger text-center">网络错误</p>';
                });
        }

        // 加载个人阅读轨迹
        function loadPersonalReadingTrajectory(userId) {
            const container = document.getElementById('personal-trajectory-content');
            if (!container) return;

            container.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div> 加载中...</div>';

            fetch(`/api/reading/statistics/?user_id=${userId}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.data.personal_stats) {
                        const stats = data.data.personal_stats;
                        container.innerHTML = `
                            <div class="row text-center mb-3">
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #667eea; margin: 0;">${stats.total_borrowed}</h4>
                                        <small class="text-muted">累计借阅</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #28a745; margin: 0;">${stats.total_returned}</h4>
                                        <small class="text-muted">已归还</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <h4 style="color: #dc3545; margin: 0;">${stats.current_borrowed}</h4>
                                        <small class="text-muted">当前借阅</small>
                                    </div>
                                </div>
                            </div>
                            <h6 class="small text-muted mb-2">📚 阅读轨迹</h6>
                            <div style="max-height: 200px; overflow-y: auto;">
                                ${stats.trajectory.length > 0 ? stats.trajectory.map(t => `
                                    <div class="d-flex justify-content-between align-items-center py-1 border-bottom">
                                        <div>
                                            <span class="small">《${t.book_name}》</span>
                                            <small class="text-muted d-block">${t.author}</small>
                                        </div>
                                        <div class="text-end">
                                            <small class="text-muted">${t.borrow_date}</small>
                                            ${t.return_date !== '未归还' ? `<small class="text-success d-block">↩ ${t.return_date}</small>` : '<small class="text-danger d-block">借阅中</small>'}
                                        </div>
                                    </div>
                                `).join('') : '<p class="text-muted small">暂无借阅记录</p>'}
                            </div>
                        `;
                    } else {
                        container.innerHTML = '<p class="text-muted text-center">暂无数据</p>';
                    }
                })
                .catch(() => {
                    container.innerHTML = '<p class="text-danger text-center">加载失败</p>';
                });
        }
        function loadReadingReport(year, month) {
            const container = document.getElementById('reading-report-content');
            if (!container) return;

            container.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>';

            fetch(`/api/reading/report/?year=${year}&month=${month}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const report = data.report;
                        container.innerHTML = `
                            <div class="report-card">
                                <h5 class="mb-3">${report.period} 阅读报告</h5>
                                <div class="row g-3">
                                    <div class="col-6">
                                        <div class="stat-box">
                                            <div class="stat-value">${report.total_borrows}</div>
                                            <div class="stat-label">借阅次数</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="stat-box">
                                            <div class="stat-value">${report.total_returns}</div>
                                            <div class="stat-label">归还次数</div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <h6 class="mb-2">🔥 最受欢迎书籍</h6>
                                ${report.popular_books.length > 0 ? `
                                    <ul class="list-unstyled">
                                        ${report.popular_books.map(b => `<li>《${b.book__book_name}》- ${b.count}次</li>`).join('')}
                                    </ul>
                                ` : '<p class="text-muted small">暂无数据</p>'}
                                <h6 class="mb-2 mt-3">📖 最活跃读者</h6>
                                ${report.active_readers.length > 0 ? `
                                    <ul class="list-unstyled">
                                        ${report.active_readers.map(r => `<li>${r.borrower_name} - ${r.count}本</li>`).join('')}
                                    </ul>
                                ` : '<p class="text-muted small">暂无数据</p>'}
                            </div>
                        `;
                    }
                });
        }

        // ========== 二维码分享功能 ==========
        function showBookQRCode(bookId) {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = '📱 分享书籍';

            content.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2">生成二维码中...</p></div>';
            modal.style.display = 'flex';

            fetch(`/api/book/${bookId}/qrcode/`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        content.innerHTML = `
                            <div class="text-center py-3">
                                <img src="${data.qrcode}" alt="QR Code" style="width: 200px; height: 200px; border-radius: 8px;">
                                <p class="mt-3 mb-1"><strong>《${data.book_name}》</strong></p>
                                <p class="text-muted small">扫描二维码查看书籍详情</p>
                                <button class="btn btn-outline-primary btn-sm mt-2" onclick="copyShareUrl('${data.share_url}')">
                                    复制分享链接
                                </button>
                            </div>
                        `;
                    } else {
                        content.innerHTML = `<div class="alert alert-danger">${data.error || '生成失败'}</div>`;
                    }
                });
        }

        function copyShareUrl(url) {
            navigator.clipboard.writeText(url).then(() => {
                showToast('链接已复制到剪贴板');
            }).catch(() => {
                showToast('复制失败，请手动复制', 'error');
            });
        }

        // ========== 书评点赞功能 ==========
        function toggleCommentLike(commentId) {
            fetch(`/api/comment/${commentId}/like/`, {
                method: 'POST',
                headers: { 'X-CSRFToken': getCsrfToken() }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    // 更新UI
                    const btn = document.querySelector(`[data-comment-id="${commentId}"] .like-btn`);
                    if (btn) {
                        const icon = data.liked ? '❤️' : '🤍';
                        btn.innerHTML = `${icon} ${data.like_count}`;
                        btn.classList.toggle('liked', data.liked);
                    }
                }
            });
        }

        // 页面加载时检查提醒
        document.addEventListener('DOMContentLoaded', function() {
            // 如果用户已登录，加载通知
            if (window.djangoData && window.djangoData.currentUser) {
                loadNotifications();
                // 检查到期提醒
                fetch('/api/check-due-reminders/').catch(() => {});
            }
        });

        // ========== 统计交互功能 ==========

        // 显示统计详情弹窗
        function showStatDetail(type) {
            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');

            const titles = {
                'total': '📚 全部馆藏',
                'available': '📖 在架书籍',
                'borrowed': '📤 借出中'
            };

            document.getElementById('scanModalTitle').textContent = titles[type] || '详情';
            content.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2">加载中...</p></div>';
            modal.style.display = 'flex';

            // 构建筛选条件
            let url = '/api/books/search/?';
            if (type === 'available') {
                url += 'status=在架';
            } else if (type === 'borrowed') {
                url += 'status=借出';
            }

            fetch(url)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const books = data.books || [];
                        if (books.length === 0) {
                            content.innerHTML = '<div class="text-center py-4 text-muted">暂无数据</div>';
                            return;
                        }

                        content.innerHTML = `
                            <div class="mb-3">
                                <strong>共 ${books.length} 本书</strong>
                            </div>
                            <div style="max-height: 400px; overflow-y: auto;">
                                ${books.slice(0, 50).map(book => `
                                    <div class="d-flex align-items-center p-2 mb-2" style="background: #f8f9fa; border-radius: 8px; cursor: pointer;"
                                         onclick="showBookModal({id: ${book.id}, book_name: '${book.book_name.replace(/'/g, "\\'")}', author: '${(book.author || '').replace(/'/g, "\\'")}', book_type: '${book.book_type || ''}', place: '${book.place || ''}', isbn: '${book.isbn || ''}', status: '${book.status}', cover: '${book.cover || ''}', description: '${(book.description || '').replace(/'/g, "\\'")}'}); closeScanModal();">
                                        ${book.cover ? `<img src="${book.cover}" style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px; margin-right: 10px;">` : '<div style="width:40px;height:55px;background:#e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;margin-right:10px;">📖</div>'}
                                        <div style="flex: 1;">
                                            <div class="fw-bold small">${book.book_name}</div>
                                            <small class="text-muted">${book.author || '未知作者'}</small>
                                        </div>
                                        <span class="badge ${book.status === '借出' ? 'bg-danger' : 'bg-success'}">${book.status}</span>
                                    </div>
                                `).join('')}
                                ${books.length > 50 ? '<p class="text-muted text-center small">仅显示前50本</p>' : ''}
                            </div>
                            <div class="mt-3 text-center">
                                <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
                            </div>
                        `;
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">加载失败</div>';
                    }
                })
                .catch(() => {
                    content.innerHTML = '<div class="alert alert-danger">网络错误</div>';
                });
        }

        // 显示借阅人的借阅历史
        function showBorrowerHistory(borrowerName) {
            if (!borrowerName) return;

            const modal = document.getElementById('scanModal');
            const content = document.getElementById('scanModalContent');
            document.getElementById('scanModalTitle').textContent = `📋 ${borrowerName} 的借阅历史`;
            content.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2">加载中...</p></div>';
            modal.style.display = 'flex';

            fetch(`/api/borrow-records/search/?search_borrower=${encodeURIComponent(borrowerName)}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const records = data.records || [];
                        if (records.length === 0) {
                            content.innerHTML = '<div class="text-center py-4 text-muted">暂无借阅记录</div>';
                            return;
                        }

                        content.innerHTML = `
                            <div class="mb-3">
                                <strong>共 ${records.length} 条借阅记录</strong>
                            </div>
                            <div style="max-height: 400px; overflow-y: auto;">
                                ${records.map(record => `
                                    <div class="p-2 mb-2" style="background: #f8f9fa; border-radius: 8px;">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <div class="fw-bold">《${record.book_name}》</div>
                                                <small class="text-muted">${record.author || '未知作者'}</small>
                                            </div>
                                            <span class="badge ${record.is_returned ? 'bg-success' : 'bg-warning'}">${record.is_returned ? '已归还' : '借阅中'}</span>
                                        </div>
                                        <div class="small text-muted mt-1">
                                            借出：${record.borrow_date}
                                            ${record.return_date ? `<br>归还：${record.return_date}` : ''}
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                            <div class="mt-3 text-center">
                                <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
                            </div>
                        `;
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">加载失败</div>';
                    }
                })
                .catch(() => {
                    content.innerHTML = '<div class="alert alert-danger">网络错误</div>';
                });
        }

        // 根据书名显示书籍详情
        function showBookDetailByName(bookName) {
            if (!bookName) return;

            // 搜索书籍
            fetch(`/api/books/search/?keyword=${encodeURIComponent(bookName)}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.books && data.books.length > 0) {
                        const book = data.books[0];
                        showBookModal({
                            id: book.id,
                            book_name: book.book_name,
                            author: book.author,
                            book_type: book.book_type,
                            place: book.place,
                            isbn: book.isbn,
                            status: book.status,
                            cover: book.cover,
                            description: book.description
                        });
                    } else {
                        showToast('未找到该书籍', 'error');
                    }
                })
                .catch(() => {
                    showToast('查询失败', 'error');
                });
        }

        // 从借阅记录点击书籍显示详情
        function showRecordBookDetail(bookId) {
            fetch(`/api/book/${bookId}/borrow-info/`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        // 获取书籍详细信息
                        fetch(`/api/books/search/?keyword=${bookId}`)
                            .then(r2 => r2.json())
                            .then(data2 => {
                                if (data2.success && data2.books && data2.books.length > 0) {
                                    const book = data2.books.find(b => b.id == bookId) || data2.books[0];
                                    showBookModal({
                                        id: book.id,
                                        book_name: book.book_name,
                                        author: book.author,
                                        book_type: book.book_type,
                                        place: book.place,
                                        isbn: book.isbn,
                                        status: book.status,
                                        cover: book.cover,
                                        description: book.description
                                    });
                                }
                            });
                    }
                });
        }

        // ========== 阅读打卡功能 ==========

        function loadCheckinStatus() {
            fetch('/api/checkin/status/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('streak-days').textContent = data.streak || 0;
                        document.getElementById('total-checkins').textContent = data.total_days || 0;
                        document.getElementById('week-checkins').textContent = data.week_days || 0;

                        const btn = document.getElementById('checkin-btn');
                        const btnText = document.getElementById('checkin-btn-text');

                        if (data.checked_today) {
                            btn.classList.add('checked');
                            btnText.textContent = '已打卡 ✓';
                        } else {
                            btn.classList.remove('checked');
                            btnText.textContent = '今日打卡';
                        }
                    }
                })
                .catch(err => console.error('加载打卡状态失败:', err));
        }

        function doCheckin() {
            const btn = document.getElementById('checkin-btn');
            if (btn.classList.contains('checked')) {
                showToast('今天已经打卡过了');
                return;
            }

            fetch('/api/checkin/', {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCsrfToken()
                }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    // 更新显示
                    document.getElementById('streak-days').textContent = data.streak;
                    document.getElementById('total-checkins').textContent = data.total_days;

                    const btn = document.getElementById('checkin-btn');
                    const btnText = document.getElementById('checkin-btn-text');
                    btn.classList.add('checked');
                    btnText.textContent = '已打卡 ✓';

                    showToast('打卡成功！连续' + data.streak + '天');

                    // 如果获得了新徽章
                    if (data.new_badges && data.new_badges.length > 0) {
                        setTimeout(() => {
                            loadUserBadges();
                            showToast('🎉 恭喜获得新徽章！', 'success');
                        }, 500);
                    }
                } else {
                    showToast(data.message || '打卡失败', 'error');
                }
            })
            .catch(err => {
                console.error('打卡失败:', err);
                showToast('打卡失败，请重试', 'error');
            });
        }

        function loadUserBadges() {
            fetch('/api/badges/')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        renderBadges(data.badges);
                    }
                })
                .catch(err => console.error('加载徽章失败:', err));
        }

        function renderBadges(earnedBadges) {
            const container = document.getElementById('badges-container');
            if (!container) return;

            const allBadges = [
                { type: 'week_reader', icon: '🌟', name: '一周阅读达人', desc: '连续打卡7天' },
                { type: 'month_reader', icon: '🏆', name: '月度阅读之星', desc: '累计打卡30天' },
                { type: 'book_lover', icon: '📚', name: '藏书爱好者', desc: '累计借阅10本书' }
            ];

            const earnedTypes = earnedBadges.map(b => b.type);

            container.innerHTML = allBadges.map(badge => {
                const earned = earnedTypes.includes(badge.type);
                const earnedInfo = earnedBadges.find(b => b.type === badge.type);

                return `
                    <div class="badge-item ${earned ? 'badge-earned' : 'badge-locked'}">
                        <div class="badge-icon">${badge.icon}</div>
                        <div class="badge-name">${badge.name}</div>
                        <div class="badge-desc">${badge.desc}</div>
                        ${earned ? `<div class="badge-date" style="font-size: 10px; color: #999; margin-top: 4px;">获得于 ${earnedInfo.earned_at}</div>` : ''}
                    </div>
                `;
            }).join('');
        }

        // ========== 主题设置功能 ==========

        function initTheme() {
            // 加载保存的主题设置
            const darkMode = localStorage.getItem('darkMode') === 'true';
            const themeColor = localStorage.getItem('themeColor') || '#667eea';

            // 应用夜间模式
            if (darkMode) {
                document.body.classList.add('dark-mode');
                const toggle = document.getElementById('darkModeToggle');
                if (toggle) toggle.checked = true;
            }

            // 应用主题色
            applyThemeColor(themeColor);

            // 更新颜色选择器
            const picker = document.getElementById('themeColorPicker');
            if (picker) {
                picker.value = themeColor;
            }
            const label = document.getElementById('currentColorLabel');
            if (label) {
                label.textContent = themeColor;
            }

            // 更新预设颜色选中状态
            updatePresetColorActive(themeColor);
        }

        function toggleDarkMode(enabled) {
            if (enabled) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('darkMode', 'true');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('darkMode', 'false');
            }
        }

        function changeThemeColor(color) {
            applyThemeColor(color);
            localStorage.setItem('themeColor', color);

            // 更新颜色选择器
            const picker = document.getElementById('themeColorPicker');
            if (picker) {
                picker.value = color;
            }
            const label = document.getElementById('currentColorLabel');
            if (label) {
                label.textContent = color;
            }

            // 更新预设颜色选中状态
            updatePresetColorActive(color);

            showToast('主题色已更改');
        }

        function applyThemeColor(color) {
            // 计算深色和浅色变体
            const rgb = hexToRgb(color);
            const darkerColor = rgbToHex(
                Math.max(0, rgb.r - 20),
                Math.max(0, rgb.g - 20),
                Math.max(0, rgb.b - 20)
            );
            const lighterColor = rgbToHex(
                Math.min(255, rgb.r + 30),
                Math.min(255, rgb.g + 30),
                Math.min(255, rgb.b + 30)
            );

            // 设置CSS变量
            document.documentElement.style.setProperty('--primary-color', color);
            document.documentElement.style.setProperty('--primary-dark', darkerColor);
            document.documentElement.style.setProperty('--primary-light', lighterColor);
            document.documentElement.style.setProperty('--gradient-start', color);
            document.documentElement.style.setProperty('--gradient-end', darkerColor);

            // 更新侧边栏渐变
            const sidebar = document.querySelector('.left-sidebar');
            if (sidebar) {
                sidebar.style.background = `linear-gradient(135deg, ${color} 0%, ${darkerColor} 100%)`;
            }

            // 更新头部渐变
            const header = document.querySelector('.ai-chat-header');
            if (header) {
                header.style.background = `linear-gradient(135deg, ${color} 0%, ${darkerColor} 100%)`;
            }

            // 更新打卡卡片渐变
            const checkinCard = document.querySelector('.checkin-card');
            if (checkinCard) {
                checkinCard.style.background = `linear-gradient(135deg, ${color} 0%, ${darkerColor} 100%)`;
            }
        }

        function hexToRgb(hex) {
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result ? {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16)
            } : { r: 102, g: 126, b: 234 };
        }

        function rgbToHex(r, g, b) {
            return '#' + [r, g, b].map(x => {
                const hex = x.toString(16);
                return hex.length === 1 ? '0' + hex : hex;
            }).join('');
        }

        function updatePresetColorActive(color) {
            const presets = document.querySelectorAll('.preset-color');
            presets.forEach(preset => {
                const presetColor = preset.style.background;
                const normalizedPreset = rgbToHexString(presetColor);
                if (normalizedPreset.toLowerCase() === color.toLowerCase()) {
                    preset.classList.add('active');
                } else {
                    preset.classList.remove('active');
                }
            });
        }

        function rgbToHexString(rgb) {
            // 处理rgb格式转hex
            if (rgb.startsWith('#')) return rgb;
            const match = rgb.match(/\d+/g);
            if (match && match.length >= 3) {
                return rgbToHex(parseInt(match[0]), parseInt(match[1]), parseInt(match[2]));
            }
            return rgb;
        }
