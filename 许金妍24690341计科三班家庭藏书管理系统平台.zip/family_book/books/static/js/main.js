/**
 * 家庭图书管理系统 - 主JavaScript文件
 */

// 数据存储
let allBooks = [];
let allRecords = [];
let currentMonth = new Date();
let currentCategory = 'all';
let currentStatus = 'all';
let currentShelf = 'all';
let currentShelfStatus = 'all';
let borrowedBookIds = new Set();

// ========== 初始化 ==========

function initApp() {
    initSubNavs();
    initBookCards();
    initCalendar();
    initStatusFilter();
    initShelfStatusFilter();
    loadShelfLocations();

    // 事件委托：处理动态内容中的关闭按钮
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.btn-close-modal');
        if (btn || (e.target.tagName === 'BUTTON' && e.target.textContent.includes('关闭'))) {
            e.preventDefault();
            closeScanModal();
        }
    });

    // 全局 Enter 键提交支持
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            const visibleModal = document.querySelector('.scan-modal-overlay[style*="flex"], .book-modal-overlay[style*="flex"]');
            if (visibleModal) {
                const submitBtn = visibleModal.querySelector('.btn-primary:not([type="button"])') ||
                                visibleModal.querySelector('button[onclick*="submit"], button[onclick*="add"], button[onclick*="save"]');
                if (submitBtn && e.target.tagName === 'INPUT') {
                    e.preventDefault();
                    submitBtn.click();
                }
            }
        }
        // ESC 键关闭弹窗
        if (e.key === 'Escape') {
            closeBookModal();
            closeScanModal();
            closeShelfModal();
        }
    });

    // 初始化浮动按钮
    updateFabButton('books');
}

// ========== 状态筛选 ==========

function initStatusFilter() {
    document.querySelectorAll('#status-filter-bar .status-filter-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#status-filter-bar .status-filter-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            currentStatus = this.dataset.status;
            filterBooks();
        });
    });
}

function initShelfStatusFilter() {
    document.querySelectorAll('#shelf-status-filter-bar .status-filter-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#shelf-status-filter-bar .status-filter-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            currentShelfStatus = this.dataset.status;
            filterShelfBooks(currentShelf);
        });
    });
}

// ========== 导航切换 ==========

function initSubNavs() {
    // 书籍分类导航
    document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#books-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            currentCategory = this.dataset.category;
            filterBooks();
        });
    });

    // 书架位置导航
    document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            filterShelfBooks(this.dataset.shelf);
        });
    });

    // 记录视图导航
    document.querySelectorAll('#records-sub-nav .sub-nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#records-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');

            document.getElementById('records-list-view').classList.remove('hidden');
            document.getElementById('records-calendar-view').classList.remove('active');
            document.getElementById('records-statistics-view').style.display = 'none';

            const view = this.dataset.view;
            if (view === 'list') {
                document.getElementById('records-calendar-view').classList.remove('active');
                document.getElementById('records-filter-bar').style.display = 'block';
            } else if (view === 'calendar') {
                document.getElementById('records-list-view').classList.add('hidden');
                document.getElementById('records-calendar-view').classList.add('active');
                document.getElementById('records-filter-bar').style.display = 'none';
            } else if (view === 'statistics') {
                document.getElementById('records-list-view').classList.add('hidden');
                document.getElementById('records-statistics-view').style.display = 'block';
                document.getElementById('records-filter-bar').style.display = 'none';
                loadStatistics();
            }
        });
    });

    // 设置子标签导航
    document.querySelectorAll('#settings-sub-nav .sub-nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#settings-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('members-sub-pane').style.display = this.dataset.subtab === 'members' ? 'block' : 'none';
            document.getElementById('account-sub-pane').style.display = this.dataset.subtab === 'account' ? 'block' : 'none';
            if (this.dataset.subtab === 'members') {
                loadMembersList();
            }
        });
    });
}

// 左侧导航切换
function initLeftNav() {
    document.querySelectorAll('.left-sidebar .nav-item').forEach(item => {
        item.addEventListener('click', function() {
            const tab = this.dataset.tab;
            if (!tab) return;

            document.querySelectorAll('.left-sidebar .nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');

            const titles = {
                'books': '📚 书籍',
                'shelf': '📚 书架',
                'notes': '📝 书摘书评',
                'records': '📋 借阅记录',
                'settings': '⚙️ 设置'
            };
            document.getElementById('page-title').textContent = titles[tab];

            document.querySelectorAll('.content-pane').forEach(pane => pane.classList.remove('active'));
            const targetPane = document.getElementById(tab + '-pane');
            if (targetPane) {
                targetPane.classList.add('active');
            }

            updateFabButton(tab);

            if (tab === 'shelf') {
                filterShelfBooks('all');
            }

            if (tab === 'notes') {
                loadNotes();
                loadNotesBookFilter();
            }

            if (tab === 'records') {
                initRecordsStatistics();
            }

            if (tab === 'settings') {
                const membersList = document.getElementById('members-list');
                if (membersList) {
                    loadMembersList();
                }
            }
        });
    });
}

// ========== 书籍功能 ==========

function filterBooks() {
    const cards = document.querySelectorAll('#books-container .book-card');
    cards.forEach(card => {
        if (card.classList.contains('book-add-card')) {
            card.style.display = '';
            return;
        }
        const matchCategory = currentCategory === 'all' || card.dataset.bookType === currentCategory;
        let matchStatus = true;
        if (currentStatus !== 'all') {
            const bookId = parseInt(card.dataset.bookId);
            if (currentStatus === '在架') {
                matchStatus = card.dataset.status === '在架';
            } else if (currentStatus === '借出') {
                matchStatus = card.dataset.status === '借出';
            } else if (currentStatus === '未归还') {
                matchStatus = card.dataset.status === '借出' && borrowedBookIds.has(bookId);
            }
        }
        card.style.display = (matchCategory && matchStatus) ? '' : 'none';
    });
}

function filterShelfBooks(shelf) {
    currentShelf = shelf;
    const container = document.getElementById('shelf-books-container');
    const searchInput = document.getElementById('shelf-search-input');
    const searchKeyword = searchInput ? searchInput.value.trim().toLowerCase() : '';

    let filteredBooks = [];

    if (shelf === 'all') {
        filteredBooks = allBooks;
    } else {
        filteredBooks = allBooks.filter(book =>
            book.place && book.place.includes(shelf)
        );
    }

    if (currentShelfStatus !== 'all') {
        if (currentShelfStatus === '未归还') {
            filteredBooks = filteredBooks.filter(book => book.status === '借出');
        } else {
            filteredBooks = filteredBooks.filter(book => book.status === currentShelfStatus);
        }
    }

    if (searchKeyword) {
        filteredBooks = filteredBooks.filter(book =>
            (book.book_name && book.book_name.toLowerCase().includes(searchKeyword)) ||
            (book.author && book.author.toLowerCase().includes(searchKeyword))
        );
    }

    if (filteredBooks.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5" style="color: #999;">
                <div style="font-size: 48px;">📚</div>
                <h5>该位置暂无书籍</h5>
                <p class="small mt-2">尝试调整筛选条件</p>
            </div>
        `;
        return;
    }

    container.innerHTML = filteredBooks.map(book => `
        <div class="book-card" data-book-id="${book.id || ''}" draggable="true"
             data-book-name="${book.book_name || '未知书名'}"
             data-author="${book.author || '未知作者'}"
             data-book-type="${book.book_type || ''}"
             data-place="${book.place || ''}"
             data-isbn="${book.isbn || ''}"
             data-status="${book.status || '在架'}"
             data-cover="${book.cover || ''}"
             data-description="${book.description || ''}">
            <div class="d-flex align-items-center">
                ${book.cover ? `<img src="${book.cover}" class="book-cover-small">` : '<div class="book-cover-small bg-secondary d-flex align-items-center justify-content-center text-white" style="width:60px;height:80px;border-radius:6px;margin-right:15px;font-size:24px;">📖</div>'}
                <div style="flex: 1;">
                    <h6 class="mb-1 text-truncate" style="max-width: 200px;">${book.book_name || '未知书名'}</h6>
                    <small class="text-muted">作者：${book.author || '未知'}</small>
                    <div class="mt-2">
                        <span class="status-badge ${book.status === '借出' ? 'status-borrowed' : 'status-available'}">
                            ${book.status === '借出' ? '已借出' : '可借阅'}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `).join('');

    initBookCards();
}

function initBookCards() {
    document.querySelectorAll('.book-card[data-book-id]').forEach(card => {
        card.addEventListener('dragstart', function(e) {
            this.classList.add('dragging');
            e.dataTransfer.setData('bookId', this.dataset.bookId);
            e.dataTransfer.effectAllowed = 'move';
        });

        card.addEventListener('dragend', function() {
            this.classList.remove('dragging');
            document.querySelectorAll('.drop-target').forEach(el => el.classList.remove('drop-target'));
        });

        card.addEventListener('click', function(e) {
            if (this.dataset.dragged === 'true') {
                this.dataset.dragged = 'false';
                return;
            }
            const bookData = {
                id: this.dataset.bookId,
                book_name: this.dataset.bookName,
                author: this.dataset.author,
                book_type: this.dataset.bookType,
                place: this.dataset.place,
                isbn: this.dataset.isbn,
                status: this.dataset.status,
                cover: this.dataset.cover,
                description: this.dataset.description
            };
            showBookModal(bookData);
        });
    });

    initDropTargets();
}

function initDropTargets() {
    document.querySelectorAll('#books-sub-nav .sub-nav-item:not([data-category="all"])').forEach(item => {
        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drop-target');
        });

        item.addEventListener('dragleave', function() {
            this.classList.remove('drop-target');
        });

        item.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drop-target');
            const bookId = e.dataTransfer.getData('bookId');
            if (bookId) {
                updateBookCategory(bookId, this.dataset.category);
            }
        });
    });

    document.querySelectorAll('#shelf-sub-nav .sub-nav-item:not([data-shelf="all"])').forEach(item => {
        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drop-target');
        });

        item.addEventListener('dragleave', function() {
            this.classList.remove('drop-target');
        });

        item.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drop-target');
            const bookId = e.dataTransfer.getData('bookId');
            if (bookId) {
                updateBookPlace(bookId, this.dataset.shelf);
            }
        });
    });
}

function updateBookCategory(bookId, category) {
    fetch(`/api/book/${bookId}/`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ book_type: category })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(`已将书籍移动到「${category}」分类`);
            setTimeout(() => location.reload(), 500);
        } else {
            showToast('更新失败：' + (data.error || '未知错误'), 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('网络错误，请稍后重试', 'error');
    });
}

function updateBookPlace(bookId, place) {
    fetch(`/api/book/${bookId}/`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ place: place })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(`已将书籍移动到「${place}」`);
            const bookIndex = allBooks.findIndex(b => b.id === bookId);
            if (bookIndex !== -1) {
                allBooks[bookIndex].place = place;
            }
            const activeShelf = document.querySelector('#shelf-sub-nav .sub-nav-item.active');
            if (activeShelf) {
                filterShelfBooks(activeShelf.dataset.shelf);
            }
        } else {
            showToast('更新失败：' + (data.error || '未知错误'), 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('网络错误，请稍后重试', 'error');
    });
}

// ========== 弹窗功能 ==========

function showBookModal(bookData) {
    const modal = document.getElementById('bookModal');
    const content = document.getElementById('bookModalContent');

    content.innerHTML = `
        <div style="text-align: center; margin-bottom: 20px;">
            ${bookData.cover ? `<img src="${bookData.cover}" class="book-cover-modal">` : '<div class="book-cover-modal bg-secondary d-flex align-items-center justify-content-center" style="height:250px;color:white;font-size:48px;">📖</div>'}
        </div>
        <div class="detail-row">
            <div class="detail-label">书名</div>
            <div class="detail-value" style="font-size: 18px;">${bookData.book_name}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">作者</div>
            <div class="detail-value">${bookData.author}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">分类</div>
            <div class="detail-value">${bookData.book_type}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">位置</div>
            <div class="detail-value">${bookData.place || '未填写'}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">ISBN</div>
            <div class="detail-value">${bookData.isbn || '未填写'}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">状态</div>
            <div class="detail-value">
                <span class="status-badge ${bookData.status === '借出' ? 'status-borrowed' : 'status-available'}">
                    ${bookData.status === '借出' ? '已借出' : '可借阅'}
                </span>
            </div>
        </div>
        ${bookData.description ? `
        <div class="detail-row" style="flex-direction: column; align-items: flex-start;">
            <div class="detail-label" style="margin-bottom: 8px;">介绍</div>
            <div class="detail-value" style="font-size: 14px; line-height: 1.6; color: #555;">${bookData.description}</div>
        </div>
        ` : ''}
        <div class="mt-4" style="display: flex; gap: 10px;">
            <a href="/borrow/${bookData.id}/" class="btn btn-outline-primary" style="flex: 1;">
                ${bookData.status === '借出' ? '↩️ 归还' : '📤 借出'}
            </a>
            <a href="/edit/${bookData.id}/" class="btn btn-outline-secondary" style="flex: 1;">编辑</a>
        </div>
        <div class="mt-4 pt-3" style="border-top: 1px solid #e0e0e0;">
            <h6 class="mb-3">💬 评论</h6>
            <div id="book-comments" class="mb-3" style="max-height: 200px; overflow-y: auto;">
                <p class="text-muted small">加载中...</p>
            </div>
            <div class="input-group">
                <input type="text" id="comment-input" class="form-control" placeholder="写下你的评论...">
                <button class="btn btn-primary" onclick="submitComment(${bookData.id})">发送</button>
            </div>
        </div>
    `;

    modal.style.display = 'flex';
    loadBookComments(bookData.id);
}

function closeBookModal() {
    const modal = document.getElementById('bookModal');
    if (modal) modal.style.display = 'none';
}

function loadBookComments(bookId) {
    const container = document.getElementById('book-comments');
    fetch(`/api/book/${bookId}/comments/`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.comments.length > 0) {
                container.innerHTML = data.comments.map(c => `
                    <div class="mb-2 p-2" style="background: #f8f9fa; border-radius: 8px;">
                        <div class="d-flex justify-content-between">
                            <small class="fw-bold">${c.user}</small>
                            <small class="text-muted">${c.created_at}</small>
                        </div>
                        <div class="small mt-1">${c.content}</div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<p class="text-muted small mb-0">暂无评论</p>';
            }
        })
        .catch(() => {
            container.innerHTML = '<p class="text-muted small mb-0">加载失败</p>';
        });
}

function submitComment(bookId) {
    const input = document.getElementById('comment-input');
    const content = input.value.trim();
    if (!content) {
        showToast('请输入评论内容', 'error');
        return;
    }

    fetch(`/api/book/${bookId}/comment/add/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCsrfToken()
        },
        body: JSON.stringify({ content: content })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            input.value = '';
            loadBookComments(bookId);
            showToast('评论成功');
        } else {
            showToast(data.error || '评论失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// ========== 浮动按钮 ==========

function updateFabButton(tab) {
    const fabContainer = document.getElementById('fabContainer');
    const fabMenu = document.getElementById('fabMenu');

    if (!fabContainer) return;

    if (tab === 'books' || tab === 'shelf') {
        fabContainer.style.display = 'block';

        if (tab === 'books') {
            fabMenu.innerHTML = `
                <div class="fab-menu-item" onclick="openBarcodeScanner()">
                    <span class="icon">📷</span>
                    <span class="text">条形码录入</span>
                </div>
                <div class="fab-menu-item" onclick="openISBNInput()">
                    <span class="icon">🔢</span>
                    <span class="text">ISBN录入</span>
                </div>
                <a href="/add/" class="fab-menu-item">
                    <span class="icon">✏️</span>
                    <span class="text">手动录入</span>
                </a>
            `;
        } else if (tab === 'shelf') {
            fabMenu.innerHTML = `
                <div class="fab-menu-item" onclick="openAddShelfModal()">
                    <span class="icon">🏠</span>
                    <span class="text">添加书架位置</span>
                </div>
                <div class="fab-menu-item" onclick="openManageShelfModal()">
                    <span class="icon">⚙️</span>
                    <span class="text">管理书架位置</span>
                </div>
            `;
        }
    } else {
        fabContainer.style.display = 'none';
    }
}

function toggleFabMenu() {
    const fabMenu = document.getElementById('fabMenu');
    const fabBtn = document.getElementById('fabBtn');
    fabMenu.classList.toggle('show');
    fabBtn.classList.toggle('active');
}

// ========== 条形码/ISBN扫描 ==========

let videoStream = null;
let scanInterval = null;

function openBarcodeScanner() {
    toggleFabMenu();
    const modal = document.getElementById('scanModal');
    const content = document.getElementById('scanModalContent');
    document.getElementById('scanModalTitle').textContent = '📷 条形码录入';

    content.innerHTML = `
        <div class="isbn-input-section">
            <div id="scanner-container" style="position: relative; background: #000; border-radius: 12px; overflow: hidden; height: 300px;">
                <video id="barcode-video" style="width: 100%; height: 100%; object-fit: cover;"></video>
                <div id="scan-overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 80%; height: 60px; border: 2px solid #667eea; border-radius: 8px; box-shadow: 0 0 0 9999px rgba(0,0,0,0.3);"></div>
                <div id="scan-hint" style="position: absolute; bottom: 20px; left: 0; right: 0; text-align: center; color: white; font-size: 14px;">将条形码对准框内</div>
            </div>
            <div id="scan-status" class="text-center mt-3">
                <button id="startScanBtn" class="btn btn-primary" onclick="startCamera()">
                    📷 开启摄像头
                </button>
                <button id="stopScanBtn" class="btn btn-secondary" onclick="stopCamera()" style="display: none;">
                    ⏹️ 停止扫描
                </button>
            </div>
            <div class="mt-4">
                <label class="form-label">或直接输入条形码：</label>
                <div class="input-group">
                    <input type="text" id="barcodeInput" class="form-control" placeholder="输入条形码数字">
                    <button class="btn btn-primary" onclick="searchByBarcode()">查询</button>
                </div>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
}

async function startCamera() {
    try {
        const video = document.getElementById('barcode-video');
        videoStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment', width: 640, height: 480 }
        });
        video.srcObject = videoStream;
        video.play();

        document.getElementById('startScanBtn').style.display = 'none';
        document.getElementById('stopScanBtn').style.display = 'inline-block';
        document.getElementById('scan-hint').textContent = '扫描中...请将条形码对准框内';

        startBarcodeScanning();
    } catch (error) {
        console.error('摄像头错误:', error);
        alert('无法访问摄像头，请确保已授权摄像头权限');
    }
}

function stopCamera() {
    if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        videoStream = null;
    }
    if (scanInterval) {
        clearInterval(scanInterval);
        scanInterval = null;
    }
    const startBtn = document.getElementById('startScanBtn');
    const stopBtn = document.getElementById('stopScanBtn');
    const hint = document.getElementById('scan-hint');
    if (startBtn) startBtn.style.display = 'inline-block';
    if (stopBtn) stopBtn.style.display = 'none';
    if (hint) hint.textContent = '将条形码对准框内';
}

function startBarcodeScanning() {
    if (typeof Quagga === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/@ericblade/quagga2@1.8.4/dist/quagga.min.js';
        script.onload = initQuagga;
        script.onerror = () => {
            console.log('QuaggaJS 加载失败，使用简化扫描');
            simpleBarcodeScan();
        };
        document.head.appendChild(script);
    } else {
        initQuagga();
    }
}

function initQuagga() {
    const video = document.getElementById('barcode-video');
    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: video,
            constraints: { facingMode: "environment" }
        },
        decoder: { readers: ["ean_reader", "ean_8_reader", "code_128_reader"] },
        locate: true
    }, function(err) {
        if (err) {
            console.error('Quagga初始化失败:', err);
            simpleBarcodeScan();
            return;
        }
        Quagga.start();
        Quagga.onDetected(onBarcodeDetected);
    });
}

function onBarcodeDetected(result) {
    if (result && result.codeResult) {
        const code = result.codeResult.code;
        document.getElementById('barcodeInput').value = code;
        document.getElementById('scan-hint').textContent = `✅ 识别成功: ${code}`;
        stopCamera();
        if (typeof Quagga !== 'undefined') {
            Quagga.stop();
        }
        setTimeout(() => searchByBarcode(), 500);
    }
}

function simpleBarcodeScan() {
    let lastCode = '';
    scanInterval = setInterval(() => {
        const input = document.getElementById('barcodeInput');
        if (input && input.value && input.value !== lastCode && input.value.length >= 8) {
            lastCode = input.value;
            document.getElementById('scan-hint').textContent = `检测到: ${input.value}`;
            stopCamera();
            searchByBarcode();
        }
    }, 500);
}

function openISBNInput() {
    toggleFabMenu();
    const modal = document.getElementById('scanModal');
    const content = document.getElementById('scanModalContent');
    document.getElementById('scanModalTitle').textContent = '🔢 ISBN录入';

    content.innerHTML = `
        <div class="isbn-input-section">
            <div class="text-center py-3">
                <div style="font-size: 48px; margin-bottom: 15px;">🔢</div>
                <h5>ISBN快速录入</h5>
                <p class="text-muted mt-2">输入ISBN号自动获取书籍信息</p>
            </div>
            <div class="mt-3">
                <label class="form-label">ISBN号：</label>
                <div class="input-group">
                    <input type="text" id="isbnInput" class="form-control" placeholder="如：9787111234567" maxlength="17">
                    <button class="btn btn-primary" onclick="searchByISBN()">查询</button>
                </div>
                <div class="form-text">支持10位或13位ISBN，可包含连字符</div>
            </div>
            <div id="isbnResult" class="mt-3"></div>
        </div>
    `;
    modal.style.display = 'flex';

    document.getElementById('isbnInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') searchByISBN();
    });
}

function searchByBarcode() {
    const barcode = document.getElementById('barcodeInput').value.trim();
    if (!barcode) {
        showToast('请输入条形码', 'error');
        return;
    }
    searchBookByCode(barcode);
}

function searchByISBN() {
    const isbn = document.getElementById('isbnInput').value.trim();
    if (!isbn) {
        showToast('请输入ISBN号', 'error');
        return;
    }
    searchBookByCode(isbn);
}

function searchBookByCode(code) {
    const resultDiv = document.getElementById('isbnResult') || document.getElementById('barcodeInput').parentElement.parentElement;
    resultDiv.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary"></div><p class="mt-2">正在查询书库...</p><small class="text-muted">约需3-5秒</small></div>';

    const cleanIsbn = code.replace(/[-\s]/g, '');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    fetch(`/api/book/isbn/${cleanIsbn}/`, { signal: controller.signal })
        .then(response => response.json())
        .then(data => {
            clearTimeout(timeoutId);
            if (data.success && data.book) {
                showBookResult(data.book);
            } else {
                const isNetworkError = data.network_error === true;
                showManualEntry(cleanIsbn, data.error || '书库未收录此ISBN', isNetworkError);
            }
        })
        .catch(error => {
            clearTimeout(timeoutId);
            console.error('查询错误:', error);
            showManualEntry(cleanIsbn, '当前网络无法连接图书数据库，请手动录入书籍信息', true);
        });
}

function showManualEntry(isbn, reason, isNetworkError) {
    const resultDiv = document.getElementById('isbnResult');
    const alertClass = isNetworkError ? 'alert-warning' : 'alert-info';
    const icon = isNetworkError ? '⚠️' : 'ℹ️';
    const showSearch = !isNetworkError;

    resultDiv.innerHTML = `
        <div class="alert ${alertClass}">
            <div class="mb-3">
                <strong>${icon} ISBN: ${isbn}</strong>
                <p class="small text-muted mb-0">${reason}</p>
            </div>
            ${showSearch ? `
            <div class="mb-3">
                <label class="form-label small">或输入书名搜索：</label>
                <div class="input-group input-group-sm">
                    <input type="text" id="titleSearchInput" class="form-control" placeholder="输入书名搜索豆瓣书库">
                    <button class="btn btn-primary" onclick="searchByTitle()">搜索</button>
                </div>
            </div>
            <div id="titleSearchResult"></div>
            <hr>
            ` : ''}
            <a href="/add/?isbn=${isbn}" class="btn btn-success btn-sm">
                ✏️ 手动录入此ISBN
            </a>
        </div>
    `;

    document.getElementById('titleSearchInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') searchByTitle();
    });
}

function searchByTitle() {
    const query = document.getElementById('titleSearchInput').value.trim();
    if (!query) return;

    const resultDiv = document.getElementById('titleSearchResult');
    resultDiv.innerHTML = '<div class="text-center py-2"><div class="spinner-border spinner-border-sm"></div> 搜索中...</div>';

    fetch(`/api/book/search/?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.books.length > 0) {
                resultDiv.innerHTML = data.books.map(book => `
                    <div class="card mb-2" style="cursor: pointer;" onclick="selectBookFromSearch('${book.book_name.replace(/'/g, "\\'")}', '${book.author || ''}', '${book.cover || ''}')">
                        <div class="card-body p-2 d-flex align-items-center gap-2">
                            ${book.cover ? `<img src="${book.cover}" style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">` : '<div style="width:40px;height:55px;background:#f0f0f0;border-radius:4px;display:flex;align-items:center;justify-content:center;">📖</div>'}
                            <div>
                                <div class="small fw-bold">${book.book_name}</div>
                                <div class="small text-muted">${book.author || '未知作者'}</div>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                const errorMsg = data.network_error ? '⚠️ 网络连接失败' : '未找到相关书籍';
                resultDiv.innerHTML = `<div class="small text-muted">${errorMsg}</div>`;
            }
        })
        .catch(error => {
            resultDiv.innerHTML = '<div class="small text-warning">⚠️ 网络连接失败，请手动录入</div>';
        });
}

function selectBookFromSearch(title, author, cover) {
    const isbn = document.getElementById('isbnInput')?.value || document.getElementById('barcodeInput')?.value || '';
    const book = { book_name: title, author: author, isbn: isbn, cover: cover };
    showBookResult(book);
}

function showBookResult(book) {
    const resultDiv = document.getElementById('isbnResult');
    resultDiv.innerHTML = `
        <div class="isbn-result">
            <div class="d-flex align-items-start gap-3">
                ${book.cover ? `<img src="${book.cover}" style="width: 80px; height: 110px; object-fit: cover; border-radius: 8px;">` : '<div style="width:80px;height:110px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:32px;">📖</div>'}
                <div style="flex: 1;">
                    <h6 class="mb-1">${book.book_name}</h6>
                    <p class="text-muted mb-1 small">作者：${book.author}</p>
                    <p class="text-muted mb-1 small">ISBN：${book.isbn}</p>
                    ${book.publisher ? `<p class="text-muted mb-0 small">出版社：${book.publisher}</p>` : ''}
                </div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <a href="/add/?isbn=${book.isbn}&title=${encodeURIComponent(book.book_name)}&author=${encodeURIComponent(book.author)}" class="btn btn-success flex-grow-1">
                    ✅ 录入此书
                </a>
                <button class="btn btn-outline-secondary" onclick="document.getElementById('isbnInput').value='';document.getElementById('isbnResult').innerHTML='';">
                    重新查询
                </button>
            </div>
        </div>
    `;
}

function closeScanModal() {
    try {
        if (typeof stopCamera === 'function') stopCamera();
        if (typeof Quagga !== 'undefined') {
            try { Quagga.stop(); } catch(e) {}
        }
    } catch(e) {}
    const modal = document.getElementById('scanModal');
    if (modal) modal.style.display = 'none';
}

// ========== 书架管理 ==========

function openAddShelfModal() {
    toggleFabMenu();
    const modal = document.getElementById('shelfModal');
    const content = document.getElementById('shelfModalContent');
    document.getElementById('shelfModalTitle').textContent = '🏠 添加书架位置';

    content.innerHTML = `
        <div class="isbn-input-section">
            <div class="mb-3">
                <label class="form-label">位置名称</label>
                <input type="text" id="shelf-name" class="form-control" placeholder="如：客厅书架、卧室床头柜">
            </div>
            <div class="mb-3">
                <label class="form-label">位置描述（可选）</label>
                <input type="text" id="shelf-desc" class="form-control" placeholder="如：靠窗位置">
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-primary flex-grow-1" onclick="addShelfLocation()">添加</button>
                <button class="btn btn-secondary" onclick="closeShelfModal()">取消</button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
}

function openManageShelfModal() {
    toggleFabMenu();
    const modal = document.getElementById('shelfModal');
    const content = document.getElementById('shelfModalContent');
    document.getElementById('shelfModalTitle').textContent = '⚙️ 管理书架位置';

    content.innerHTML = `<div class="isbn-input-section"><p class="text-center">加载中...</p></div>`;

    fetch('/api/shelf/locations/')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let html = '<div class="isbn-input-section">';
                if (data.locations.length === 0) {
                    html += '<p class="text-center text-muted">暂无自定义书架位置</p>';
                } else {
                    data.locations.forEach(loc => {
                        html += `
                            <div class="d-flex align-items-center justify-content-between p-3 mb-2" style="background: #f8f9fa; border-radius: 10px;">
                                <div>
                                    <strong>${loc.name}</strong>
                                    <br><small class="text-muted">${loc.book_count} 本书 ${loc.description ? '· ' + loc.description : ''}</small>
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editShelfLocation(${loc.id}, '${loc.name}', '${loc.description || ''}')">编辑</button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteShelfLocation(${loc.id}, '${loc.name}')">删除</button>
                                </div>
                            </div>
                        `;
                    });
                }
                html += '</div>';
                content.innerHTML = html;
            }
        });

    modal.style.display = 'flex';
}

function addShelfLocation() {
    const name = document.getElementById('shelf-name').value.trim();
    const desc = document.getElementById('shelf-desc').value.trim();
    if (!name) { showToast('请输入位置名称', 'error'); return; }

    fetch('/api/shelf/location/add/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description: desc })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('添加成功');
            closeShelfModal();
            loadShelfLocations();
        } else {
            showToast(data.error || '添加失败', 'error');
        }
    });
}

function editShelfLocation(id, name, desc) {
    const modal = document.getElementById('shelfModal');
    const content = document.getElementById('shelfModalContent');
    document.getElementById('shelfModalTitle').textContent = '✏️ 编辑书架位置';

    content.innerHTML = `
        <div class="isbn-input-section">
            <div class="mb-3">
                <label class="form-label">位置名称</label>
                <input type="text" id="shelf-name" class="form-control" value="${name}">
            </div>
            <div class="mb-3">
                <label class="form-label">位置描述</label>
                <input type="text" id="shelf-desc" class="form-control" value="${desc}">
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-primary flex-grow-1" onclick="saveShelfLocation(${id})">保存</button>
                <button class="btn btn-secondary" onclick="openManageShelfModal()">返回</button>
            </div>
        </div>
    `;
}

function saveShelfLocation(id) {
    const name = document.getElementById('shelf-name').value.trim();
    const desc = document.getElementById('shelf-desc').value.trim();
    if (!name) { showToast('请输入位置名称', 'error'); return; }

    fetch(`/api/shelf/location/edit/${id}/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description: desc })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('保存成功');
            openManageShelfModal();
            loadShelfLocations();
        } else {
            showToast(data.error || '保存失败', 'error');
        }
    });
}

function deleteShelfLocation(id, name) {
    if (!confirm(`确定删除「${name}」吗？相关书籍的存放位置不会被清除。`)) return;

    fetch(`/api/shelf/location/delete/${id}/`, { method: 'POST' })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('删除成功');
            openManageShelfModal();
            loadShelfLocations();
        } else {
            showToast(data.error || '删除失败', 'error');
        }
    });
}

function loadShelfLocations() {
    fetch('/api/shelf/locations/')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                const nav = document.getElementById('shelf-sub-nav');
                const customItems = nav.querySelectorAll('.sub-nav-item.custom');
                customItems.forEach(item => item.remove());

                data.locations.forEach(loc => {
                    const item = document.createElement('div');
                    item.className = 'sub-nav-item custom';
                    item.dataset.shelf = loc.name;
                    item.textContent = loc.name;
                    item.addEventListener('click', function() {
                        document.querySelectorAll('#shelf-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
                        this.classList.add('active');
                        filterShelfBooks(this.dataset.shelf);
                    });
                    nav.appendChild(item);
                });
            }
        });
}

function closeShelfModal() {
    const modal = document.getElementById('shelfModal');
    if (modal) modal.style.display = 'none';
}

// ========== 日历功能 ==========

function initCalendar() {
    renderCalendar();
}

function renderCalendar() {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();

    document.getElementById('calendar-title').textContent = `${year}年${month + 1}月`;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    let html = '';

    for (let i = 0; i < firstDay; i++) {
        html += '<div class="calendar-day"></div>';
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
        const dayEvents = [];

        allRecords.forEach(record => {
            if (record.borrowDate) {
                const parts = record.borrowDate.split('-');
                if (parseInt(parts[0]) === year && parseInt(parts[1]) - 1 === month && parseInt(parts[2]) === day) {
                    dayEvents.push({ text: `📤 ${record.book_name}`, type: 'borrow', book: record.book_name, borrower: record.borrower, date: record.borrowDate });
                }
            }

            if (record.returnDate) {
                const parts = record.returnDate.split('-');
                if (parseInt(parts[0]) === year && parseInt(parts[1]) - 1 === month && parseInt(parts[2]) === day) {
                    dayEvents.push({ text: `↩️ ${record.book_name}`, type: 'return', book: record.book_name, borrower: record.borrower, date: record.returnDate });
                }
            }
        });

        const hasEvents = dayEvents.length > 0;
        html += `
            <div class="calendar-day ${isToday ? 'today' : ''} ${hasEvents ? 'has-events' : ''}" ${hasEvents ? `onclick="showDayEvents(${year}, ${month}, ${day})" style="cursor: pointer;"` : ''}>
                <div class="calendar-day-number">${day}</div>
                ${dayEvents.slice(0, 2).map(e => `<div class="calendar-event ${e.type === 'return' ? 'calendar-event-return' : ''}" title="${e.type === 'return' ? '归还' : '借出'}">${e.text}</div>`).join('')}
                ${dayEvents.length > 2 ? `<div class="calendar-event" style="background: #6c757d;">+${dayEvents.length - 2} 更多</div>` : ''}
            </div>
        `;
    }

    const grid = document.querySelector('#records-calendar-view .calendar-grid');
    const existingDays = grid.querySelectorAll('.calendar-day');
    existingDays.forEach(d => d.remove());
    grid.insertAdjacentHTML('beforeend', html);
}

function showDayEvents(year, month, day) {
    const dayEvents = [];

    allRecords.forEach(record => {
        if (record.borrowDate) {
            const parts = record.borrowDate.split('-');
            if (parseInt(parts[0]) === year && parseInt(parts[1]) - 1 === month && parseInt(parts[2]) === day) {
                dayEvents.push({
                    text: `📤 借出《${record.book_name}》`,
                    type: 'borrow',
                    book: record.book_name,
                    borrower: record.borrower,
                    time: record.borrowDate,
                    returnTime: record.returnDate || null
                });
            }
        }

        if (record.returnDate) {
            const parts = record.returnDate.split('-');
            if (parseInt(parts[0]) === year && parseInt(parts[1]) - 1 === month && parseInt(parts[2]) === day) {
                dayEvents.push({
                    text: `↩️ 归还《${record.book_name}》`,
                    type: 'return',
                    book: record.book_name,
                    borrower: record.borrower,
                    time: record.returnDate
                });
            }
        }
    });

    if (dayEvents.length === 0) return;

    const modal = document.getElementById('scanModal');
    const content = document.getElementById('scanModalContent');
    document.getElementById('scanModalTitle').textContent = `📅 ${year}年${month + 1}月${day}日 借阅记录`;

    content.innerHTML = `
        <div class="isbn-input-section">
            ${dayEvents.map(e => `
                <div class="d-flex align-items-start gap-3 p-3 mb-2" style="background: ${e.type === 'return' ? '#d4edda' : '#f8d7da'}; border-radius: 10px;">
                    <div style="font-size: 24px;">${e.type === 'return' ? '↩️' : '📤'}</div>
                    <div style="flex: 1;">
                        <div class="fw-bold">${e.book}</div>
                        <div class="small text-muted">
                            ${e.type === 'return' ? '归还' : '借出'} · 借阅人：${e.borrower || '未知'}
                        </div>
                        <div class="small text-muted mt-1">
                            ${e.type === 'return' ? '归还时间' : '借阅时间'}：${e.time || '未知'}
                        </div>
                        ${e.type === 'borrow' && e.returnTime ? `<div class="small text-success mt-1">归还时间：${e.returnTime}</div>` : ''}
                        ${e.type === 'borrow' && !e.returnTime ? `<div class="small text-warning mt-1">状态：未归还</div>` : ''}
                    </div>
                </div>
            `).join('')}
            <div class="text-center mt-3">
                <button class="btn btn-secondary" onclick="closeScanModal()">关闭</button>
            </div>
        </div>
    `;

    modal.style.display = 'flex';
}

function changeMonth(delta) {
    currentMonth.setMonth(currentMonth.getMonth() + delta);
    renderCalendar();
}

// ========== 借阅记录 ==========

function filterRecords() {
    const search = document.getElementById('record-search').value.toLowerCase();
    const filter = document.getElementById('record-filter').value;
    const month = document.getElementById('record-month').value;
    const borrowerFilter = document.getElementById('record-borrower')?.value || 'all';

    document.querySelectorAll('#records-list-view .record-item').forEach(item => {
        const bookName = item.dataset.bookName.toLowerCase();
        const borrower = item.dataset.borrower.toLowerCase();
        const status = item.dataset.status;
        const recordDate = item.dataset.date;
        const recordMonth = recordDate ? parseInt(recordDate.split('-')[1]) : 0;

        const matchSearch = bookName.includes(search) || borrower.includes(search);
        const matchFilter = filter === 'all' || status === filter;
        const matchMonth = month === 'all' || recordMonth === parseInt(month);
        const matchBorrower = borrowerFilter === 'all' || borrower.includes(borrowerFilter.toLowerCase());

        item.style.display = (matchSearch && matchFilter && matchMonth && matchBorrower) ? '' : 'none';
    });
}

function deleteRecord(recordId, bookName) {
    if (!confirm(`确定要删除《${bookName}》的借阅记录吗？`)) return;

    fetch(`/records/delete/${recordId}/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': getCsrfToken() }
    }).then(response => {
        if (response.ok) {
            showToast('借阅记录已删除');
            location.reload();
        } else {
            showToast('删除失败', 'error');
        }
    }).catch(error => {
        showToast('网络错误', 'error');
    });
}

// ========== 统计功能 ==========

function loadStatistics() {
    fetch('/api/borrow/statistics/')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                renderStatistics(data.data);
            }
        });
}

function renderStatistics(stats) {
    document.getElementById('stat-total-books').textContent = stats.collection_stats.total;
    document.getElementById('stat-borrowed').textContent = stats.collection_stats.borrowed;
    document.getElementById('stat-weekly').textContent = stats.weekly_stats.borrows;
    document.getElementById('stat-weekly-returns').textContent = stats.weekly_stats.returns;

    const borrowerRank = document.getElementById('stat-borrower-rank');
    if (stats.borrower_stats.length > 0) {
        borrowerRank.innerHTML = stats.borrower_stats.map((b, i) => `
            <div class="d-flex align-items-center justify-content-between py-2 ${i > 0 ? 'border-top' : ''}">
                <div>
                    <span class="badge ${i < 3 ? 'bg-warning' : 'bg-secondary'} me-2">${i + 1}</span>
                    ${b.borrower_name || '未知'}
                </div>
                <span class="badge bg-primary">${b.count}次</span>
            </div>
        `).join('');
    } else {
        borrowerRank.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
    }

    const bookRank = document.getElementById('stat-book-rank');
    if (stats.book_stats.length > 0) {
        bookRank.innerHTML = stats.book_stats.map((b, i) => `
            <div class="d-flex align-items-center justify-content-between py-2 ${i > 0 ? 'border-top' : ''}">
                <div>
                    <span class="badge ${i < 3 ? 'bg-warning' : 'bg-secondary'} me-2">${i + 1}</span>
                    ${b.book__book_name}
                </div>
                <span class="badge bg-primary">${b.count}次</span>
            </div>
        `).join('');
    } else {
        bookRank.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
    }

    const unreturned = document.getElementById('stat-unreturned');
    if (stats.unreturned_books.length > 0) {
        unreturned.innerHTML = stats.unreturned_books.map(b => `
            <div class="d-flex justify-content-between py-2 border-top">
                <div>
                    <div>${b.book_name}</div>
                    <small class="text-muted">借阅人：${b.borrower}</small>
                </div>
                <small class="text-muted">${b.borrow_date}</small>
            </div>
        `).join('');
    } else {
        unreturned.innerHTML = '<p class="text-muted text-center mb-0">全部已归还 ✓</p>';
    }

    const category = document.getElementById('stat-category');
    if (stats.collection_stats.by_category.length > 0) {
        const total = stats.collection_stats.total;
        category.innerHTML = stats.collection_stats.by_category.map(c => {
            const percent = Math.round(c.count / total * 100);
            return `
                <div class="mb-2">
                    <div class="d-flex justify-content-between mb-1">
                        <span>${c.book_type || '未分类'}</span>
                        <span>${c.count}本 (${percent}%)</span>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar" style="width: ${percent}%; background: #667eea;"></div>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        category.innerHTML = '<p class="text-muted text-center mb-0">暂无数据</p>';
    }
}

function fixBorrowerNames() {
    if (!confirm('确定要修复借阅记录中缺失的借阅人姓名吗？')) return;

    fetch('/api/borrow/fix-names/', {
        method: 'POST',
        headers: { 'X-CSRFToken': getCsrfToken() }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast(`修复完成！共修复 ${data.fixed_count} 条记录`);
            setTimeout(() => location.reload(), 1500);
        } else {
            showToast(data.error || '修复失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// ========== 书摘书评 ==========

function loadNotes() {
    const container = document.getElementById('notes-container');
    const activeNav = document.querySelector('#notes-sub-nav .sub-nav-item.active');
    const noteType = activeNav ? activeNav.dataset.noteType : 'all';
    const bookFilter = document.getElementById('notes-book-filter')?.value || 'all';

    container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><p class="mt-2">加载中...</p></div>';

    let url = '/api/notes/?';
    if (bookFilter !== 'all') {
        url += `book_id=${bookFilter}`;
    }

    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let notes = data.notes;
                if (noteType !== 'all') {
                    notes = notes.filter(n => n.note_type === noteType);
                }
                renderNotes(notes);
            } else {
                container.innerHTML = '<div class="text-center py-5 text-muted">加载失败</div>';
            }
        })
        .catch(() => {
            container.innerHTML = '<div class="text-center py-5 text-muted">网络错误</div>';
        });
}

function renderNotes(notes) {
    const container = document.getElementById('notes-container');
    if (notes.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5" style="color: #999;">
                <div style="font-size: 48px;">📝</div>
                <h4>暂无书摘书评</h4>
                <p class="mt-2">点击右上角添加你的第一条书摘或书评</p>
            </div>
        `;
        return;
    }

    container.innerHTML = notes.map(note => `
        <div class="card mb-3" style="border-radius: 12px; border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <span class="badge ${note.note_type === 'excerpt' ? 'bg-info' : 'bg-warning'} me-2">${note.note_type_display}</span>
                        <small class="text-muted">《${note.book_name}》</small>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <small class="text-muted">${note.created_at}</small>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteNote(${note.id})" title="删除">🗑️</button>
                    </div>
                </div>
                <h6 class="card-title">${note.title}</h6>
                <p class="card-text text-muted small" style="white-space: pre-wrap;">${note.content}</p>
                ${note.page_number ? `<small class="text-muted">📖 第 ${note.page_number} 页</small>` : ''}
            </div>
        </div>
    `).join('');
}

function loadNotesBookFilter() {
    const select = document.getElementById('notes-book-filter');
    select.innerHTML = '<option value="all">全部书籍</option>';
    allBooks.forEach(book => {
        select.innerHTML += `<option value="${book.id}">${book.book_name}</option>`;
    });
}

function filterNotes() {
    loadNotes();
}

function openAddNoteModal() {
    const modal = document.getElementById('scanModal');
    const content = document.getElementById('scanModalContent');
    document.getElementById('scanModalTitle').textContent = '📝 添加书摘/书评';

    let bookOptions = allBooks.map(b => `<option value="${b.id}">${b.book_name}</option>`).join('');

    content.innerHTML = `
        <div class="isbn-input-section">
            <div class="mb-3">
                <label class="form-label">选择书籍 *</label>
                <select id="note-book" class="form-select" required>
                    <option value="">请选择书籍</option>
                    ${bookOptions}
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">类型 *</label>
                <select id="note-type" class="form-select">
                    <option value="excerpt">书摘</option>
                    <option value="review">书评</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">标题 *</label>
                <input type="text" id="note-title" class="form-control" placeholder="请输入标题">
            </div>
            <div class="mb-3">
                <label class="form-label">页码（可选）</label>
                <input type="number" id="note-page" class="form-control" placeholder="如：42">
            </div>
            <div class="mb-3">
                <label class="form-label">内容 *</label>
                <textarea id="note-content" class="form-control" rows="5" placeholder="请输入内容..."></textarea>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-primary flex-grow-1" onclick="submitNote()">提交</button>
                <button class="btn btn-secondary" onclick="closeScanModal()">取消</button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
}

function submitNote() {
    const bookId = document.getElementById('note-book').value;
    const noteType = document.getElementById('note-type').value;
    const title = document.getElementById('note-title').value.trim();
    const page = document.getElementById('note-page').value;
    const content = document.getElementById('note-content').value.trim();

    if (!bookId || !title || !content) {
        showToast('请填写完整信息', 'error');
        return;
    }

    fetch('/api/note/add/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCsrfToken()
        },
        body: JSON.stringify({
            book_id: bookId,
            note_type: noteType,
            title: title,
            page_number: page || null,
            content: content
        })
    })
    .then(r => {
        if (!r.ok) throw new Error('服务器错误: ' + r.status);
        return r.json();
    })
    .then(data => {
        if (data.success) {
            showToast('添加成功');
            closeScanModal();
            loadNotes();
        } else {
            showToast(data.error || '添加失败', 'error');
        }
    })
    .catch(err => {
        console.error('提交错误:', err);
        showToast('网络错误，请检查登录状态', 'error');
    });
}

function deleteNote(noteId) {
    if (!confirm('确定要删除这条记录吗？')) return;

    fetch(`/api/note/${noteId}/delete/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCsrfToken()
        }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('删除成功');
            loadNotes();
        } else {
            showToast(data.error || '删除失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// ========== 用户管理 ==========

function loadMembersList() {
    const container = document.getElementById('members-list');
    fetch('/api/users/')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (data.users.length === 0) {
                    container.innerHTML = '<div class="settings-card" style="text-align: center; color: #999;"><p>暂无注册用户</p></div>';
                    return;
                }
                container.innerHTML = data.users.map(user => `
                    <div class="settings-card">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="user-avatar" style="width: 40px; height: 40px; font-size: 16px; margin-right: 12px;">
                                    ${user.username.charAt(0).toUpperCase()}
                                </div>
                                <div>
                                    <div style="font-weight: 600;">${user.username}</div>
                                    <small class="text-muted">${user.reader_name || ''}</small>
                                </div>
                            </div>
                            <span class="badge ${user.is_superuser ? 'bg-danger' : 'bg-secondary'}">
                                ${user.is_superuser ? '管理员' : '成员'}
                            </span>
                        </div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div class="settings-card" style="text-align: center; color: #999;"><p>无权限查看用户列表</p></div>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            container.innerHTML = '<div class="settings-card" style="text-align: center; color: #999;"><p>加载失败</p></div>';
        });
}

// ========== 工具函数 ==========

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'error' ? 'danger' : 'success'} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 10000; min-width: 300px; animation: slideIn 0.3s ease-out;';
    toast.innerHTML = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

function getCsrfToken() {
    const input = document.querySelector('[name=csrfmiddlewaretoken]');
    if (input && input.value) return input.value;

    const match = document.cookie.match(/csrftoken=([^;]+)/);
    if (match && match[1]) return match[1];

    return '';
}

// ========== 书摘书评分类切换 ==========
function initNotesNav() {
    document.querySelectorAll('#notes-sub-nav .sub-nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('#notes-sub-nav .sub-nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            loadNotes();
        });
    });
}

// ========== 点击遮罩关闭弹窗 ==========
function initModalOverlays() {
    document.getElementById('bookModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeBookModal();
    });
    document.getElementById('scanModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeScanModal();
    });
    document.getElementById('shelfModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeShelfModal();
    });
}

// 点击其他地方关闭浮动菜单
document.addEventListener('click', function(e) {
    const fabContainer = document.querySelector('.fab-container');
    if (fabContainer && !fabContainer.contains(e.target)) {
        document.getElementById('fabMenu')?.classList.remove('show');
        document.getElementById('fabBtn')?.classList.remove('active');
    }
});
