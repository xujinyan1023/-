
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q, Count
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_exempt
from django.contrib.auth.models import User
from .models import Book, Reader, BorrowRecord, UserProfile, ShelfLocation, BookComment, BookNote, Category, RecentLogin, Notification, OperationLog, BookCommentLike, ReadingCheckIn, UserBadge
import json
import requests
from requests.exceptions import ConnectionError, Timeout


def get_user_profile(request):
    if request.user.is_authenticated:
        profile, _ = UserProfile.objects.get_or_create(user=request.user)
        return profile
    return None


def check_permission(request, action):
    if request.user.is_superuser:
        return True
    # 所有登录用户都有基本权限
    if not request.user.is_authenticated:
        return False
    # 添加、编辑、删除只有管理员可以操作
    if action in ['add', 'edit', 'delete']:
        return False
    profile = get_user_profile(request)
    if not profile:
        return True  # 有配置的用户可以访问
    return profile.has_permission(action)


def permission_required(action):
    def decorator(view_func):
        def wrapped_view(request, *args, **kwargs):
            if not check_permission(request, action):
                return redirect('book_list')
            return view_func(request, *args, **kwargs)
        return wrapped_view
    return decorator


def create_operation_log(request, action, target_type='', target_id=None, target_name='', detail=''):
    """创建操作日志"""
    try:
        OperationLog.objects.create(
            user=request.user if request.user.is_authenticated else None,
            action=action,
            target_type=target_type,
            target_id=target_id,
            target_name=target_name,
            detail=detail,
            ip_address=request.META.get('REMOTE_ADDR', '')
        )
    except Exception:
        pass  # 日志记录失败不影响主流程


def login_view(request):
    if request.user.is_authenticated:
        return redirect('book_list')
    if request.method == "POST":
        account = request.POST.get("account", "").strip()
        password = request.POST.get("password", "")

        # 支持手机号和用户名双重登录（仿微信）
        user = None

        # 先尝试用户名登录
        user = authenticate(request, username=account, password=password)

        # 如果用户名登录失败，尝试手机号登录
        if not user:
            try:
                profile = UserProfile.objects.get(phone=account)
                user = authenticate(request, username=profile.user.username, password=password)
            except UserProfile.DoesNotExist:
                pass

        if user:
            login(request, user)
            # 记录登录日志
            OperationLog.objects.create(
                user=user,
                action='login',
                target_type='user',
                target_id=user.id,
                target_name=user.username,
                ip_address=request.META.get('REMOTE_ADDR', '')
            )
            # 创建或更新最近登录记录
            recent_login, _ = RecentLogin.objects.get_or_create(user=user)
            # 生成快速登录令牌
            import secrets
            from django.utils import timezone
            token = secrets.token_hex(16)
            recent_login.quick_login_token = token
            recent_login.token_expires = timezone.now() + timezone.timedelta(days=30)
            # 记录密码验证时间和会话
            recent_login.password_verified_at = timezone.now()
            recent_login.session_key = request.session.session_key or ''
            recent_login.switch_count = 0
            recent_login.save()
            return redirect('book_list')
        messages.error(request, '账号/手机号或密码错误，请重新输入')
        return render(request, "login.html")
    return render(request, "login.html")


def logout_view(request):
    # 记录退出日志
    if request.user.is_authenticated:
        OperationLog.objects.create(
            user=request.user,
            action='logout',
            target_type='user',
            target_id=request.user.id,
            target_name=request.user.username,
            ip_address=request.META.get('REMOTE_ADDR', '')
        )
    logout(request)
    return redirect('login')


# 获取最近登录的用户列表
def api_recent_logins(request):
    """获取最近登录的用户列表（仿微信，显示3-5个）"""
    from django.utils import timezone
    from django.conf import settings

    max_logins = getattr(settings, 'ACCOUNT_SWITCH_SETTINGS', {}).get('MAX_RECENT_LOGINS', 5)
    recent_logins = RecentLogin.objects.select_related('user').order_by('-last_login')[:max_logins]
    data = []
    for rl in recent_logins:
        profile = UserProfile.objects.filter(user=rl.user).first()
        # 使用新的display_name属性
        display_name = profile.display_name if profile else rl.user.username
        # 手机号脱敏显示（仿微信）
        phone_masked = ''
        if profile and profile.phone:
            phone_masked = profile.phone[:3] + '****' + profile.phone[-4:]

        data.append({
            'id': rl.user.id,
            'username': rl.user.username,
            'display_name': display_name,
            'phone_masked': phone_masked,
            'is_superuser': rl.user.is_superuser,
            'last_login': rl.last_login.strftime('%Y-%m-%d %H:%M'),
            'can_quick_login': bool(rl.quick_login_token and rl.token_expires and rl.token_expires > timezone.now()),
            'avatar': profile.avatar.url if profile and profile.avatar else ''
        })
    return JsonResponse({'success': True, 'users': data})


# 获取当前用户账户信息
def api_user_info(request):
    # 手动检查登录状态，返回JSON而非重定向
    if not request.user.is_authenticated:
        return JsonResponse({'success': False, 'error': '请先登录'})
    """获取当前用户的账户信息"""
    user = request.user
    profile = get_user_profile(request)

    # 获取显示名称（用户名）
    display_name = profile.reader.reader_name if profile and profile.reader else user.username

    # 账号就是username
    account = user.username

    # 获取最近登录时间
    recent_login = RecentLogin.objects.filter(user=user).first()
    last_login_time = recent_login.last_login.strftime('%Y-%m-%d %H:%M') if recent_login else '暂无记录'

    data = {
        'display_name': display_name,
        'account': account,
        'role': '管理员' if user.is_superuser else '普通成员',
        'phone': profile.phone if profile and profile.phone else '未设置',
        'date_joined': user.date_joined.strftime('%Y-%m-%d %H:%M'),
        'last_login': last_login_time,
        'avatar': profile.avatar.url if profile and profile.avatar else ''
    }
    return JsonResponse({'success': True, 'user': data})


# 更新用户显示名称
@login_required
@require_http_methods(["POST"])
def api_update_display_name(request):
    """更新用户显示名称"""
    data = json.loads(request.body)
    new_name = data.get('display_name', '').strip()

    if not new_name:
        return JsonResponse({'success': False, 'error': '用户名不能为空'})

    if len(new_name) > 20:
        return JsonResponse({'success': False, 'error': '用户名不能超过20个字符'})

    profile = get_user_profile(request)

    # 更新或创建Reader
    reader, _ = Reader.objects.get_or_create(reader_name=new_name)
    profile.reader = reader
    profile.save()

    return JsonResponse({'success': True, 'display_name': new_name})


# 更新用户手机号
@login_required
@require_http_methods(["POST"])
def api_update_phone(request):
    """更新用户手机号"""
    data = json.loads(request.body)
    phone = data.get('phone', '').strip()

    if phone:
        if not phone.isdigit() or len(phone) != 11:
            return JsonResponse({'success': False, 'error': '请输入正确的11位手机号'})

    profile = get_user_profile(request)
    profile.phone = phone if phone else None
    profile.save()

    return JsonResponse({'success': True, 'phone': phone if phone else '未设置'})


# 上传头像
@login_required
@require_http_methods(["POST"])
def api_upload_avatar(request):
    """上传用户头像"""
    avatar = request.FILES.get('avatar')

    if not avatar:
        return JsonResponse({'success': False, 'error': '请选择图片'})

    # 检查文件类型
    allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
    if avatar.content_type not in allowed_types:
        return JsonResponse({'success': False, 'error': '仅支持 JPG、PNG、GIF、WEBP 格式'})

    # 检查文件大小 (最大 2MB)
    if avatar.size > 2 * 1024 * 1024:
        return JsonResponse({'success': False, 'error': '图片大小不能超过 2MB'})

    profile = get_user_profile(request)
    profile.avatar = avatar
    profile.save()

    return JsonResponse({'success': True, 'avatar_url': profile.avatar.url})


# ========== 管理员管理成员功能 ==========

@login_required
def api_members_list(request):
    """获取所有成员列表（仅管理员）"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权限'})

    members = []
    for user in User.objects.all():
        profile = UserProfile.objects.filter(user=user).first()
        reader_name = profile.reader.reader_name if profile and profile.reader else '未设置'
        recent_login = RecentLogin.objects.filter(user=user).first()

        # 统计借阅数据
        total_borrowed = BorrowRecord.objects.filter(borrower=user).count()
        current_borrowed = BorrowRecord.objects.filter(borrower=user, is_returned=False).count()

        members.append({
            'id': user.id,
            'account': user.username,
            'display_name': reader_name,
            'phone': profile.phone if profile and profile.phone else '未设置',
            'role': '管理员' if user.is_superuser else '普通成员',
            'is_superuser': user.is_superuser,
            'date_joined': user.date_joined.strftime('%Y-%m-%d'),
            'last_login': recent_login.last_login.strftime('%Y-%m-%d %H:%M') if recent_login else '暂无记录',
            'avatar': profile.avatar.url if profile and profile.avatar else '',
            'total_borrowed': total_borrowed,
            'current_borrowed': current_borrowed
        })

    return JsonResponse({'success': True, 'members': members})


@login_required
@require_http_methods(["POST"])
def api_member_update(request, user_id):
    """管理员修改成员信息"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权限'})

    try:
        target_user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': '用户不存在'})

    data = json.loads(request.body)
    profile = UserProfile.objects.filter(user=target_user).first()

    if not profile:
        profile = UserProfile.objects.create(user=target_user)

    # 更新用户名
    new_name = data.get('display_name', '').strip()
    if new_name:
        reader, _ = Reader.objects.get_or_create(reader_name=new_name)
        profile.reader = reader

    # 更新手机号
    new_phone = data.get('phone', '').strip()
    if new_phone:
        if not new_phone.isdigit() or len(new_phone) != 11:
            return JsonResponse({'success': False, 'error': '手机号格式不正确'})
        profile.phone = new_phone
    else:
        profile.phone = None

    # 更新角色
    new_role = data.get('role', '')
    if new_role == 'admin':
        target_user.is_superuser = True
        target_user.is_staff = True
    elif new_role == 'member':
        target_user.is_superuser = False
        target_user.is_staff = False

    target_user.save()
    profile.save()

    return JsonResponse({'success': True, 'message': '更新成功'})


@login_required
@require_http_methods(["POST"])
def api_member_reset_password(request, user_id):
    """管理员重置成员密码"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权限'})

    try:
        target_user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': '用户不存在'})

    data = json.loads(request.body)
    new_password = data.get('password', '')

    if len(new_password) < 6:
        return JsonResponse({'success': False, 'error': '密码长度至少6位'})

    target_user.set_password(new_password)
    target_user.save()

    return JsonResponse({'success': True, 'message': '密码重置成功'})


@login_required
@require_http_methods(["DELETE"])
def api_member_delete(request, user_id):
    """管理员删除成员"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权限'})

    if request.user.id == user_id:
        return JsonResponse({'success': False, 'error': '不能删除自己'})

    try:
        target_user = User.objects.get(id=user_id)
        # 将该用户的借阅记录标记为已归还
        BorrowRecord.objects.filter(borrower=target_user, is_returned=False).update(
            is_returned=True,
            return_date=timezone.now()
        )
        target_user.delete()
        return JsonResponse({'success': True, 'message': '删除成功'})
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': '用户不存在'})


# 获取借阅人列表（用于筛选）
def api_borrowers_list(request):
    """获取所有有借阅记录的借阅人列表"""
    # 从借阅记录中获取所有不重复的借阅人姓名
    borrowers = BorrowRecord.objects.values_list('borrower_name', flat=True).distinct()
    borrowers = [b for b in borrowers if b]  # 过滤掉空值

    # 同时获取所有注册用户的用户名
    for user in User.objects.all():
        profile = UserProfile.objects.filter(user=user).first()
        if profile and profile.reader:
            name = profile.reader.reader_name
            if name and name not in borrowers:
                borrowers.append(name)

    return JsonResponse({'success': True, 'borrowers': sorted(borrowers)})


# 搜索借阅记录 API
@login_required
def api_borrow_records_search(request):
    """搜索借阅记录（AJAX）"""
    # 获取搜索参数
    search_book = request.GET.get('search_book', '').strip()
    search_borrower = request.GET.get('search_borrower', '').strip()
    search_author = request.GET.get('search_author', '').strip()
    record_filter = request.GET.get('filter', 'all')  # all, borrowed 或 returned
    search_month = request.GET.get('month', 'all')

    # 超级管理员看所有记录，普通成员只看自己的借阅记录
    if request.user.is_superuser:
        records = BorrowRecord.objects.select_related('book', 'borrower').all().order_by("-borrow_date")
    else:
        profile = UserProfile.objects.filter(user=request.user).first()
        borrower_name = profile.reader.reader_name if profile and profile.reader else request.user.username
        records = BorrowRecord.objects.select_related('book', 'borrower').filter(
            Q(borrower=request.user) | Q(borrower_name=borrower_name)
        ).order_by("-borrow_date")

    # 应用搜索条件
    if search_book:
        records = records.filter(book__book_name__icontains=search_book)
    if search_borrower:
        records = records.filter(borrower_name__icontains=search_borrower)
    if search_author:
        records = records.filter(book__author__icontains=search_author)

    # 借阅状态筛选
    if record_filter == 'borrowed':
        records = records.filter(is_returned=False)
    elif record_filter == 'returned':
        records = records.filter(is_returned=True)

    # 月份筛选
    if search_month != 'all':
        from django.db.models.functions import ExtractMonth
        records = records.annotate(month=ExtractMonth('borrow_date')).filter(month=int(search_month))

    # 返回结果
    data = []
    for record in records[:100]:  # 限制返回100条
        data.append({
            'id': record.id,
            'book_id': record.book.id,
            'book_name': record.book.book_name,
            'author': record.book.author,
            'borrower_name': record.get_borrower_display_name(),
            'borrow_date': record.borrow_date.strftime('%Y-%m-%d %H:%M'),
            'return_date': record.return_date.strftime('%Y-%m-%d %H:%M') if record.return_date else None,
            'is_returned': record.is_returned,
            'cover': record.book.cover.url if record.book.cover else None
        })

    return JsonResponse({'success': True, 'records': data, 'total': records.count()})


# 快速登录
@require_http_methods(["POST"])
def api_quick_login(request):
    """使用令牌快速登录（带安全保护机制）"""
    from django.utils import timezone
    from django.conf import settings

    data = json.loads(request.body)
    user_id = data.get('user_id')
    password = data.get('password', '')
    session_key = request.session.session_key or 'new_session'

    # 获取安全配置
    switch_settings = getattr(settings, 'ACCOUNT_SWITCH_SETTINGS', {})
    password_timeout = switch_settings.get('PASSWORD_VERIFY_TIMEOUT_MINUTES', 60)
    max_switches = switch_settings.get('MAX_SWITCHES_IN_WINDOW', 3)
    switch_window = switch_settings.get('SWITCH_WINDOW_MINUTES', 10)
    inactive_days = switch_settings.get('INACTIVE_ACCOUNT_DAYS', 7)

    if not user_id:
        return JsonResponse({'success': False, 'error': '参数错误'})

    try:
        user = User.objects.get(id=user_id)
        recent_login = RecentLogin.objects.filter(user=user).first()

        if not recent_login:
            return JsonResponse({'success': False, 'error': '无登录记录'})

        now = timezone.now()

        # ===== 安全检查函数 =====
        def check_security_conditions():
            """检查是否需要密码验证，返回 (need_password, reason)"""
            reasons = []

            # 1. 检查密码验证超时
            if recent_login.password_verified_at:
                timeout_threshold = now - timezone.timedelta(minutes=password_timeout)
                if recent_login.password_verified_at < timeout_threshold:
                    reasons.append(f'距离上次密码验证已超过{password_timeout}分钟')
            else:
                reasons.append('首次切换需要密码验证')

            # 2. 检查切换次数限制
            if recent_login.switch_count_reset_at:
                window_threshold = now - timezone.timedelta(minutes=switch_window)
                if recent_login.switch_count_reset_at < window_threshold:
                    # 重置计数
                    recent_login.switch_count = 0
                    recent_login.switch_count_reset_at = now
                    recent_login.save(update_fields=['switch_count', 'switch_count_reset_at'])
                elif recent_login.switch_count >= max_switches:
                    reasons.append(f'短时间内切换次数过多（{max_switches}次/{switch_window}分钟）')
            else:
                recent_login.switch_count_reset_at = now
                recent_login.save(update_fields=['switch_count_reset_at'])

            # 3. 检查浏览器重启（通过session判断）
            session_switch_count = request.session.get('switch_count', 0)
            last_session = request.session.get('last_switch_session', '')
            if last_session and last_session != session_key:
                # 会话变化，可能是浏览器重启
                reasons.append('检测到新会话，需要密码验证')
            request.session['last_switch_session'] = session_key

            # 4. 检查目标账号是否长期未活跃
            inactive_threshold = now - timezone.timedelta(days=inactive_days)
            if recent_login.last_login < inactive_threshold:
                reasons.append(f'该账号已超过{inactive_days}天未使用')

            return len(reasons) > 0, '；'.join(reasons) if reasons else ''

        # ===== 主逻辑 =====
        # 检查是否在10天内（基本条件）
        ten_days_ago = now - timezone.timedelta(days=10)
        in_ten_days = recent_login.last_login >= ten_days_ago and recent_login.quick_login_token
        token_valid = recent_login.token_expires and recent_login.token_expires > now

        if in_ten_days and token_valid:
            # 满足基本条件，检查安全条件
            need_password, reason = check_security_conditions()

            if not need_password:
                # 免密码登录
                login(request, user)
                recent_login.switch_count += 1
                recent_login.save()
                current_session_count = request.session.get('switch_count', 0)
                request.session['switch_count'] = current_session_count + 1
                return JsonResponse({'success': True})
            else:
                # 需要密码验证
                if not password:
                    return JsonResponse({
                        'success': False,
                        'need_password': True,
                        'reason': reason,
                        'error': f'需要密码验证：{reason}'
                    })

        # 超过10天或不满足安全条件，需要密码验证
        if not password:
            need_password, reason = check_security_conditions()
            error_msg = '请输入密码验证'
            if reason:
                error_msg = f'需要密码验证：{reason}'
            return JsonResponse({
                'success': False,
                'need_password': True,
                'reason': reason,
                'error': error_msg
            })

        # 验证密码
        if user.check_password(password):
            login(request, user)
            # 更新令牌和安全记录
            import secrets
            token = secrets.token_hex(16)
            recent_login.quick_login_token = token
            recent_login.token_expires = now + timezone.timedelta(days=30)
            recent_login.password_verified_at = now
            recent_login.switch_count = 1
            recent_login.switch_count_reset_at = now
            recent_login.save()
            request.session['switch_count'] = 1
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'error': '密码错误'})

    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': '用户不存在'})


@login_required
def change_password_view(request):
    """修改密码"""
    if request.method == "POST":
        old_password = request.POST.get("old_password", "")
        new_password = request.POST.get("new_password", "")
        confirm_password = request.POST.get("confirm_password", "")

        # 验证旧密码
        if not request.user.check_password(old_password):
            messages.error(request, '当前密码错误')
            return render(request, "change_password.html")

        # 验证新密码
        if len(new_password) < 6:
            messages.error(request, '新密码长度至少6位')
            return render(request, "change_password.html")

        if new_password != confirm_password:
            messages.error(request, '两次输入的新密码不一致')
            return render(request, "change_password.html")

        if old_password == new_password:
            messages.error(request, '新密码不能与当前密码相同')
            return render(request, "change_password.html")

        # 修改密码
        request.user.set_password(new_password)
        request.user.save()

        # 更新 session，避免被登出
        from django.contrib.auth import update_session_auth_hash
        update_session_auth_hash(request, request.user)

        messages.success(request, '密码修改成功！')
        return redirect('book_list')

    return render(request, "change_password.html")


def register_view(request):
    if request.user.is_authenticated:
        return redirect('book_list')
    
    if request.method == "POST":
        account = request.POST.get("account", "").strip()
        password = request.POST.get("password", "")
        password_confirm = request.POST.get("password_confirm", "")
        display_name = request.POST.get("display_name", "").strip()
        phone = request.POST.get("phone", "").strip()
        avatar = request.FILES.get("avatar")

        # 验证账号（用户名）
        if not account:
            messages.error(request, '请输入登录账号')
            return render(request, "register.html")

        if len(account) < 3:
            messages.error(request, '账号长度至少3位')
            return render(request, "register.html")

        if User.objects.filter(username=account).exists():
            messages.error(request, '该账号已被注册，请换一个')
            return render(request, "register.html")

        # 验证密码
        if password != password_confirm:
            messages.error(request, '两次密码输入不一致')
            return render(request, "register.html")

        if len(password) < 6:
            messages.error(request, '密码长度至少6位')
            return render(request, "register.html")

        # 验证手机号（选填，但如果填写了必须格式正确且唯一）
        if phone:
            if not phone.isdigit() or len(phone) != 11:
                messages.error(request, '请输入正确的11位手机号')
                return render(request, "register.html")
            if UserProfile.objects.filter(phone=phone).exists():
                messages.error(request, '该手机号已被注册')
                return render(request, "register.html")

        # 验证用户名称
        if not display_name:
            display_name = account

        # 创建用户
        user = User.objects.create_user(username=account, password=password)

        # 创建用户配置（手机号选填）
        profile = UserProfile.objects.create(
            user=user,
            role='member',
            phone=phone if phone else None,
            nickname=display_name
        )
        if avatar:
            profile.avatar = avatar

        # 创建或获取读者信息
        Reader.objects.get_or_create(reader_name=display_name)
        reader = Reader.objects.get(reader_name=display_name)
        profile.reader = reader
        profile.save()

        # 创建最近登录记录，记录会话和密码验证时间
        from django.utils import timezone
        recent_login, _ = RecentLogin.objects.get_or_create(user=user)
        recent_login.password_verified_at = timezone.now()
        recent_login.session_key = request.session.session_key or ''
        recent_login.save()

        # 自动登录
        login(request, user)
        messages.success(request, f'注册成功！欢迎 {display_name}')
        return redirect('book_list')

    # GET请求 - 生成验证码
    import random
    import string
    captcha = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    request.session['captcha'] = captcha

    return render(request, "register.html", {'captcha': captcha})


def get_current_user_role(request):
    profile = get_user_profile(request)
    if profile:
        return profile.role
    return 'guest'


def get_current_user_can(action, request):
    return check_permission(request, action)


# 首页：查看全部图书
@ensure_csrf_cookie
def book_list(request):
    # 分页设置
    page = int(request.GET.get('page', 1))
    page_size = 20  # 每页显示20本书

    books = Book.objects.all()
    keyword = request.GET.get('keyword', '')
    if keyword:
        books = books.filter(Q(book_name__icontains=keyword) | Q(author__icontains=keyword))

    # 计算总数和分页
    total_books = books.count()
    total_pages = (total_books + page_size - 1) // page_size
    start_index = (page - 1) * page_size
    books = books[start_index:start_index + page_size]

    # 获取所有在架书籍的ID（用于前端筛选）
    borrowed_book_ids = set(
        BorrowRecord.objects.filter(return_date__isnull=True)
        .values_list('book_id', flat=True)
    )

    # 超级管理员看所有记录，普通成员只看自己的借阅记录
    if request.user.is_authenticated:
        if request.user.is_superuser:
            # 使用 select_related 避免 N+1 查询
            records = BorrowRecord.objects.select_related('book', 'borrower').order_by("-borrow_date")[:50]
        else:
            # 普通成员只看自己的记录
            profile = UserProfile.objects.filter(user=request.user).first()
            borrower_name = profile.reader.reader_name if profile and profile.reader else request.user.username
            records = BorrowRecord.objects.select_related('book', 'borrower').filter(
                Q(borrower=request.user) | Q(borrower_name=borrower_name)
            ).order_by("-borrow_date")[:50]
    else:
        records = BorrowRecord.objects.none()

    return render(request, "list.html", {
        "books": books,
        "keyword": keyword,
        "user_role": get_current_user_role(request),
        "can_add": get_current_user_can('add', request),
        "can_edit": get_current_user_can('edit', request),
        "can_delete": get_current_user_can('delete', request),
        "can_borrow": get_current_user_can('borrow', request),
        "can_return": get_current_user_can('return', request),
        "records": records,
        "borrowed_book_ids": list(borrowed_book_ids),
        # 分页信息
        "current_page": page,
        "total_pages": total_pages,
        "total_books": total_books,
        "has_next": page < total_pages,
        "has_prev": page > 1,
    })


# 录入新书
@login_required
def book_add(request):
    if not check_permission(request, 'add'):
        messages.error(request, '您没有权限执行此操作')
        return redirect('book_list')
    if request.method == "POST":
        name = request.POST.get("book_name", "").strip()
        author = request.POST.get("author", "").strip()
        isbn = request.POST.get("isbn", "").strip() or None
        book_type = request.POST.get("book_type", "其他")
        place = request.POST.get("place", "未填写").strip()
        cover = request.FILES.get("cover")
        description = request.POST.get("description", "").strip()
        publisher = request.POST.get("publisher", "").strip() or None
        publish_date = request.POST.get("publish_date", "").strip() or None

        if not name or not author:
            messages.error(request, '请填写书名和作者')
            return render(request, "add.html", {
                'prefill_isbn': isbn or '',
                'prefill_title': name,
                'prefill_author': author,
                'prefill_publisher': publisher or '',
                'prefill_publish_date': publish_date or '',
            })

        # 检查重复录入
        duplicate = None
        if isbn:
            # 有 ISBN 时，优先按 ISBN 检查
            duplicate = Book.objects.filter(isbn=isbn).first()
        if not duplicate:
            # 按书名+作者检查
            duplicate = Book.objects.filter(book_name=name, author=author).first()

        if duplicate:
            messages.warning(request, f'《{name}》已存在（ID: {duplicate.id}，状态: {duplicate.status}），请勿重复录入')
            return redirect("book_list")

        book = Book.objects.create(
            book_name=name,
            author=author,
            isbn=isbn,
            status="在架",
            book_type=book_type,
            place=place,
            description=description,
            publisher=publisher,
        )
        if cover:
            book.cover = cover
        if publish_date:
            try:
                book.publish_date = publish_date
            except:
                pass
        book.save()
        # 记录操作日志
        create_operation_log(request, 'add_book', 'book', book.id, name)
        messages.success(request, f'《{name}》添加成功！')
        return redirect("book_list")
    # 从URL参数获取预填充信息
    context = {
        'prefill_isbn': request.GET.get('isbn', ''),
        'prefill_title': request.GET.get('title', ''),
        'prefill_author': request.GET.get('author', ''),
        'prefill_publisher': request.GET.get('publisher', ''),
        'prefill_publish_date': request.GET.get('publish_date', ''),
    }
    return render(request, "add.html", context)

# 搜索图书
def book_search(request):
    keyword = request.GET.get("keyword", "")
    books = Book.objects.all()
    if keyword:
        books = books.filter(
            Q(book_name__icontains=keyword) |
            Q(author__icontains=keyword) |
            Q(isbn__icontains=keyword) |
            Q(book_type__icontains=keyword) |
            Q(publisher__icontains=keyword)
        )

    # 与 book_list 保持一致的权限逻辑
    if request.user.is_authenticated:
        if request.user.is_superuser:
            records = BorrowRecord.objects.all().order_by("-borrow_date")
        else:
            profile = UserProfile.objects.filter(user=request.user).first()
            borrower_name = profile.reader.reader_name if profile and profile.reader else request.user.username
            records = BorrowRecord.objects.filter(
                Q(borrower=request.user) | Q(borrower_name=borrower_name)
            ).order_by("-borrow_date")
    else:
        records = BorrowRecord.objects.none()

    return render(request, "list.html", {
        "books": books,
        "keyword": keyword,
        "user_role": get_current_user_role(request),
        "can_add": get_current_user_can('add', request),
        "can_edit": get_current_user_can('edit', request),
        "can_delete": get_current_user_can('delete', request),
        "can_borrow": get_current_user_can('borrow', request),
        "can_return": get_current_user_can('return', request),
        "records": records,
    })

# 借/还图书
@login_required
def borrow_return(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    # 获取所有已注册用户
    users = User.objects.all().order_by('username')
    # 获取所有书架位置
    shelf_locations = ShelfLocation.objects.all()

    if request.method == "POST":
        # 先检查是否存在未归还记录（防止并发借阅）
        existing_unreturned = BorrowRecord.objects.filter(book=book, is_returned=False).first()
        if existing_unreturned and book.status == "在架":
            # 数据不一致，修复书籍状态
            book.status = "借出"
            book.save()
            messages.error(request, f"该书已被 {existing_unreturned.borrower_name} 借阅，无法重复借阅！")
            return redirect("book_list")

        if book.status == "在架" and not existing_unreturned:
            # 借阅逻辑
            borrower = None
            borrower_name = None

            # 权限控制：管理员可以选择借阅人，普通成员只能自己借阅
            if request.user.is_superuser:
                # 管理员可以选择借阅人
                borrow_type = request.POST.get("borrow_type", "select")
                user_id = request.POST.get("user_id")
                manual_name = request.POST.get("manual_name", "").strip()

                if borrow_type == "select" and user_id:
                    borrower = get_object_or_404(User, id=user_id)
                    profile = UserProfile.objects.filter(user=borrower).first()
                    if profile and profile.reader:
                        borrower_name = profile.reader.reader_name
                    else:
                        reader, _ = Reader.objects.get_or_create(reader_name=borrower.username)
                        if not profile:
                            profile = UserProfile.objects.create(user=borrower, reader=reader)
                        else:
                            profile.reader = reader
                            profile.save()
                        borrower_name = reader.reader_name
                elif borrow_type == "manual" and manual_name:
                    borrower_name = manual_name
                else:
                    messages.error(request, "请选择借阅人或输入借阅人姓名！")
                    return render(request, "borrow.html", {
                        "book": book, "users": users, "shelf_locations": shelf_locations,
                        "is_superuser": request.user.is_superuser
                    })
            else:
                # 普通成员只能自己借阅
                borrower = request.user
                profile = UserProfile.objects.filter(user=request.user).first()
                if profile and profile.reader:
                    borrower_name = profile.reader.reader_name
                else:
                    borrower_name = request.user.username

            BorrowRecord.objects.create(
                book=book,
                borrower=borrower,
                borrower_name=borrower_name,
                borrow_date=timezone.now()
            )

            book.status = "借出"
            book.save()
            # 记录操作日志
            create_operation_log(request, 'borrow', 'book', book.id, book.book_name, f'借阅人：{borrower_name}')
            messages.success(request, f"书籍借阅成功！借阅人：{borrower_name}")
        else:
            # 归还逻辑
            current_record = BorrowRecord.objects.filter(book=book, is_returned=False).first()
            if not current_record:
                messages.warning(request, "未找到该书籍的未归还记录！")
                return redirect("book_list")

            # 权限检查：只有借阅人本人或管理员可以归还
            can_return = False
            if request.user.is_superuser:
                can_return = True
            elif current_record.borrower == request.user:
                can_return = True
            elif current_record.borrower_name:
                profile = UserProfile.objects.filter(user=request.user).first()
                user_display_name = profile.reader.reader_name if profile and profile.reader else request.user.username
                if user_display_name == current_record.borrower_name:
                    can_return = True

            if not can_return:
                messages.error(request, f"您无权归还此书籍，只有借阅人({current_record.borrower_name})本人或管理员可以归还！")
                return redirect("book_list")

            # 获取归还位置
            return_place = request.POST.get("return_place", "").strip()
            if not return_place:
                messages.error(request, "请选择归还位置！")
                return render(request, "borrow.html", {
                    "book": book, "users": users, "shelf_locations": shelf_locations,
                    "current_borrower": current_record.get_borrower_display_name(),
                    "is_superuser": request.user.is_superuser
                })

            # 执行归还
            book.status = "在架"
            book.place = return_place  # 更新书籍位置
            book.save()
            current_record.return_date = timezone.now()
            current_record.is_returned = True
            current_record.save()
            # 记录操作日志
            create_operation_log(request, 'return', 'book', book.id, book.book_name, f'归还位置：{return_place}')
            messages.success(request, f"书籍归还成功！已放回「{return_place}」")

        return redirect("book_list")

    # GET请求 - 显示借阅/归还页面
    current_borrower = None
    if book.status == "借出":
        current_record = BorrowRecord.objects.filter(book=book, return_date__isnull=True).first()
        if current_record:
            current_borrower = current_record.get_borrower_display_name()

    return render(request, "borrow.html", {
        "book": book,
        "users": users,
        "shelf_locations": shelf_locations,
        "current_borrower": current_borrower,
        "is_superuser": request.user.is_superuser
    })

# 借阅记录列表
@login_required
def borrow_list(request):
    # 分页设置
    page = int(request.GET.get('page', 1))
    page_size = 30

    # 获取筛选参数
    search_book = request.GET.get('search_book', '').strip()
    search_borrower = request.GET.get('search_borrower', '').strip()
    search_author = request.GET.get('search_author', '').strip()

    # 超级管理员看所有记录，普通成员只看自己的借阅记录
    if request.user.is_superuser:
        records = BorrowRecord.objects.select_related('book', 'borrower').all().order_by("-borrow_date")
    else:
        profile = UserProfile.objects.filter(user=request.user).first()
        borrower_name = profile.reader.reader_name if profile and profile.reader else request.user.username
        records = BorrowRecord.objects.select_related('book', 'borrower').filter(
            Q(borrower=request.user) | Q(borrower_name=borrower_name)
        ).order_by("-borrow_date")

    # 应用筛选条件
    if search_book:
        records = records.filter(book__book_name__icontains=search_book)
    if search_borrower:
        records = records.filter(borrower_name__icontains=search_borrower)
    if search_author:
        records = records.filter(book__author__icontains=search_author)

    # 分页
    total_records = records.count()
    total_pages = (total_records + page_size - 1) // page_size
    records = records[(page-1)*page_size:page*page_size]

    books = Book.objects.all()
    return render(request, "records.html", {
        "records": records,
        "user_role": get_current_user_role(request),
        "books": books,
        "can_add": get_current_user_can('add', request),
        "can_edit": get_current_user_can('edit', request),
        "can_delete": get_current_user_can('delete', request),
        "can_borrow": get_current_user_can('borrow', request),
        "can_return": get_current_user_can('return', request),
        "current_page": page,
        "total_pages": total_pages,
        "total_records": total_records,
        "has_next": page < total_pages,
        "has_prev": page > 1,
        "search_book": search_book,
        "search_borrower": search_borrower,
        "search_author": search_author,
    })


# 删除图书
@login_required
def book_delete(request, book_id):
    if not check_permission(request, 'delete'):
        messages.error(request, '您没有删除权限')
        return redirect('book_list')
    book = get_object_or_404(Book, id=book_id)
    book_name = book.book_name
    # 记录操作日志
    create_operation_log(request, 'delete_book', 'book', book_id, book_name)
    book.delete()
    messages.success(request, f'《{book_name}》已删除')
    return redirect("book_list")


# 编辑图书
@login_required
def book_edit(request, book_id):
    if not request.user.is_superuser:
        messages.error(request, '只有管理员可以编辑书籍')
        return redirect('book_list')
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        name = request.POST.get("book_name", "").strip()
        author = request.POST.get("author", "").strip()
        isbn = request.POST.get("isbn", "").strip() or None
        book_type = request.POST.get("book_type", "其他")
        place = request.POST.get("place", "未填写").strip()
        cover = request.FILES.get("cover")
        description = request.POST.get("description", "").strip()
        publisher = request.POST.get("publisher", "").strip() or None
        publish_date = request.POST.get("publish_date", "").strip() or None

        if not name or not author:
            messages.error(request, '请填写书名和作者')
            return render(request, "edit.html", {"book": book})

        book.book_name = name
        book.author = author
        book.isbn = isbn
        book.book_type = book_type
        book.place = place
        book.description = description
        book.publisher = publisher
        if publish_date:
            try:
                from datetime import datetime
                book.publish_date = datetime.strptime(publish_date, '%Y-%m-%d').date()
            except:
                book.publish_date = None
        else:
            book.publish_date = None
        if cover:
            book.cover = cover
        book.save()
        # 记录操作日志
        create_operation_log(request, 'edit_book', 'book', book.id, name)
        messages.success(request, f'《{name}》修改成功！')
        return redirect("book_list")
    return render(request, "edit.html", {"book": book})



# 家庭成员列表
@login_required
def family_list(request):
    if not request.user.is_superuser:
        messages.error(request, '只有超级管理员可以管理家庭成员')
        return redirect('book_list')
    members = Reader.objects.all()
    return render(request, "family_list.html", {"members": members})

# 添加家庭成员
@login_required
def family_add(request):
    if not request.user.is_superuser:
        messages.error(request, '只有超级管理员可以添加家庭成员')
        return redirect('family_list')
    if request.method == "POST":
        name = request.POST.get("reader_name")
        Reader.objects.create(reader_name=name)
        return redirect("family_list")
    return render(request, "family_add.html")

# 删除家庭成员
@login_required
def family_delete(request, member_id):
    if not request.user.is_superuser:
        messages.error(request, '只有超级管理员可以删除家庭成员')
        return redirect('family_list')
    member = get_object_or_404(Reader, id=member_id)
    member.delete()
    messages.success(request, f'已删除成员：{member.reader_name}')
    return redirect("family_list")

# 删除借阅记录
@login_required
def borrow_record_delete(request, record_id):
    if not request.user.is_superuser:
        messages.error(request, '只有超级管理员可以删除借阅记录')
        return redirect('book_list')
    record = get_object_or_404(BorrowRecord, id=record_id)
    record.delete()
    messages.success(request, '借阅记录已删除')
    return redirect('book_list')

# API: 更新书籍信息（用于拖拽归类）
@csrf_exempt
@require_http_methods(["PATCH", "POST"])
def api_update_book(request, book_id):
    # 手动检查登录状态，返回 JSON 错误而非重定向
    if not request.user.is_authenticated:
        return JsonResponse({'success': False, 'error': '请先登录'}, status=401)

    try:
        book = Book.objects.get(id=book_id)
        data = json.loads(request.body)
        if 'book_type' in data:
            book.book_type = data['book_type']
        if 'place' in data:
            book.place = data['place']
        book.save()
        return JsonResponse({'success': True, 'message': '更新成功'})
    except Book.DoesNotExist:
        return JsonResponse({'success': False, 'error': '书籍不存在'}, status=404)
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'error': '请求数据格式错误'}, status=400)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


# API: 获取已注册用户列表（仅超级管理员可访问）
@login_required
def api_users_list(request):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权限访问'}, status=403)
    users = User.objects.all().order_by('username')
    users_data = []
    for u in users:
        profile = UserProfile.objects.filter(user=u).first()
        users_data.append({
            'id': u.id,
            'username': u.username,
            'is_superuser': u.is_superuser,
            'role': profile.role if profile else 'member',
            'reader_name': profile.reader.reader_name if profile and profile.reader else '',
            'phone': profile.phone if profile else '',
            'avatar': profile.avatar.url if profile and profile.avatar else ''
        })
    return JsonResponse({'success': True, 'users': users_data})


# API: 通过ISBN查询书籍信息
def api_book_by_isbn(request, isbn):
    # 清理ISBN格式
    clean_isbn = isbn.replace('-', '').replace(' ', '')

    # 验证ISBN格式（10位或13位数字）
    if not clean_isbn.isdigit() or len(clean_isbn) not in [10, 13]:
        return JsonResponse({
            'success': False,
            'error': f'ISBN格式错误: {clean_isbn}（需要10位或13位数字）'
        })

    print(f'[ISBN查询] 收到查询请求: {clean_isbn}')

    # 先查本地数据库
    book = Book.objects.filter(isbn=clean_isbn).first()
    if book:
        print(f'[ISBN查询] 本地数据库找到: {book.book_name}')
        return JsonResponse({
            'success': True,
            'source': 'local',
            'book': {
                'book_name': book.book_name,
                'author': book.author,
                'isbn': book.isbn,
                'cover': book.cover.url if book.cover else '',
                'book_type': book.book_type,
                'place': book.place,
                'publisher': book.publisher or '',
                'publish_date': book.publish_date.strftime('%Y-%m-%d') if book.publish_date else '',
                'description': book.description or '',
            }
        })

    # 查询在线书库
    print(f'[ISBN查询] 本地无此书，查询在线书库...')
    return query_online_book_info(clean_isbn)


# API: 通过书名搜索书籍
def api_book_search(request):
    query = request.GET.get('q', '')
    if not query:
        return JsonResponse({'success': False, 'error': '请输入搜索关键词'})

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }

    try:
        url = f'https://book.douban.com/j/subject_suggest?q={query}'
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            books = []
            for item in data[:5]:  # 最多返回5个结果
                books.append({
                    'book_name': item.get('title', ''),
                    'author': item.get('author_name', ''),
                    'cover': item.get('pic', ''),
                    'publisher': item.get('publisher', ''),
                    'year': item.get('year', ''),
                    'id': item.get('id', ''),
                })
            return JsonResponse({'success': True, 'books': books})
    except (ConnectionError, Timeout):
        return JsonResponse({
            'success': False,
            'error': '当前网络无法连接图书数据库，请手动录入书籍信息',
            'network_error': True
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': f'搜索出错: {str(e)}'})

    return JsonResponse({'success': False, 'error': '搜索失败'})


# 在线查询书籍信息（豆瓣API）
def query_online_book_info(isbn):
    import time
    start_time = time.time()

    # 豆瓣API配置
    DOUBAN_API_KEY = "0ab215a8b1977939201640fa14c66bab"
    DOUBAN_API_URL = "https://api.douban.com/v2/book/isbn/"

    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    # 1. 查询豆瓣API
    try:
        print(f'[查询] 开始查询豆瓣API: {isbn}')
        url = DOUBAN_API_URL + isbn
        data = {"apikey": DOUBAN_API_KEY}

        response = requests.post(url, data=data, headers=headers, timeout=10)
        elapsed = time.time() - start_time
        print(f'[查询] 豆瓣API响应: {response.status_code}, 耗时: {elapsed:.2f}s')

        if response.status_code == 200:
            # 处理编码问题
            response.encoding = 'utf-8'
            result = response.json()
            print(f'[查询] 豆瓣API返回: {result.get("title", "无标题")}')

            # 解析豆瓣返回的数据
            authors = result.get('author', [])
            if isinstance(authors, list):
                author_str = '/'.join(authors)
            else:
                author_str = str(authors)

            # 获取封面图片
            images = result.get('images', {})
            cover = images.get('large', '') or images.get('medium', '') or result.get('image', '')

            # 获取分类标签
            tags = result.get('tags', [])
            book_type = tags[0].get('name', '') if tags else ''

            book_info = {
                'book_name': result.get('title', ''),
                'author': author_str,
                'isbn': isbn,
                'cover': cover,
                'publisher': result.get('publisher', ''),
                'publish_date': result.get('pubdate', ''),
                'book_type': book_type,
                'description': result.get('summary', ''),
                'pages': result.get('pages', ''),
                'price': result.get('price', ''),
                'rating': result.get('rating', {}).get('average', ''),
            }

            return JsonResponse({
                'success': True,
                'source': 'douban',
                'book': book_info
            })
        elif response.status_code == 404:
            print(f'[查询] 豆瓣API未找到ISBN: {isbn}')
        else:
            print(f'[查询] 豆瓣API返回错误: {response.status_code}')
            try:
                error_data = response.json()
                print(f'[查询] 错误详情: {error_data}')
            except:
                pass

    except requests.Timeout:
        print(f'[查询] 豆瓣API超时 (10秒)')
    except requests.ConnectionError as e:
        print(f'[查询] 豆瓣API连接错误: {e}')
    except Exception as e:
        print(f'[查询] 豆瓣API失败: {type(e).__name__}: {e}')

    # 2. 豆瓣失败，尝试Open Library作为备用
    try:
        print(f'[查询] 尝试Open Library备用查询: {isbn}')
        start_time2 = time.time()
        url = f'https://openlibrary.org/api/books?bibkeys=ISBN:{isbn}&format=json&jscmd=data'
        headers_ol = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers_ol, timeout=5)
        elapsed = time.time() - start_time2
        print(f'[查询] Open Library响应: {response.status_code}, 耗时: {elapsed:.2f}s')

        if response.status_code == 200:
            data = response.json()
            key = f'ISBN:{isbn}'
            if key in data:
                book_info = data[key]
                authors = ', '.join([a.get('name', '') for a in book_info.get('authors', [])])
                publishers = book_info.get('publishers', [])
                publisher_names = ', '.join([p.get('name', '') for p in publishers])
                print(f'[查询] Open Library找到: {book_info.get("title")}')

                return JsonResponse({
                    'success': True,
                    'source': 'openlibrary',
                    'book': {
                        'book_name': book_info.get('title', ''),
                        'author': authors,
                        'isbn': isbn,
                        'cover': book_info.get('cover', {}).get('medium', '') if book_info.get('cover') else '',
                        'publisher': publisher_names,
                        'publish_date': book_info.get('publish_date', ''),
                    }
                })
    except Exception as e:
        print(f'[查询] Open Library失败: {e}')

    total_time = time.time() - start_time
    print(f'[查询] 未找到书籍: {isbn}, 总耗时: {total_time:.2f}s')
    return JsonResponse({
        'success': False,
        'error': '未找到书籍，请手动录入或尝试书名搜索',
        'isbn': isbn
    })


# ========== 书架位置管理API ==========

# 获取所有书架位置
@login_required
def api_shelf_locations(request):
    locations = ShelfLocation.objects.all()
    # 统计每个位置的书籍数量
    data = []
    for loc in locations:
        book_count = Book.objects.filter(place__contains=loc.name).count()
        data.append({
            'id': loc.id,
            'name': loc.name,
            'description': loc.description,
            'book_count': book_count
        })
    return JsonResponse({'success': True, 'locations': data})


# 添加书架位置
@login_required
@require_http_methods(["POST"])
def api_shelf_location_add(request):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以添加'}, status=403)
    data = json.loads(request.body)
    name = data.get('name', '').strip()
    description = data.get('description', '')
    if not name:
        return JsonResponse({'success': False, 'error': '请输入位置名称'})
    if ShelfLocation.objects.filter(name=name).exists():
        return JsonResponse({'success': False, 'error': '该位置已存在'})
    loc = ShelfLocation.objects.create(name=name, description=description)
    return JsonResponse({'success': True, 'location': {'id': loc.id, 'name': loc.name, 'description': loc.description}})


# 编辑书架位置
@login_required
@require_http_methods(["POST"])
def api_shelf_location_edit(request, loc_id):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以编辑'}, status=403)
    data = json.loads(request.body)
    loc = get_object_or_404(ShelfLocation, id=loc_id)
    name = data.get('name', '').strip()
    if not name:
        return JsonResponse({'success': False, 'error': '请输入位置名称'})
    # 检查名称是否重复（排除自己）
    if ShelfLocation.objects.filter(name=name).exclude(id=loc_id).exists():
        return JsonResponse({'success': False, 'error': '该位置名称已存在'})
    loc.name = name
    loc.description = data.get('description', '')
    loc.save()
    return JsonResponse({'success': True})


# 删除书架位置
@login_required
@require_http_methods(["POST"])
def api_shelf_location_delete(request, loc_id):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以删除'}, status=403)
    loc = get_object_or_404(ShelfLocation, id=loc_id)
    loc.delete()
    return JsonResponse({'success': True})


# ========== 借阅统计API ==========

@login_required
@require_http_methods(["POST"])
def api_fix_borrower_names(request):
    """修复借阅记录中缺失的借阅人姓名"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以执行此操作'}, status=403)

    fixed_count = 0
    records = BorrowRecord.objects.filter(borrower_name__isnull=True) | BorrowRecord.objects.filter(borrower_name='')

    for record in records:
        if record.borrower:
            profile = UserProfile.objects.filter(user=record.borrower).first()
            if profile and profile.reader:
                record.borrower_name = profile.reader.reader_name
            else:
                record.borrower_name = record.borrower.username
            record.save()
            fixed_count += 1

    return JsonResponse({'success': True, 'fixed_count': fixed_count})


@login_required
def api_borrow_statistics(request):
    """借阅统计数据"""
    from django.db.models.functions import TruncMonth, TruncWeek

    # 时间范围
    now = timezone.now()
    year_start = now.replace(month=1, day=1, hour=0, minute=0, second=0)

    # 1. 人员借阅统计 - 统计所有借阅记录
    borrower_stats = BorrowRecord.objects.filter(
        borrower_name__isnull=False
    ).exclude(
        borrower_name=''
    ).values('borrower_name').annotate(
        count=Count('id')
    ).order_by('-count')[:10]

    # 2. 月度借阅趋势（本年度）- 统计所有借阅记录
    monthly_stats = BorrowRecord.objects.filter(
        borrow_date__year=now.year
    ).annotate(month=TruncMonth('borrow_date')).values('month').annotate(
        count=Count('id')
    ).order_by('month')

    # 3. 书籍借阅排行 - 统计所有借阅记录
    book_stats = BorrowRecord.objects.values('book__book_name').annotate(
        count=Count('id')
    ).order_by('-count')[:10]

    # 4. 未归还书籍
    unreturned_books = BorrowRecord.objects.filter(
        is_returned=False
    ).select_related('book').order_by('-borrow_date')[:20]

    unreturned_data = [{
        'book_name': r.book.book_name,
        'borrower': r.get_borrower_display_name(),
        'borrow_date': r.borrow_date.strftime('%Y-%m-%d')
    } for r in unreturned_books]

    # 5. 藏书统计
    total_books = Book.objects.count()
    borrowed_books = Book.objects.filter(status='借出').count()
    available_books = total_books - borrowed_books

    # 按分类统计
    category_stats = Book.objects.values('book_type').annotate(
        count=Count('id')
    ).order_by('-count')

    # 6. 周借阅统计
    week_ago = now - timezone.timedelta(days=7)
    weekly_borrows = BorrowRecord.objects.filter(
        borrow_date__gte=week_ago
    ).count()

    weekly_returns = BorrowRecord.objects.filter(
        return_date__gte=week_ago
    ).count()

    # 7. 用户数量统计
    from django.contrib.auth.models import User
    user_count = User.objects.count()

    return JsonResponse({
        'success': True,
        'data': {
            'borrower_stats': list(borrower_stats),
            'monthly_stats': list(monthly_stats),
            'book_stats': list(book_stats),
            'unreturned_books': unreturned_data,
            'collection_stats': {
                'total': total_books,
                'borrowed': borrowed_books,
                'available': available_books,
                'by_category': list(category_stats)
            },
            'weekly_stats': {
                'borrows': weekly_borrows,
                'returns': weekly_returns
            },
            'user_count': user_count
        }
    })


# API: 按日期范围统计借阅数据（用于图表）
@login_required
def api_borrow_chart_data(request):
    """获取借阅图表数据"""
    from django.db.models.functions import TruncDate

    # 获取日期范围参数
    start_date = request.GET.get('start_date', '')
    end_date = request.GET.get('end_date', '')

    # 默认查询最近30天
    now = timezone.now()
    if not start_date:
        start_date = (now - timezone.timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = now.strftime('%Y-%m-%d')

    # 转换日期
    try:
        start = timezone.datetime.strptime(start_date, '%Y-%m-%d')
        end = timezone.datetime.strptime(end_date, '%Y-%m-%d') + timezone.timedelta(days=1)  # 包含结束日期
    except ValueError:
        return JsonResponse({'success': False, 'error': '日期格式错误'})

    # 按日期分组统计借阅数量
    borrow_records = BorrowRecord.objects.filter(
        borrow_date__date__gte=start.date(),
        borrow_date__date__lt=end.date()
    ).annotate(
        date=TruncDate('borrow_date')
    ).values('date').annotate(
        count=Count('id')
    ).order_by('date')

    # 按日期分组统计归还数量
    return_records = BorrowRecord.objects.filter(
        return_date__isnull=False,
        return_date__date__gte=start.date(),
        return_date__date__lt=end.date()
    ).annotate(
        date=TruncDate('return_date')
    ).values('date').annotate(
        count=Count('id')
    ).order_by('date')

    # 生成日期范围内所有日期
    date_range = []
    current = start.date()
    while current < end.date():
        date_range.append(current)
        current += timezone.timedelta(days=1)

    # 构建数据
    borrow_dict = {r['date']: r['count'] for r in borrow_records}
    return_dict = {r['date']: r['count'] for r in return_records}

    labels = []
    borrow_counts = []
    return_counts = []
    rates = []

    total_borrowed = 0
    total_returned = 0

    for date in date_range:
        labels.append(date.strftime('%m-%d'))
        borrow_count = borrow_dict.get(date, 0)
        return_count = return_dict.get(date, 0)
        borrow_counts.append(borrow_count)
        return_counts.append(return_count)

        total_borrowed += borrow_count
        total_returned += return_count

        # 计算累计归还率
        if total_borrowed > 0:
            rates.append(round(total_returned / total_borrowed * 100, 1))
        else:
            rates.append(0)

    # 计算在架率
    total_books = Book.objects.count()
    borrowed_books = Book.objects.filter(status='借出').count()
    available_rate = round((total_books - borrowed_books) / total_books * 100, 1) if total_books > 0 else 100

    return JsonResponse({
        'success': True,
        'data': {
            'labels': labels,
            'borrow_counts': borrow_counts,
            'return_counts': return_counts,
            'return_rates': rates,
            'available_rate': available_rate,
            'summary': {
                'total_borrowed': sum(borrow_counts),
                'total_returned': sum(return_counts),
                'total_books': total_books,
                'borrowed_books': borrowed_books
            }
        }
    })


# ========== 借阅提醒功能 ==========

@login_required
def api_borrow_reminders(request):
    """获取借阅提醒列表"""
    now = timezone.now()

    # 超过30天未归还的书籍
    thirty_days_ago = now - timezone.timedelta(days=30)
    overdue_records = BorrowRecord.objects.filter(
        is_returned=False,
        borrow_date__lt=thirty_days_ago
    ).select_related('book').order_by('borrow_date')

    # 超过14天未归还的书籍（提醒）
    fourteen_days_ago = now - timezone.timedelta(days=14)
    reminder_records = BorrowRecord.objects.filter(
        is_returned=False,
        borrow_date__lt=fourteen_days_ago,
        borrow_date__gte=thirty_days_ago
    ).select_related('book').order_by('borrow_date')

    data = {
        'overdue': [{
            'id': r.id,
            'book_name': r.book.book_name,
            'borrower': r.get_borrower_display_name(),
            'borrow_date': r.borrow_date.strftime('%Y-%m-%d'),
            'days': (now.date() - r.borrow_date.date()).days
        } for r in overdue_records],
        'reminder': [{
            'id': r.id,
            'book_name': r.book.book_name,
            'borrower': r.get_borrower_display_name(),
            'borrow_date': r.borrow_date.strftime('%Y-%m-%d'),
            'days': (now.date() - r.borrow_date.date()).days
        } for r in reminder_records]
    }

    return JsonResponse({'success': True, 'data': data})


# ========== 导入导出书单功能 ==========

@login_required
def api_export_books(request):
    """导出书单为CSV"""
    import csv
    from django.http import HttpResponse

    books = Book.objects.all()

    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition'] = 'attachment; filename="books_export.csv"'

    writer = csv.writer(response)
    writer.writerow(['书名', '作者', 'ISBN', '分类', '状态', '存放位置', '出版社', '出版日期', '简介'])

    for book in books:
        writer.writerow([
            book.book_name,
            book.author,
            book.isbn or '',
            book.book_type,
            book.status,
            book.place or '',
            book.publisher or '',
            book.publish_date.strftime('%Y-%m-%d') if book.publish_date else '',
            book.description or ''
        ])

    return response


@login_required
@require_http_methods(["POST"])
def api_import_books(request):
    """
    批量导入书单（支持 Excel 和 CSV 格式）

    Excel/CSV 文件列说明：
    - 书名（必填）
    - 作者（必填）
    - ISBN
    - 分类
    - 出版社
    - 出版日期（格式：YYYY-MM-DD）
    - 存放位置
    - 简介

    注意：ISBN重复或书名+作者重复的记录会被跳过
    """
    import csv
    from datetime import datetime

    uploaded_file = request.FILES.get('file')
    if not uploaded_file:
        return JsonResponse({'success': False, 'error': '请选择要上传的文件'})

    # 检查文件格式
    filename = uploaded_file.name.lower()
    is_excel = filename.endswith(('.xlsx', '.xls'))
    is_csv = filename.endswith('.csv')

    if not (is_excel or is_csv):
        return JsonResponse({
            'success': False,
            'error': '不支持的文件格式，请上传 .xlsx、.xls 或 .csv 文件'
        })

    # 结果统计
    added = 0
    skipped = 0
    errors = []
    error_details = []

    try:
        # ========== 读取 Excel 文件 ==========
        if is_excel:
            try:
                import pandas as pd
            except ImportError:
                return JsonResponse({
                    'success': False,
                    'error': '服务器未安装 pandas 库，无法处理 Excel 文件。请联系管理员安装：pip install pandas openpyxl'
                })

            try:
                df = pd.read_excel(uploaded_file, dtype=str)  # 全部作为字符串读取
                df = df.fillna('')  # 填充空值
                rows = df.to_dict('records')
            except Exception as e:
                return JsonResponse({'success': False, 'error': f'读取Excel文件失败：{str(e)}'})

        # ========== 读取 CSV 文件 ==========
        else:
            try:
                decoded_file = uploaded_file.read().decode('utf-8-sig')
            except UnicodeDecodeError:
                # 尝试 GBK 编码
                try:
                    uploaded_file.seek(0)
                    decoded_file = uploaded_file.read().decode('gbk')
                except:
                    return JsonResponse({'success': False, 'error': '文件编码不支持，请使用 UTF-8 或 GBK 编码的 CSV 文件'})

            reader = csv.DictReader(decoded_file.splitlines())
            rows = list(reader)

        # ========== 批量处理数据 ==========
        for idx, row in enumerate(rows, start=2 if is_excel else 1):  # Excel从第2行开始
            try:
                # 获取字段（支持中文和英文列名）
                book_name = row.get('书名') or row.get('book_name') or row.get('title') or ''
                author = row.get('作者') or row.get('author') or ''

                book_name = str(book_name).strip()
                author = str(author).strip()

                # 必填字段检查
                if not book_name:
                    error_details.append(f'第{idx}行：缺少书名')
                    errors.append(idx)
                    continue
                if not author:
                    error_details.append(f'第{idx}行：缺少作者')
                    errors.append(idx)
                    continue

                # 获取可选字段
                isbn = str(row.get('ISBN') or row.get('isbn') or '').strip()
                book_type = str(row.get('分类') or row.get('category') or row.get('book_type') or '其他').strip()
                publisher = str(row.get('出版社') or row.get('publisher') or '').strip()
                publish_date_str = str(row.get('出版日期') or row.get('publish_date') or '').strip()
                place = str(row.get('存放位置') or row.get('place') or row.get('location') or '').strip()
                description = str(row.get('简介') or row.get('description') or '').strip()

                # 解析出版日期
                publish_date = None
                if publish_date_str:
                    for fmt in ['%Y-%m-%d', '%Y/%m/%d', '%Y年%m月%d日', '%Y.%m.%d']:
                        try:
                            publish_date = datetime.strptime(publish_date_str, fmt).date()
                            break
                        except ValueError:
                            continue

                # 检查重复
                if isbn:
                    if Book.objects.filter(isbn=isbn).exists():
                        skipped += 1
                        continue
                else:
                    if Book.objects.filter(book_name=book_name, author=author).exists():
                        skipped += 1
                        continue

                # 创建书籍
                Book.objects.create(
                    book_name=book_name,
                    author=author,
                    isbn=isbn or None,
                    book_type=book_type,
                    status='在架',
                    place=place,
                    publisher=publisher,
                    publish_date=publish_date,
                    description=description
                )
                added += 1

            except Exception as e:
                error_details.append(f'第{idx}行：{str(e)}')
                errors.append(idx)

        # 构建返回消息
        message_parts = [f'成功导入 {added} 本']
        if skipped > 0:
            message_parts.append(f'跳过重复 {skipped} 本')
        if errors:
            message_parts.append(f'失败 {len(errors)} 行')

        result = {
            'success': True,
            'message': '，'.join(message_parts),
            'imported': added,
            'skipped': skipped,
            'failed': len(errors)
        }

        if error_details:
            result['errors'] = error_details[:10]  # 最多返回10条错误

        return JsonResponse(result)

    except Exception as e:
        return JsonResponse({'success': False, 'error': f'导入失败：{str(e)}'})


@login_required
@require_http_methods(["GET"])
def api_download_template(request):
    """下载批量导入模板文件"""
    from django.http import HttpResponse
    import csv
    from io import StringIO

    # 创建CSV内容
    output = StringIO()
    writer = csv.writer(output)

    # 写入表头
    writer.writerow(['书名', '作者', 'ISBN', '分类', '出版社', '出版日期', '存放位置', '简介'])

    # 写入示例数据
    writer.writerow(['活着', '余华', '9787544270878', '文学', '作家出版社', '2014-05-01', 'A区1号书架', '讲述一个人一生的故事'])
    writer.writerow(['三体', '刘慈欣', '9787536692930', '科幻', '重庆出版社', '2008-01-01', 'A区2号书架', '中国科幻文学的里程碑之作'])
    writer.writerow(['小王子', '[法]圣埃克苏佩里', '9787020042494', '童话', '人民文学出版社', '2003-08-01', 'B区1号书架', '献给长大的孩子们'])

    # 构建响应
    output.seek(0)
    response = HttpResponse(output.read(), content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition'] = 'attachment; filename="book_import_template.csv"'

    return response


# ========== 书籍评论API ==========

# 获取书籍评论列表
@login_required
def api_book_comments(request, book_id):
    comments = BookComment.objects.filter(book_id=book_id).select_related('user').order_by('-created_at')
    data = []
    for c in comments:
        # 获取用户显示名称
        profile = UserProfile.objects.filter(user=c.user).first()
        display_name = profile.reader.reader_name if profile and profile.reader else c.user.username
        # 获取点赞信息
        like_count = c.likes.count()
        liked = BookCommentLike.objects.filter(comment=c, user=request.user).exists()
        data.append({
            'id': c.id,
            'user': display_name,
            'content': c.content,
            'created_at': c.created_at.strftime('%Y-%m-%d %H:%M'),
            'like_count': like_count,
            'liked': liked,
            'can_delete': c.user == request.user or request.user.is_superuser
        })
    return JsonResponse({'success': True, 'comments': data})


# 添加书籍评论
@login_required
@require_http_methods(["POST"])
def api_book_comment_add(request, book_id):
    data = json.loads(request.body)
    content = data.get('content', '').strip()
    if not content:
        return JsonResponse({'success': False, 'error': '评论内容不能为空'})

    book = get_object_or_404(Book, id=book_id)
    comment = BookComment.objects.create(
        book=book,
        user=request.user,
        content=content
    )
    return JsonResponse({
        'success': True,
        'comment': {
            'id': comment.id,
            'user': comment.user.username,
            'content': comment.content,
            'created_at': comment.created_at.strftime('%Y-%m-%d %H:%M')
        }
    })


# 删除书籍评论
@login_required
@require_http_methods(["POST"])
def api_book_comment_delete(request, comment_id):
    comment = get_object_or_404(BookComment, id=comment_id)
    if comment.user != request.user and not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权删除'}, status=403)
    comment.delete()
    return JsonResponse({'success': True})


# ========== 书摘书评API ==========

# 获取书摘书评列表
@login_required
def api_book_notes(request):
    book_id = request.GET.get('book_id')
    note_type = request.GET.get('note_type', 'all')

    notes = BookNote.objects.all()

    # 书摘(excerpt)只有作者自己可见，书评(review)所有人可见
    if note_type == 'excerpt':
        # 只获取当前用户的书摘
        notes = notes.filter(user=request.user, note_type='excerpt')
    elif note_type == 'review':
        # 书评所有人可见
        notes = notes.filter(note_type='review')
    else:
        # 获取当前用户的书摘 + 所有人的书评
        notes = notes.filter(
            Q(note_type='review') | Q(note_type='excerpt', user=request.user)
        )

    if book_id:
        notes = notes.filter(book_id=book_id)
    notes = notes.select_related('book', 'user').order_by('-created_at')
    data = []
    for n in notes:
        # 获取用户显示名称
        profile = UserProfile.objects.filter(user=n.user).first()
        display_name = profile.reader.reader_name if profile and profile.reader else n.user.username
        data.append({
            'id': n.id,
            'book_id': n.book_id,
            'book_name': n.book.book_name,
            'user': display_name,
            'note_type': n.note_type,
            'note_type_display': n.get_note_type_display(),
            'title': n.title,
            'content': n.content,
            'page_number': n.page_number,
            'created_at': n.created_at.strftime('%Y-%m-%d %H:%M'),
            'is_owner': n.user == request.user
        })
    return JsonResponse({'success': True, 'notes': data})


# 添加书摘书评
@login_required
@require_http_methods(["POST"])
def api_book_note_add(request):
    data = json.loads(request.body)
    book_id = data.get('book_id')
    note_type = data.get('note_type', 'excerpt')
    title = data.get('title', '').strip()
    content = data.get('content', '').strip()
    page_number = data.get('page_number')

    if not book_id or not title or not content:
        return JsonResponse({'success': False, 'error': '请填写完整信息'})

    book = get_object_or_404(Book, id=book_id)
    note = BookNote.objects.create(
        book=book,
        user=request.user,
        note_type=note_type,
        title=title,
        content=content,
        page_number=page_number
    )
    return JsonResponse({'success': True, 'note_id': note.id})


# 删除书摘书评
@login_required
@require_http_methods(["POST"])
def api_book_note_delete(request, note_id):
    note = get_object_or_404(BookNote, id=note_id)
    if note.user != request.user and not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '无权删除'}, status=403)
    note.delete()
    return JsonResponse({'success': True})


# ========== 书籍借阅信息API ==========

# 获取书籍当前借阅信息
def api_book_borrow_info(request, book_id):
    """获取书籍当前的借阅信息"""
    book = get_object_or_404(Book, id=book_id)
    data = {
        'book_id': book_id,
        'status': book.status,
        'is_borrowed': book.status == '借出'
    }

    if book.status == '借出':
        # 获取当前未归还的借阅记录
        record = BorrowRecord.objects.filter(book=book, return_date__isnull=True).first()
        if record:
            data['borrower'] = record.get_borrower_display_name()
            data['borrow_date'] = record.borrow_date.strftime('%Y-%m-%d %H:%M')
            data['record_id'] = record.id

            # 判断当前用户是否可以归还
            can_return = False
            if request.user.is_authenticated:
                if request.user.is_superuser:
                    can_return = True
                elif record.borrower == request.user:
                    can_return = True
                elif record.borrower_name:
                    profile = UserProfile.objects.filter(user=request.user).first()
                    user_display_name = profile.reader.reader_name if profile and profile.reader else request.user.username
                    if user_display_name == record.borrower_name:
                        can_return = True
            data['can_return'] = can_return
        else:
            data['borrower'] = None
            data['can_return'] = request.user.is_authenticated and request.user.is_superuser

    return JsonResponse({'success': True, 'data': data})


# ========== 书籍借阅次数统计API ==========

def api_books_borrow_counts(request):
    """获取所有书籍的借阅次数"""
    from django.db.models import Count
    from .models import BorrowRecord

    # 统计每本书的借阅次数
    borrow_counts = BorrowRecord.objects.values('book_id').annotate(
        count=Count('id')
    )

    # 转换为字典格式 {book_id: count}
    counts_dict = {item['book_id']: item['count'] for item in borrow_counts}

    return JsonResponse({
        'success': True,
        'counts': counts_dict
    })


# ========== 本地书籍搜索API ==========

def api_books_search(request):
    """搜索本地书籍（AJAX）"""
    keyword = request.GET.get('keyword', '').strip()
    category = request.GET.get('category', 'all')
    status_filter = request.GET.get('status', 'all')

    books = Book.objects.all()

    # 关键词搜索
    if keyword:
        books = books.filter(
            Q(book_name__icontains=keyword) |
            Q(author__icontains=keyword) |
            Q(isbn__icontains=keyword) |
            Q(publisher__icontains=keyword)
        )

    # 分类筛选
    if category and category != 'all':
        books = books.filter(book_type=category)

    # 状态筛选
    if status_filter and status_filter != 'all':
        books = books.filter(status=status_filter)

    books = books[:100]  # 限制返回100条

    # 获取借阅信息
    borrowed_book_ids = set()
    if request.user.is_authenticated:
        unreturned_records = BorrowRecord.objects.filter(is_returned=False).values_list('book_id', flat=True)
        borrowed_book_ids = set(unreturned_records)

    data = []
    for book in books:
        data.append({
            'id': book.id,
            'book_name': book.book_name,
            'author': book.author,
            'isbn': book.isbn or '',
            'book_type': book.book_type,
            'place': book.place or '',
            'status': book.status,
            'publisher': book.publisher or '',
            'publish_date': book.publish_date.strftime('%Y-%m-%d') if book.publish_date else '',
            'cover': book.cover.url if book.cover else '',
            'description': book.description or '',
            'is_borrowed_by_me': book.id in borrowed_book_ids
        })

    return JsonResponse({
        'success': True,
        'books': data,
        'total': len(data),
        'keyword': keyword
    })


# ========== 图书分类API ==========

# 获取所有分类
def api_categories_list(request):
    categories = Category.objects.all()
    data = [{
        'id': c.id,
        'name': c.name,
        'sort_order': c.sort_order,
        'book_count': Book.objects.filter(book_type=c.name).count()
    } for c in categories]
    return JsonResponse({'success': True, 'categories': data})


# 添加分类
@login_required
@require_http_methods(["POST"])
def api_category_add(request):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以添加分类'}, status=403)
    data = json.loads(request.body)
    name = data.get('name', '').strip()
    sort_order = data.get('sort_order', 0)
    if not name:
        return JsonResponse({'success': False, 'error': '请输入分类名称'})
    if Category.objects.filter(name=name).exists():
        return JsonResponse({'success': False, 'error': '该分类已存在'})
    category = Category.objects.create(name=name, sort_order=sort_order)
    return JsonResponse({
        'success': True,
        'category': {
            'id': category.id,
            'name': category.name,
            'sort_order': category.sort_order,
            'book_count': 0
        }
    })


# 编辑分类
@login_required
@require_http_methods(["POST"])
def api_category_edit(request, category_id):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以编辑分类'}, status=403)
    category = get_object_or_404(Category, id=category_id)
    data = json.loads(request.body)
    name = data.get('name', '').strip()
    sort_order = data.get('sort_order', 0)
    if not name:
        return JsonResponse({'success': False, 'error': '请输入分类名称'})
    # 检查名称是否重复（排除自己）
    if Category.objects.filter(name=name).exclude(id=category_id).exists():
        return JsonResponse({'success': False, 'error': '该分类名称已存在'})
    old_name = category.name
    category.name = name
    category.sort_order = sort_order
    category.save()
    # 同步更新所有该分类的书籍
    Book.objects.filter(book_type=old_name).update(book_type=name)
    return JsonResponse({'success': True})


# 删除分类
@login_required
@require_http_methods(["POST"])
def api_category_delete(request, category_id):
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以删除分类'}, status=403)
    category = get_object_or_404(Category, id=category_id)
    # 将该分类的书籍改为"其他"
    Book.objects.filter(book_type=category.name).update(book_type='其他')
    category.delete()
    return JsonResponse({'success': True})


# ========== 分页加载API ==========

@login_required
@require_http_methods(["GET"])
def api_books_list(request):
    """分页加载书籍列表API"""
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    category = request.GET.get('category', 'all')
    status = request.GET.get('status', 'all')

    books = Book.objects.all()

    # 分类筛选
    if category != 'all':
        books = books.filter(book_type=category)

    # 状态筛选
    if status == '在架':
        books = books.filter(status='在架')
    elif status == '借出':
        books = books.filter(status='借出')
    elif status == '未归还':
        books = books.filter(status='借出')

    total = books.count()
    total_pages = (total + page_size - 1) // page_size

    books = books[(page-1)*page_size:page*page_size]

    data = [{
        'id': b.id,
        'book_name': b.book_name,
        'author': b.author,
        'book_type': b.book_type,
        'status': b.status,
        'place': b.place or '',
        'isbn': b.isbn or '',
        'cover': b.cover.url if b.cover else '',
        'description': b.description or ''
    } for b in books]

    return JsonResponse({
        'success': True,
        'books': data,
        'pagination': {
            'current_page': page,
            'total_pages': total_pages,
            'total_books': total,
            'has_next': page < total_pages,
            'has_prev': page > 1
        }
    })


# ========== 通知提醒API ==========

@login_required
def api_notifications_list(request):
    """获取用户的通知列表"""
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')[:20]
    data = [{
        'id': n.id,
        'type': n.notification_type,
        'type_display': n.get_notification_type_display(),
        'title': n.title,
        'content': n.content,
        'is_read': n.is_read,
        'created_at': n.created_at.strftime('%Y-%m-%d %H:%M')
    } for n in notifications]
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()
    return JsonResponse({'success': True, 'notifications': data, 'unread_count': unread_count})


@login_required
@require_http_methods(["POST"])
def api_notification_read(request, notification_id):
    """标记通知为已读"""
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.is_read = True
    notification.save()
    return JsonResponse({'success': True})


@login_required
@require_http_methods(["POST"])
def api_notification_read_all(request):
    """标记所有通知为已读"""
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return JsonResponse({'success': True})


@login_required
def api_check_due_reminders(request):
    """检查并生成借阅到期提醒"""
    now = timezone.now()

    # 检查超过14天未归还的书籍，生成提醒
    fourteen_days_ago = now - timezone.timedelta(days=14)
    thirty_days_ago = now - timezone.timedelta(days=30)

    # 获取未归还记录
    unreturned_records = BorrowRecord.objects.filter(is_returned=False).select_related('book', 'borrower')

    reminders_created = 0
    for record in unreturned_records:
        days_borrowed = (now.date() - record.borrow_date.date()).days

        # 超过30天为逾期，超过14天为提醒
        if days_borrowed > 14:
            # 检查是否已有提醒
            existing = Notification.objects.filter(
                borrow_record=record,
                notification_type__in=['due_reminder', 'overdue']
            ).exists()

            if not existing:
                notification_type = 'overdue' if days_borrowed > 30 else 'due_reminder'
                title = '借阅逾期通知' if days_borrowed > 30 else '借阅到期提醒'
                content = f'《{record.book.book_name}》已借阅{days_borrowed}天，请及时归还。'

                # 给借阅人发通知
                if record.borrower:
                    Notification.objects.create(
                        user=record.borrower,
                        notification_type=notification_type,
                        title=title,
                        content=content,
                        borrow_record=record
                    )
                    reminders_created += 1

    return JsonResponse({'success': True, 'reminders_created': reminders_created})


# ========== 数据库备份API ==========

@login_required
def api_database_backup(request):
    """一键备份数据库（下载SQLite文件）"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以备份数据库'}, status=403)

    from django.http import HttpResponse
    from django.conf import settings
    import os

    db_path = settings.DATABASES['default']['NAME']

    if not os.path.exists(db_path):
        return JsonResponse({'success': False, 'error': '数据库文件不存在'}, status=404)

    # 记录操作日志
    create_operation_log(request, 'backup', 'database', None, '数据库', '执行数据库备份')

    with open(db_path, 'rb') as f:
        db_content = f.read()

    response = HttpResponse(db_content, content_type='application/octet-stream')
    filename = f'family_book_backup_{timezone.now().strftime("%Y%m%d_%H%M%S")}.sqlite3'
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    return response


# ========== 操作日志API ==========

@login_required
def api_operation_logs(request):
    """获取操作日志列表"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以查看日志'}, status=403)

    page = int(request.GET.get('page', 1))
    page_size = 50
    action_filter = request.GET.get('action', 'all')

    logs = OperationLog.objects.all()

    if action_filter != 'all':
        logs = logs.filter(action=action_filter)

    logs = logs.order_by('-created_at')
    total = logs.count()
    logs = logs[(page-1)*page_size:page*page_size]

    data = [{
        'id': log.id,
        'user': log.user.username if log.user else '未知',
        'action': log.action,
        'action_display': log.get_action_display(),
        'target_type': log.target_type,
        'target_name': log.target_name,
        'detail': log.detail,
        'ip_address': log.ip_address,
        'created_at': log.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for log in logs]

    return JsonResponse({
        'success': True,
        'logs': data,
        'total': total,
        'page': page
    })


# ========== 批量操作API ==========

@login_required
@require_http_methods(["POST"])
def api_batch_borrow(request):
    """批量借阅"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以批量借阅'}, status=403)

    data = json.loads(request.body)
    book_ids = data.get('book_ids', [])
    borrower_id = data.get('borrower_id')

    if not book_ids:
        return JsonResponse({'success': False, 'error': '请选择要借阅的书籍'})

    if not borrower_id:
        return JsonResponse({'success': False, 'error': '请选择借阅人'})

    try:
        borrower = User.objects.get(id=borrower_id)
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': '借阅人不存在'})

    profile = UserProfile.objects.filter(user=borrower).first()
    borrower_name = profile.reader.reader_name if profile and profile.reader else borrower.username

    success_count = 0
    failed_books = []

    for book_id in book_ids:
        try:
            book = Book.objects.get(id=book_id)
            if book.status == '在架':
                BorrowRecord.objects.create(
                    book=book,
                    borrower=borrower,
                    borrower_name=borrower_name
                )
                book.status = '借出'
                book.save()
                success_count += 1
                # 记录操作日志
                create_operation_log(request, 'borrow', 'book', book.id, book.book_name,
                                    f'批量借阅给 {borrower_name}')
            else:
                failed_books.append(f'{book.book_name}（已借出）')
        except Book.DoesNotExist:
            failed_books.append(f'ID:{book_id} 不存在')

    message = f'成功借阅 {success_count} 本'
    if failed_books:
        message += f'，{len(failed_books)} 本失败'

    return JsonResponse({
        'success': True,
        'message': message,
        'success_count': success_count,
        'failed_books': failed_books
    })


@login_required
@require_http_methods(["POST"])
def api_batch_return(request):
    """批量归还"""
    data = json.loads(request.body)
    record_ids = data.get('record_ids', [])
    return_place = data.get('return_place', '未填写')

    if not record_ids:
        return JsonResponse({'success': False, 'error': '请选择要归还的记录'})

    success_count = 0
    failed_records = []

    for record_id in record_ids:
        try:
            record = BorrowRecord.objects.get(id=record_id, is_returned=False)
            record.is_returned = True
            record.return_date = timezone.now()
            record.save()

            record.book.status = '在架'
            record.book.place = return_place
            record.book.save()

            success_count += 1
            # 记录操作日志
            create_operation_log(request, 'return', 'book', record.book.id, record.book.book_name,
                                f'批量归还，位置：{return_place}')
        except BorrowRecord.DoesNotExist:
            failed_records.append(f'ID:{record_id}')

    message = f'成功归还 {success_count} 本'
    if failed_records:
        message += f'，{len(failed_records)} 条记录不存在'

    return JsonResponse({
        'success': True,
        'message': message,
        'success_count': success_count
    })


@login_required
@require_http_methods(["POST"])
def api_batch_delete_books(request):
    """批量删除书籍"""
    if not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': '只有管理员可以删除书籍'}, status=403)

    data = json.loads(request.body)
    book_ids = data.get('book_ids', [])

    if not book_ids:
        return JsonResponse({'success': False, 'error': '请选择要删除的书籍'})

    deleted_count = 0
    for book_id in book_ids:
        try:
            book = Book.objects.get(id=book_id)
            book_name = book.book_name
            book.delete()
            deleted_count += 1
            # 记录操作日志
            create_operation_log(request, 'delete_book', 'book', book_id, book_name, '批量删除')
        except Book.DoesNotExist:
            pass

    return JsonResponse({
        'success': True,
        'message': f'成功删除 {deleted_count} 本书籍',
        'deleted_count': deleted_count
    })


# ========== 阅读统计报表API ==========

@login_required
def api_reading_statistics(request):
    """获取阅读统计报表"""
    now = timezone.now()

    # 获取时间范围参数
    year = int(request.GET.get('year', now.year))
    month = int(request.GET.get('month', 0))  # 0表示全年
    user_id = request.GET.get('user_id')  # 指定用户

    # 基础查询
    records = BorrowRecord.objects.all()

    if user_id:
        records = records.filter(borrower_id=user_id)

    # 按年份筛选
    records = records.filter(borrow_date__year=year)

    # 月份筛选
    if month > 0:
        records = records.filter(borrow_date__month=month)

    # 1. 月度阅读统计
    from django.db.models.functions import TruncMonth
    monthly_stats = records.annotate(
        month=TruncMonth('borrow_date')
    ).values('month').annotate(
        count=Count('id')
    ).order_by('month')

    monthly_data = [{
        'month': stat['month'].strftime('%Y-%m'),
        'count': stat['count']
    } for stat in monthly_stats]

    # 2. 分类阅读统计
    category_stats = records.values('book__book_type').annotate(
        count=Count('id')
    ).order_by('-count')

    category_data = [{
        'category': stat['book__book_type'],
        'count': stat['count']
    } for stat in category_stats]

    # 3. 个人阅读轨迹
    if user_id:
        user = User.objects.get(id=user_id)
        profile = UserProfile.objects.filter(user=user).first()
        user_name = profile.reader.reader_name if profile and profile.reader else user.username

        # 借阅历史
        user_records = BorrowRecord.objects.filter(borrower_id=user_id).select_related('book').order_by('-borrow_date')[:50]

        trajectory = [{
            'book_name': r.book.book_name,
            'author': r.book.author,
            'borrow_date': r.borrow_date.strftime('%Y-%m-%d'),
            'return_date': r.return_date.strftime('%Y-%m-%d') if r.return_date else '未归还',
            'days': (r.return_date - r.borrow_date).days if r.return_date else None
        } for r in user_records]

        # 统计
        total_borrowed = BorrowRecord.objects.filter(borrower_id=user_id).count()
        total_returned = BorrowRecord.objects.filter(borrower_id=user_id, is_returned=True).count()

        personal_stats = {
            'user_name': user_name,
            'total_borrowed': total_borrowed,
            'total_returned': total_returned,
            'current_borrowed': total_borrowed - total_returned,
            'trajectory': trajectory
        }
    else:
        personal_stats = None

    # 4. 排行榜
    top_readers = BorrowRecord.objects.filter(
        borrow_date__year=year
    ).values('borrower_name').annotate(
        count=Count('id')
    ).order_by('-count')[:10]

    top_books = BorrowRecord.objects.filter(
        borrow_date__year=year
    ).values('book__book_name', 'book__author').annotate(
        count=Count('id')
    ).order_by('-count')[:10]

    return JsonResponse({
        'success': True,
        'data': {
            'year': year,
            'month': month,
            'monthly_stats': monthly_data,
            'category_stats': category_data,
            'personal_stats': personal_stats,
            'top_readers': list(top_readers),
            'top_books': list(top_books)
        }
    })


@login_required
def api_reading_report(request):
    """生成阅读报告（月报）"""
    now = timezone.now()
    year = int(request.GET.get('year', now.year))
    month = int(request.GET.get('month', now.month))

    # 该月借阅记录
    records = BorrowRecord.objects.filter(
        borrow_date__year=year,
        borrow_date__month=month
    )

    # 统计数据
    total_borrows = records.count()
    total_returns = records.filter(is_returned=True, return_date__year=year, return_date__month=month).count()

    # 新增书籍
    new_books = Book.objects.filter(
        created_at__year=year,
        created_at__month=month
    ).count() if hasattr(Book, 'created_at') else 0

    # 最受欢迎的书
    popular_books = records.values('book__book_name').annotate(
        count=Count('id')
    ).order_by('-count')[:5]

    # 最活跃的读者
    active_readers = records.values('borrower_name').annotate(
        count=Count('id')
    ).order_by('-count')[:5]

    return JsonResponse({
        'success': True,
        'report': {
            'period': f'{year}年{month}月',
            'total_borrows': total_borrows,
            'total_returns': total_returns,
            'new_books': new_books,
            'popular_books': list(popular_books),
            'active_readers': list(active_readers)
        }
    })


# ========== 二维码生成API ==========

@login_required
def api_book_qrcode(request, book_id):
    """生成书籍分享二维码"""
    import qrcode
    from io import BytesIO
    import base64

    book = get_object_or_404(Book, id=book_id)

    # 生成分享链接（可以是书籍详情页或借阅页）
    share_url = request.build_absolute_uri(f'/borrow/{book_id}/')

    # 生成二维码
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(share_url)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")

    # 转换为base64
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    img_base64 = base64.b64encode(buffer.getvalue()).decode()

    return JsonResponse({
        'success': True,
        'qrcode': f'data:image/png;base64,{img_base64}',
        'share_url': share_url,
        'book_name': book.book_name
    })


# ========== 书评点赞API ==========

@login_required
@require_http_methods(["POST"])
def api_comment_like(request, comment_id):
    """点赞书评"""
    comment = get_object_or_404(BookComment, id=comment_id)

    # 检查是否已点赞
    existing_like = BookCommentLike.objects.filter(comment=comment, user=request.user).first()

    if existing_like:
        # 取消点赞
        existing_like.delete()
        liked = False
    else:
        # 点赞
        BookCommentLike.objects.create(comment=comment, user=request.user)
        liked = True

    like_count = comment.likes.count()

    return JsonResponse({
        'success': True,
        'liked': liked,
        'like_count': like_count
    })


@login_required
def api_comment_likes(request, comment_id):
    """获取书评点赞状态"""
    comment = get_object_or_404(BookComment, id=comment_id)
    like_count = comment.likes.count()
    liked = BookCommentLike.objects.filter(comment=comment, user=request.user).exists()

    return JsonResponse({
        'success': True,
        'like_count': like_count,
        'liked': liked
    })


# ========== 阅读打卡与徽章API ==========

@login_required
@require_http_methods(["POST"])
def api_checkin(request):
    """每日打卡"""
    from datetime import date, timedelta

    today = date.today()

    # 检查今天是否已打卡
    existing = ReadingCheckIn.objects.filter(user=request.user, checkin_date=today).first()
    if existing:
        return JsonResponse({
            'success': False,
            'message': '今天已经打卡过了',
            'already_checked': True
        })

    # 创建打卡记录
    ReadingCheckIn.objects.create(user=request.user, checkin_date=today)

    # 计算连续打卡天数
    streak = calculate_streak(request.user)

    # 计算累计打卡天数
    total_days = ReadingCheckIn.objects.filter(user=request.user).count()

    # 检查并颁发徽章
    new_badges = check_and_award_badges(request.user, streak, total_days)

    return JsonResponse({
        'success': True,
        'message': '打卡成功！',
        'streak': streak,
        'total_days': total_days,
        'new_badges': new_badges
    })


def calculate_streak(user):
    """计算连续打卡天数"""
    from datetime import date, timedelta

    checkins = list(ReadingCheckIn.objects.filter(user=user).values_list('checkin_date', flat=True).order_by('-checkin_date'))

    if not checkins:
        return 0

    today = date.today()
    yesterday = today - timedelta(days=1)

    streak = 0
    expected_date = today

    # 如果今天没打卡，从昨天开始算
    if checkins[0] != today:
        if checkins[0] == yesterday:
            expected_date = yesterday
        else:
            return 0

    for checkin_date in checkins:
        if checkin_date == expected_date:
            streak += 1
            expected_date -= timedelta(days=1)
        else:
            break

    return streak


def check_and_award_badges(user, streak, total_days):
    """检查并颁发徽章"""
    new_badges = []

    # 连续打卡7天徽章
    if streak >= 7:
        badge, created = UserBadge.objects.get_or_create(
            user=user,
            badge_type='week_reader'
        )
        if created:
            new_badges.append('week_reader')

    # 累计打卡30天徽章
    if total_days >= 30:
        badge, created = UserBadge.objects.get_or_create(
            user=user,
            badge_type='month_reader'
        )
        if created:
            new_badges.append('month_reader')

    # 累计借阅10本书徽章
    borrow_count = BorrowRecord.objects.filter(borrower=user).count()
    if borrow_count >= 10:
        badge, created = UserBadge.objects.get_or_create(
            user=user,
            badge_type='book_lover'
        )
        if created:
            new_badges.append('book_lover')

    return new_badges


@login_required
def api_checkin_status(request):
    """获取打卡状态"""
    from datetime import date, timedelta

    today = date.today()

    # 检查今天是否已打卡
    checked_today = ReadingCheckIn.objects.filter(user=request.user, checkin_date=today).exists()

    # 连续打卡天数
    streak = calculate_streak(request.user)

    # 累计打卡天数
    total_days = ReadingCheckIn.objects.filter(user=request.user).count()

    # 本周打卡天数
    week_start = today - timedelta(days=today.weekday())
    week_days = ReadingCheckIn.objects.filter(
        user=request.user,
        checkin_date__gte=week_start
    ).count()

    return JsonResponse({
        'success': True,
        'checked_today': checked_today,
        'streak': streak,
        'total_days': total_days,
        'week_days': week_days
    })


@login_required
def api_user_badges(request):
    """获取用户徽章"""
    badges = UserBadge.objects.filter(user=request.user)

    badge_list = []
    for badge in badges:
        badge_list.append({
            'id': badge.id,
            'type': badge.badge_type,
            'name': badge.name,
            'description': badge.description,
            'icon': badge.icon,
            'earned_at': badge.earned_at.strftime('%Y-%m-%d')
        })

    return JsonResponse({
        'success': True,
        'badges': badge_list
    })
