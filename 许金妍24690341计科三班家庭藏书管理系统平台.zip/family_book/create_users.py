import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'family_book.settings')
django.setup()

from django.contrib.auth.models import User

# 创建超级管理员
admin_user, created = User.objects.get_or_create(
    username='admin',
    defaults={
        'email': 'admin@family.com',
        'is_staff': True,
        'is_superuser': True
    }
)
if created or not admin_user.check_password('admin'):
    admin_user.set_password('admin')
    admin_user.save()
    print('Admin user created/updated: admin / admin')

# 删除旧的测试用户
User.objects.filter(username__in=['member', 'guest']).delete()
print('Removed old test users')
