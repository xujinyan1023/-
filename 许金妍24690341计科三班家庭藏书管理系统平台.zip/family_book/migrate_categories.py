"""
迁移现有分类数据到Category表
"""
import os
import sys
import django

# 设置Django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'family_book.settings')
django.setup()

from books.models import Book, Category

def migrate_categories():
    # 定义默认分类（与原模板中的分类一致）
    default_categories = ['小说', '教材', '字典', '报纸杂志', '其他']

    # 先添加默认分类
    for i, name in enumerate(default_categories):
        Category.objects.get_or_create(name=name, defaults={'sort_order': i})

    # 从现有书籍中提取分类
    existing_types = Book.objects.values_list('book_type', flat=True).distinct()

    added_count = 0
    for book_type in existing_types:
        if book_type and not Category.objects.filter(name=book_type).exists():
            Category.objects.create(name=book_type, sort_order=100)
            added_count += 1
            print(f"添加分类: {book_type}")

    print(f"\n迁移完成！新增了 {added_count} 个分类")
    print(f"当前共有 {Category.objects.count()} 个分类")

if __name__ == '__main__':
    migrate_categories()
