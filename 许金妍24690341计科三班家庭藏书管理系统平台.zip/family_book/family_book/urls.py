from django.contrib import admin
from django.urls import path, include
# 新增这两行导入！
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", include("books.urls")),  # 你原来的路由
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  # 新增这行！